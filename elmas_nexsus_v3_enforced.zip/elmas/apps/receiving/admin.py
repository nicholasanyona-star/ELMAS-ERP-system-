from django.contrib import admin
from .models import GateEntry, GRN, GRNLine, GRNDiscrepancy, IQCInspection, IQCDefect, Quarantine


@admin.register(GateEntry)
class GateEntryAdmin(admin.ModelAdmin):
    list_display = ('gate_number', 'supplier', 'driver_name', 'vehicle_plate', 'status', 'time_in')
    list_filter = ('status',)
    search_fields = ('gate_number', 'driver_name', 'vehicle_plate')
    ordering = ('-time_in',)


@admin.register(GRN)
class GRNAdmin(admin.ModelAdmin):
    list_display = ('grn_number', 'supplier', 'material_category', 'status', 'received_by', 'created_at')
    list_filter = ('status', 'material_category')
    search_fields = ('grn_number',)
    ordering = ('-created_at',)


@admin.register(GRNLine)
class GRNLineAdmin(admin.ModelAdmin):
    list_display = ('grn', 'product', 'quantity_received', 'quantity_rejected')
    search_fields = ('grn__grn_number', 'product__name')


@admin.register(GRNDiscrepancy)
class GRNDiscrepancyAdmin(admin.ModelAdmin):
    list_display = ('grn', 'grn_line', 'resolution', 'resolved_by', 'resolved_at')
    list_filter = ('resolution',)
    ordering = ('-created_at',)


@admin.register(IQCInspection)
class IQCInspectionAdmin(admin.ModelAdmin):
    list_display = ('inspection_number', 'grn', 'decision', 'defects_found', 'inspected_by', 'inspected_at')
    list_filter = ('decision',)
    search_fields = ('inspection_number',)
    ordering = ('-created_at',)


@admin.register(Quarantine)
class QuarantineAdmin(admin.ModelAdmin):
    list_display = ('quarantine_number', 'product', 'quantity', 'decision', 'status', 'created_at')
    list_filter = ('status', 'decision')
    search_fields = ('quarantine_number', 'product__name')
    ordering = ('-created_at',)
