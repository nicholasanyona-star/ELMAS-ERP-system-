from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('receiving', '0003_grn_fixes'),
    ]
    operations = [
        migrations.AddField(
            model_name='quarantine',
            name='deadline',
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name='quarantine',
            name='status',
            field=models.CharField(
                choices=[('pending', 'Pending Decision'), ('resolved', 'Resolved')],
                db_index=True, default='pending', max_length=10
            ),
        ),
    ]
