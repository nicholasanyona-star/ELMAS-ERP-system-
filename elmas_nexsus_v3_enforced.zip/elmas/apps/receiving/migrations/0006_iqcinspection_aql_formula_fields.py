"""
ELMAS Receiving Migration 0006
- Add full AQL formula fields to IQCInspection
- Add battery-specific check fields
- Add override tracking fields
"""
from django.db import migrations, models
import django.db.models.deletion
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('receiving', '0005_grn_supplier_name_manual'),
        ('accounts', '0004_user_assigned_line'),
    ]

    operations = [
        # AQL sampling fields
        migrations.AddField(
            model_name='iqcinspection',
            name='aql_level_used',
            field=models.CharField(default='2.5', max_length=5),
        ),
        migrations.AddField(
            model_name='iqcinspection',
            name='sample_size_required',
            field=models.IntegerField(default=0),
        ),
        migrations.AddField(
            model_name='iqcinspection',
            name='sample_size_actual',
            field=models.IntegerField(default=0),
        ),
        migrations.AddField(
            model_name='iqcinspection',
            name='accept_critical',
            field=models.IntegerField(default=0),
        ),
        migrations.AddField(
            model_name='iqcinspection',
            name='accept_major',
            field=models.IntegerField(default=0),
        ),
        migrations.AddField(
            model_name='iqcinspection',
            name='accept_minor',
            field=models.IntegerField(default=0),
        ),
        migrations.AddField(
            model_name='iqcinspection',
            name='critical_found',
            field=models.IntegerField(default=0),
        ),
        migrations.AddField(
            model_name='iqcinspection',
            name='major_found',
            field=models.IntegerField(default=0),
        ),
        migrations.AddField(
            model_name='iqcinspection',
            name='minor_found',
            field=models.IntegerField(default=0),
        ),
        migrations.AddField(
            model_name='iqcinspection',
            name='aql_recommendation',
            field=models.CharField(
                blank=True, max_length=10, null=True,
                choices=[('pass', 'Pass'), ('fail', 'Fail')],
            ),
        ),
        migrations.AddField(
            model_name='iqcinspection',
            name='qc_override',
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name='iqcinspection',
            name='override_reason',
            field=models.TextField(blank=True),
        ),
        migrations.AddField(
            model_name='iqcinspection',
            name='override_notified_fm',
            field=models.BooleanField(default=False),
        ),
        # Battery specific checks
        migrations.AddField(
            model_name='iqcinspection',
            name='battery_physical_ok',
            field=models.BooleanField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name='iqcinspection',
            name='battery_voltage_ok',
            field=models.BooleanField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name='iqcinspection',
            name='battery_voltage_reading',
            field=models.CharField(blank=True, max_length=20),
        ),
        migrations.AddField(
            model_name='iqcinspection',
            name='battery_capacity_ok',
            field=models.BooleanField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name='iqcinspection',
            name='battery_shelf_life_ok',
            field=models.BooleanField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name='iqcinspection',
            name='battery_labelling_ok',
            field=models.BooleanField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name='iqcinspection',
            name='battery_swelling_found',
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name='iqcinspection',
            name='bcr_triggered',
            field=models.BooleanField(default=False),
        ),
    ]
