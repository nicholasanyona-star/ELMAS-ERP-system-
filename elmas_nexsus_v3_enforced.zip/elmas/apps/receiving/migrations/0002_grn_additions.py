from django.db import migrations, models
import django.db.models.deletion
from django.conf import settings


class Migration(migrations.Migration):
    dependencies = [
        ('receiving', '0001_initial'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]
    operations = [
        migrations.AddField('GRN', 'purchase_order_ref',
            models.CharField(blank=True, max_length=50)),
        migrations.AddField('GRN', 'cancelled_at',
            models.DateTimeField(blank=True, null=True)),
        migrations.AddField('GRN', 'cancel_reason',
            models.TextField(blank=True)),
        migrations.AddField('GRN', 'cancelled_by',
            models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL,
                related_name='grns_cancelled', to=settings.AUTH_USER_MODEL)),
    ]
