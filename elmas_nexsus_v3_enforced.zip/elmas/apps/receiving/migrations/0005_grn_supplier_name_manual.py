"""
ELMAS Receiving Migration 0005
- Add supplier_name_manual to GRN model (was missing, causing AttributeError)
"""
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('receiving', '0004_quarantine_deadline_status'),
    ]

    operations = [
        migrations.AddField(
            model_name='grn',
            name='supplier_name_manual',
            field=models.CharField(
                blank=True,
                help_text='Supplier name if not in system yet',
                max_length=200,
            ),
        ),
    ]
