from django.db import migrations, models
import django.db.models.deletion
from django.conf import settings


class Migration(migrations.Migration):
    dependencies = [
        ('receiving', '0002_grn_additions'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]
    operations = [
        # Rename category to material_category on GRN
        migrations.RenameField(
            model_name='grn',
            old_name='category',
            new_name='material_category',
        ),
        # Add submitted_at to GRN
        migrations.AddField(
            model_name='grn',
            name='submitted_at',
            field=models.DateTimeField(blank=True, null=True),
        ),
        # Add GateEntry cancelled_by field
        migrations.AddField(
            model_name='gateentry',
            name='cancelled_by',
            field=models.ForeignKey(
                blank=True, null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='gates_cancelled',
                to=settings.AUTH_USER_MODEL
            ),
        ),
    ]
