from django.urls import path
from . import views
app_name = 'receiving'
urlpatterns = [
    path('gate/', views.gate_list, name='gate_list'),
    path('gate/create/', views.gate_create, name='gate_create'),
    path('gate/<int:pk>/', views.gate_detail, name='gate_detail'),
    path('gate/<int:pk>/depart/', views.gate_depart, name='gate_depart'),
    path('gate/<int:pk>/unloading/', views.gate_unloading, name='gate_unloading'),
    path('gate/<int:pk>/pdf/', views.gate_pdf, name='gate_pdf'),
    path('grn/', views.grn_list, name='grn_list'),
    path('grn/create/', views.grn_create, name='grn_create'),
    path('grn/<int:pk>/', views.grn_detail, name='grn_detail'),
    path('grn/<int:pk>/receive/', views.grn_receive, name='grn_receive'),
    path('grn/<int:pk>/submit/', views.grn_submit, name='grn_submit'),
    path('grn/<int:pk>/verify/', views.grn_verify, name='grn_verify'),
    path('grn/<int:pk>/pdf/', views.grn_pdf, name='grn_pdf'),
    path('grn/<int:pk>/cancel/', views.grn_cancel, name='grn_cancel'),
    path('grn/<int:pk>/line/<int:line_pk>/delete/', views.grn_delete_line, name='grn_delete_line'),
    path('api/product-lookup/', views.product_lookup, name='product_lookup'),
]
