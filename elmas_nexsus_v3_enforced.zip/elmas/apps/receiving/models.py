"""
ELMAS Receiving Models
Gate Entry, GRN, IQC, Quarantine
"""
from django.db import models
from django.conf import settings
from django.utils import timezone


class GateEntry(models.Model):
    """
    Every truck that arrives at the factory gate
    Must be registered before unloading
    """
    STATUS_CHOICES = (
        ('arrived',   'Arrived'),
        ('unloading', 'Unloading'),
        ('departed',  'Departed'),
    )

    gate_number = models.CharField(
        max_length=50, unique=True, db_index=True
    )
    supplier = models.ForeignKey(
        'inventory.Supplier',
        on_delete=models.SET_NULL,
        null=True, blank=True
    )
    supplier_name_manual = models.CharField(
        max_length=200, blank=True,
        help_text='If supplier not in system yet'
    )
    driver_name = models.CharField(max_length=100)
    vehicle_plate = models.CharField(max_length=20)
    delivery_note_number = models.CharField(max_length=100, blank=True)
    number_of_cartons = models.IntegerField(default=0)
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='arrived'
    )
    time_in = models.DateTimeField(default=timezone.now)
    time_out = models.DateTimeField(null=True, blank=True)
    notes = models.TextField(blank=True)
    cancel_reason = models.TextField(blank=True)
    cancelled_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='gates_cancelled'
    )
    cancelled_at = models.DateTimeField(null=True, blank=True)
    registered_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True
    )

    class Meta:
        ordering = ['-time_in']
        verbose_name = 'Gate Entry'
        verbose_name_plural = 'Gate Entries'

    def __str__(self):
        return f"{self.gate_number} — {self.supplier_name}"

    @property
    def supplier_name(self):
        if self.supplier:
            return self.supplier.name
        return self.supplier_name_manual or 'Unknown'

    def save(self, *args, **kwargs):
        if not self.gate_number:
            today = timezone.now().strftime('%Y%m%d')
            count = GateEntry.objects.filter(
                gate_number__startswith=f'GATE-{today}'
            ).count() + 1
            self.gate_number = f"GATE-{today}-{str(count).zfill(4)}"
        super().save(*args, **kwargs)


class GRN(models.Model):
    """
    Goods Received Note
    Created for every delivery — one GRN per category
    (separate GRNs for raw materials, packaging, consumables)
    """
    CATEGORY_CHOICES = (
        ('raw_material', '📦 Raw Materials'),
        ('packaging',    '🗃️ Packaging Materials'),
        ('consumable',   '🔧 Consumables'),
        ('battery',      '🔋 Battery'),
    )

    STATUS_CHOICES = (
        ('draft',      'Draft — being entered'),
        ('submitted',  'Submitted — awaiting verification'),
        ('verified',   'Verified — awaiting IQC'),
        ('iqc_pass',   'IQC Passed — in inventory'),
        ('iqc_fail',   'IQC Failed — in quarantine'),
        ('partial',    'Partial — some passed, some quarantined'),
        ('discrepancy','Discrepancy — under review'),
        ('cancelled',   'Cancelled — voided'),
    )

    grn_number = models.CharField(
        max_length=50, unique=True, db_index=True
    )
    material_category = models.CharField(
        max_length=20,
        choices=CATEGORY_CHOICES,
        db_index=True
    )
    purchase_order_ref = models.CharField(
        max_length=50, blank=True,
        help_text='PO number this delivery is against (e.g. PO-20240315-001)'
    )
    gate_entry = models.ForeignKey(
        GateEntry,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='grns'
    )
    supplier = models.ForeignKey(
        'inventory.Supplier',
        on_delete=models.SET_NULL,
        null=True, blank=True
    )
    supplier_name_manual = models.CharField(
        max_length=200, blank=True,
        help_text='Supplier name if not in system yet'
    )
    supplier_invoice_number = models.CharField(max_length=100, blank=True)
    delivery_note_number = models.CharField(max_length=100, blank=True)
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='draft',
        db_index=True
    )

    # Dates
    delivery_date = models.DateField(default=timezone.now)
    created_at = models.DateTimeField(auto_now_add=True)

    # Staff
    received_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='grn_received'
    )
    verified_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='grn_verified'
    )
    verified_at = models.DateTimeField(null=True, blank=True)
    submitted_at = models.DateTimeField(null=True, blank=True)

    notes = models.TextField(blank=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'GRN'
        verbose_name_plural = 'GRNs'

    def __str__(self):
        return f"{self.grn_number} — {self.get_material_category_display()}"

    def clean(self):
        from django.core.exceptions import ValidationError
        if not self.supplier_id and not self.supplier_name_manual:
            raise ValidationError('Either select a supplier or enter supplier name manually.')

    def save(self, *args, **kwargs):
        if not self.grn_number:
            today = timezone.now().strftime('%Y%m%d')
            prefix_map = {
                'raw_material': 'GRN-RM',
                'packaging': 'GRN-PKG',
                'consumable': 'GRN-CONS',
                'battery': 'GRN-BAT',
            }
            prefix = prefix_map.get(self.material_category, 'GRN')
            count = GRN.objects.filter(
                grn_number__startswith=f'{prefix}-{today}'
            ).count() + 1
            self.grn_number = f"{prefix}-{today}-{str(count).zfill(4)}"
        super().save(*args, **kwargs)

    @property
    def total_lines(self):
        return self.lines.count()

    @property
    def supplier_name(self):
        if self.supplier:
            return self.supplier.name
        return self.supplier_name_manual or 'Unknown Supplier'

    @property
    def total_value(self):
        total = sum(
            float(l.quantity_received) * float(l.unit_cost)
            for l in self.lines.all()
        )
        return total


class GRNLine(models.Model):
    """
    Individual item line on a GRN
    Can be added by scan, manual entry, or Excel upload
    """
    ENTRY_METHOD_CHOICES = (
        ('scan',    '📷 Barcode Scan'),
        ('manual',  '✏️ Manual Entry'),
        ('excel',   '📊 Excel Upload'),
        ('partial', '⚡ Partial Entry'),
    )

    grn = models.ForeignKey(
        GRN,
        on_delete=models.CASCADE,
        related_name='lines'
    )
    product = models.ForeignKey(
        'inventory.Product',
        on_delete=models.PROTECT,
        null=True, blank=True
    )
    # For new items not yet in system
    temp_barcode = models.CharField(max_length=100, blank=True)
    temp_name = models.CharField(max_length=200, blank=True)
    is_new_product = models.BooleanField(default=False)

    entry_method = models.CharField(
        max_length=10,
        choices=ENTRY_METHOD_CHOICES,
        default='manual'
    )

    quantity_expected = models.DecimalField(
        max_digits=15, decimal_places=4, default=0
    )
    quantity_received = models.DecimalField(
        max_digits=15, decimal_places=4, default=0
    )
    quantity_rejected = models.DecimalField(
        max_digits=15, decimal_places=4, default=0,
        help_text='Partial — damaged or wrong items'
    )
    unit_cost = models.DecimalField(
        max_digits=15, decimal_places=2, default=0
    )
    uom = models.CharField(max_length=20, default='EA')

    supplier_batch_number = models.CharField(max_length=100, blank=True)
    expiry_date = models.DateField(null=True, blank=True)
    manufacture_date = models.DateField(null=True, blank=True)
    condition = models.CharField(
        max_length=20,
        choices=(
            ('good',    'Good'),
            ('damaged', 'Damaged'),
            ('short',   'Short Delivery'),
            ('wrong',   'Wrong Item'),
        ),
        default='good'
    )
    notes = models.CharField(max_length=255, blank=True)
    batch = models.ForeignKey(
        'inventory.StockBatch',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='grn_lines'
    )

    class Meta:
        ordering = ['id']

    def __str__(self):
        name = self.product.name if self.product else self.temp_name
        return f"{name} × {self.quantity_received}"

    @property
    def has_discrepancy(self):
        return (
            float(self.quantity_received) != float(self.quantity_expected)
            or self.condition != 'good'
        )

    @property
    def line_value(self):
        return float(self.quantity_received) * float(self.unit_cost)


class GRNDiscrepancy(models.Model):
    """
    Discrepancy recorded on a GRN line
    Auto-created when qty_received != qty_expected
    """
    grn = models.ForeignKey(
        GRN, on_delete=models.CASCADE, related_name='discrepancies'
    )
    grn_line = models.ForeignKey(
        GRNLine, on_delete=models.CASCADE, related_name='discrepancies'
    )
    description = models.TextField()
    resolution = models.CharField(
        max_length=20,
        choices=(
            ('pending',  'Pending'),
            ('accepted', 'Accepted as-is'),
            ('returned', 'Returned to supplier'),
            ('credited', 'Credit note received'),
            ('resolved', 'Resolved'),
        ),
        default='pending',
        db_index=True
    )
    resolution_notes = models.TextField(blank=True)
    resolved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True
    )
    resolved_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Discrepancy on {self.grn.grn_number}"


class IQCInspection(models.Model):
    """
    Incoming Quality Control inspection
    AQL-based sampling — formula-driven pass/fail recommendation
    """
    DECISION_CHOICES = (
        ('pass',    '✅ Pass — release to inventory'),
        ('fail',    '❌ Fail — send to quarantine'),
        ('partial', '⚡ Partial — split batch'),
    )

    inspection_number = models.CharField(
        max_length=50, unique=True, db_index=True
    )
    grn = models.ForeignKey(
        GRN,
        on_delete=models.CASCADE,
        related_name='inspections'
    )
    grn_line = models.ForeignKey(
        GRNLine,
        on_delete=models.SET_NULL,
        null=True, blank=True
    )

    # AQL — sampling
    batch_size = models.IntegerField(default=0)
    aql_level_used = models.CharField(
        max_length=5, default='2.5',
        help_text='AQL level applied — from strictest product in GRN'
    )
    sample_size_required = models.IntegerField(
        default=0,
        help_text='Sample size required by AQL formula'
    )
    sample_size_actual = models.IntegerField(
        default=0,
        help_text='Actual number of units QC inspected'
    )

    # AQL acceptance numbers (copied from AQLTable at inspection time)
    accept_critical = models.IntegerField(
        default=0,
        help_text='Zero tolerance — any critical defect = fail'
    )
    accept_major = models.IntegerField(
        default=0,
        help_text='Max major defects allowed before fail'
    )
    accept_minor = models.IntegerField(
        default=0,
        help_text='Max minor defects allowed before fail'
    )
    rejection_number = models.IntegerField(
        default=1,
        help_text='Number of defects that triggers rejection'
    )

    # Defect counts by severity
    critical_found = models.IntegerField(default=0)
    major_found = models.IntegerField(default=0)
    minor_found = models.IntegerField(default=0)
    defects_found = models.IntegerField(
        default=0,
        help_text='Total defects found across all severities'
    )

    # AQL formula recommendation
    aql_recommendation = models.CharField(
        max_length=10,
        choices=(('pass', 'Pass'), ('fail', 'Fail')),
        null=True, blank=True,
        help_text='System recommendation based on AQL formula'
    )

    # QC override (if QC disagrees with formula)
    qc_override = models.BooleanField(
        default=False,
        help_text='True if QC Officer overrode the AQL recommendation'
    )
    override_reason = models.TextField(
        blank=True,
        help_text='Mandatory reason if QC overrides recommendation'
    )
    override_notified_fm = models.BooleanField(default=False)

    # Battery specific checks
    battery_physical_ok = models.BooleanField(null=True, blank=True)
    battery_voltage_ok = models.BooleanField(null=True, blank=True)
    battery_voltage_reading = models.CharField(max_length=20, blank=True)
    battery_capacity_ok = models.BooleanField(null=True, blank=True)
    battery_shelf_life_ok = models.BooleanField(null=True, blank=True)
    battery_labelling_ok = models.BooleanField(null=True, blank=True)
    battery_swelling_found = models.BooleanField(
        default=False,
        help_text='If True — BCR auto-triggered immediately'
    )
    bcr_triggered = models.BooleanField(default=False)

    # Results
    quantity_accepted = models.DecimalField(
        max_digits=15, decimal_places=4, default=0
    )
    quantity_rejected = models.DecimalField(
        max_digits=15, decimal_places=4, default=0
    )
    decision = models.CharField(
        max_length=10,
        choices=DECISION_CHOICES,
        null=True, blank=True,
        db_index=True
    )
    remarks = models.TextField(blank=True)

    # Staff
    inspected_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='iqc_inspections'
    )
    inspected_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'IQC Inspection'

    def __str__(self):
        return f"{self.inspection_number} — {self.grn.grn_number}"

    def clean(self):
        from django.core.exceptions import ValidationError
        if self.sample_size_actual > 0 and self.batch_size > 0:
            if self.sample_size_actual > self.batch_size:
                raise ValidationError({'sample_size_actual': 'Cannot inspect more units than the batch size.'})
        if self.qc_override and not self.override_reason:
            raise ValidationError({'override_reason': 'Override reason is mandatory when overriding AQL recommendation.'})
        if self.battery_swelling_found and not self.bcr_triggered:
            pass  # BCR trigger is handled in view logic, not model

    def save(self, *args, **kwargs):
        if not self.inspection_number:
            today = timezone.now().strftime('%Y%m%d')
            count = IQCInspection.objects.filter(
                inspection_number__startswith=f'IQC-{today}'
            ).count() + 1
            self.inspection_number = f"IQC-{today}-{str(count).zfill(4)}"
        # Keep legacy fields in sync
        self.defects_found = self.critical_found + self.major_found + self.minor_found
        self.sample_size = self.sample_size_required
        self.aql_level = self.aql_level_used
        self.acceptance_number = self.accept_major
        super().save(*args, **kwargs)

    # Legacy fields kept for backward compatibility
    sample_size = models.IntegerField(default=0)
    aql_level = models.CharField(max_length=10, default='2.5')
    acceptance_number = models.IntegerField(default=0)

    def calculate_aql_recommendation(self):
        """
        Apply AQL formula to determine pass/fail recommendation.
        Zero tolerance on critical defects.
        """
        if self.critical_found > self.accept_critical:
            return 'fail'
        if self.major_found > self.accept_major:
            return 'fail'
        if self.minor_found > self.accept_minor:
            return 'fail'
        return 'pass'

    def load_aql_numbers(self):
        """Load sample size and acceptance numbers from AQLTable"""
        from apps.qc.models import AQLTable
        result = AQLTable.get_acceptance_numbers(
            self.batch_size, self.aql_level_used
        )
        if result:
            self.sample_size_required = result['sample_size']
            self.accept_critical = result['accept_critical']
            self.accept_major = result['accept_major']
            self.accept_minor = result['accept_minor']
            self.rejection_number = result['rejection_number']


class IQCDefect(models.Model):
    """Defect found during IQC inspection"""
    DEFECT_TYPE_CHOICES = (
        ('physical_damage',    'Physical Damage'),
        ('wrong_item',         'Wrong Item'),
        ('short_delivery',     'Short Delivery'),
        ('expired',            'Expired / Past shelf life'),
        ('functional_failure', 'Functional Failure'),
        ('labelling_error',    'Labelling Error'),
        ('cosmetic',           'Cosmetic Defect'),
        ('other',              'Other'),
    )

    inspection = models.ForeignKey(
        IQCInspection,
        on_delete=models.CASCADE,
        related_name='defects'
    )
    defect_type = models.CharField(
        max_length=30,
        choices=DEFECT_TYPE_CHOICES
    )
    quantity_affected = models.IntegerField(default=1)
    severity = models.CharField(
        max_length=10,
        choices=(
            ('critical', 'Critical'),
            ('major',    'Major'),
            ('minor',    'Minor'),
        ),
        default='major'
    )
    description = models.TextField()

    def __str__(self):
        return f"{self.get_defect_type_display()} × {self.quantity_affected}"


class Quarantine(models.Model):
    """
    Items that failed IQC — awaiting Factory Manager decision
    """
    DECISION_CHOICES = (
        ('return_supplier',      'Return to Supplier'),
        ('accept_with_discount', 'Accept with Discount'),
        ('scrap',                'Scrap'),
        ('pending',              'Pending Decision'),
    )

    quarantine_number = models.CharField(
        max_length=50, unique=True, db_index=True
    )
    grn = models.ForeignKey(
        GRN, on_delete=models.CASCADE, related_name='quarantines'
    )
    inspection = models.ForeignKey(
        IQCInspection,
        on_delete=models.SET_NULL,
        null=True, blank=True
    )
    product = models.ForeignKey(
        'inventory.Product',
        on_delete=models.PROTECT
    )
    quantity = models.DecimalField(max_digits=15, decimal_places=4)
    defect_summary = models.TextField()
    location = models.ForeignKey(
        'master.Bin',
        on_delete=models.SET_NULL,
        null=True, blank=True
    )
    decision = models.CharField(
        max_length=25,
        choices=DECISION_CHOICES,
        default='pending',
        db_index=True
    )
    decision_notes = models.TextField(blank=True)
    discount_percentage = models.DecimalField(
        max_digits=5, decimal_places=2,
        default=0,
        help_text='If accept with discount'
    )

    # Timeline
    deadline = models.DateTimeField(null=True, blank=True)
    status = models.CharField(
        max_length=10,
        choices=(
            ('pending',  'Pending Decision'),
            ('resolved', 'Resolved'),
        ),
        default='pending',
        db_index=True
    )

    # Alerts
    alert_sent = models.BooleanField(default=False)
    escalated = models.BooleanField(default=False)

    # Staff
    quarantined_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='quarantines_created'
    )
    decided_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='quarantine_decisions'
    )
    decided_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.quarantine_number} — {self.product.name}"

    def save(self, *args, **kwargs):
        if not self.quarantine_number:
            today = timezone.now().strftime('%Y%m%d')
            count = Quarantine.objects.filter(
                quarantine_number__startswith=f'QUAR-{today}'
            ).count() + 1
            self.quarantine_number = f"QUAR-{today}-{str(count).zfill(4)}"
        super().save(*args, **kwargs)

    @property
    def hours_in_quarantine(self):
        delta = timezone.now() - self.created_at
        return round(delta.total_seconds() / 3600, 1)

    @property
    def is_overdue(self):
        from apps.master.models import SystemSettings
        settings = SystemSettings.get_settings()
        return (
            self.status == 'pending' and
            self.hours_in_quarantine > settings.quarantine_alert_hours
        )
