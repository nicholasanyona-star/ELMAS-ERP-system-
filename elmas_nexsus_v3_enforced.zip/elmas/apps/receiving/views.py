"""ELMAS Receiving Views — Gate Entry, GRN, IQC"""
import json
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.utils import timezone
from django.db import transaction
from .models import GateEntry, GRN, GRNLine, GRNDiscrepancy, IQCInspection, IQCDefect, Quarantine
from apps.accounts.decorators import role_required
import logging
logger = logging.getLogger('elmas')


@login_required
@role_required('admin', 'receiving', 'warehouse', 'factory_manager')
def gate_list(request):
    today = timezone.now().date()
    gates = GateEntry.objects.select_related('registered_by').order_by('-time_in')
    date_filter = request.GET.get('date', str(today))
    try:
        from datetime import date
        fd = date.fromisoformat(date_filter)
        gates = gates.filter(time_in__date=fd)
    except Exception:
        gates = gates.filter(time_in__date=today)
    on_site = [g for g in gates if g.status != 'departed']
    departed = [g for g in gates if g.status == 'departed']
    return render(request, 'receiving/gate_list.html', {
        'gates': gates, 'date_filter': date_filter,
        'on_site_count': len(on_site),
        'departed_count': len(departed),
        'page_title': 'Gate Register',
    })


@login_required
@role_required('admin', 'receiving', 'warehouse')
def gate_create(request):
    if request.method == 'POST':
        try:
            entry = GateEntry.objects.create(
                supplier_name_manual=request.POST.get('supplier_name', '').strip(),
                driver_name=request.POST.get('driver_name', '').strip(),
                vehicle_plate=request.POST.get('vehicle_plate', '').strip().upper(),
                delivery_note_number=request.POST.get('delivery_note_number', '').strip(),
                number_of_cartons=int(request.POST.get('number_of_cartons', 0) or 0),
                notes=request.POST.get('notes', '').strip(),
                registered_by=request.user,
            )
            messages.success(request, f'✓ Gate entry {entry.gate_number} registered. Truck may proceed to Receiving Bay.')
            return redirect('receiving:gate_detail', pk=entry.pk)
        except Exception as e:
            messages.error(request, f'Error: {e}')
    return render(request, 'receiving/gate_form.html', {'page_title': 'New Gate Entry'})


@login_required
@role_required('admin', 'receiving', 'warehouse', 'factory_manager')
def gate_detail(request, pk):
    gate = get_object_or_404(GateEntry, pk=pk)
    grns = GRN.objects.filter(gate_entry=gate).select_related('received_by')
    return render(request, 'receiving/gate_detail.html', {
        'gate': gate, 'grns': grns, 'page_title': gate.gate_number,
    })


@login_required
@role_required('admin', 'receiving', 'warehouse')
def gate_depart(request, pk):
    gate = get_object_or_404(GateEntry, pk=pk)
    if request.method == 'POST':
        gate.status = 'departed'
        gate.time_out = timezone.now()
        gate.save()
        messages.success(request, f'Truck departure recorded for {gate.gate_number}.')
    return redirect('receiving:gate_detail', pk=pk)


@login_required
@role_required('admin', 'receiving', 'warehouse', 'factory_manager')
def grn_list(request):
    from django.core.paginator import Paginator
    grns = GRN.objects.select_related('received_by', 'supplier').order_by('-created_at')
    status_filter = request.GET.get('status', '')
    category_filter = request.GET.get('category', '')
    from_date = request.GET.get('from_date', '')
    to_date = request.GET.get('to_date', '')
    if status_filter:
        grns = grns.filter(status=status_filter)
    if category_filter:
        grns = grns.filter(material_category=category_filter)
    if from_date:
        grns = grns.filter(created_at__date__gte=from_date)
    if to_date:
        grns = grns.filter(created_at__date__lte=to_date)
    paginator = Paginator(grns, 25)
    page_obj = paginator.get_page(request.GET.get('page', 1))
    return render(request, 'receiving/grn_list.html', {
        'grns': page_obj, 'page_obj': page_obj,
        'status_filter': status_filter, 'category_filter': category_filter,
        'from_date': from_date, 'to_date': to_date,
        'page_title': 'Goods Received Notes',
        'status_choices': GRN.STATUS_CHOICES,
        'category_choices': GRN.CATEGORY_CHOICES,
    })


@login_required
@role_required('admin', 'receiving', 'warehouse')
def grn_create(request):
    if request.method == 'POST':
        try:
            category = request.POST.get('material_category')
            supplier_name = request.POST.get('supplier_name', '').strip()
            gate_pk = request.POST.get('gate_entry')
            gate = GateEntry.objects.filter(pk=gate_pk).first() if gate_pk else None
            grn = GRN.objects.create(
                material_category=category,
                supplier_name_manual=supplier_name,
                gate_entry=gate,
                purchase_order_ref=request.POST.get('purchase_order_ref', '').strip(),
                delivery_note_number=request.POST.get('delivery_note_number', '').strip(),
                notes=request.POST.get('notes', '').strip(),
                received_by=request.user,
            )
            messages.success(request, f'✓ GRN {grn.grn_number} created. Now add items below.')
            return redirect('receiving:grn_receive', pk=grn.pk)
        except Exception as e:
            messages.error(request, f'Error: {e}')
    today_gates = GateEntry.objects.filter(
        time_in__date=timezone.now().date(), status__in=['arrived', 'unloading']
    ).order_by('-time_in')
    # Pre-select gate if coming from gate detail page
    preselected_gate = request.GET.get('gate', '')
    return render(request, 'receiving/grn_create.html', {
        'page_title': 'New GRN — Select Category',
        'category_choices': GRN.CATEGORY_CHOICES,
        'today_gates': today_gates,
        'preselected_gate': preselected_gate,
    })


@login_required
@role_required('admin', 'receiving', 'warehouse')
def grn_receive(request, pk):
    """The main receiving page — handles scan, manual, excel line additions"""
    grn = get_object_or_404(GRN, pk=pk)
    if grn.status not in ('draft', 'discrepancy'):
        messages.info(request, 'This GRN is already submitted.')
        return redirect('receiving:grn_detail', pk=pk)

    if request.method == 'POST':
        entry_method = request.POST.get('entry_method', 'manual')

        if entry_method in ('scan', 'manual'):
            try:
                product_id = request.POST.get('product_id')
                barcode_val = request.POST.get('barcode_value', '').strip()
                new_name = request.POST.get('new_name', '').strip()
                new_uom = request.POST.get('new_uom', 'EA').strip() or 'EA'
                new_category = request.POST.get('new_category', grn.material_category)
                qty_expected = float(request.POST.get('qty_expected', 0) or 0)
                qty_received = float(request.POST.get('qty_received', 0) or 0)
                unit_cost = float(request.POST.get('unit_cost', 0) or 0)
                condition = request.POST.get('condition', 'good')
                batch_number = request.POST.get('batch_number', '').strip()
                expiry_date = request.POST.get('expiry_date') or None

                if qty_received <= 0:
                    messages.error(request, 'Quantity received must be greater than 0.')
                    return redirect('receiving:grn_receive', pk=pk)

                from apps.inventory.models import Product
                # Get or create product
                if product_id:
                    try:
                        product = Product.objects.get(pk=int(product_id))
                        # Update cost if provided
                        if unit_cost > 0 and product.unit_cost == 0:
                            product.unit_cost = unit_cost
                            product.save(update_fields=['unit_cost'])
                    except Product.DoesNotExist:
                        product = None
                else:
                    product = None

                if not product:
                    # Create new product from scan/manual
                    if not new_name:
                        if barcode_val:
                            new_name = f'Unknown Item — {barcode_val}'
                        else:
                            messages.error(request, 'Item name is required for new items.')
                            return redirect('receiving:grn_receive', pk=pk)
                    # If barcode provided, try to find by barcode first
                    if barcode_val:
                        product = Product.objects.filter(barcode=barcode_val).first()
                    # If still not found, try by name
                    if not product:
                        product = Product.objects.filter(name__iexact=new_name).first()
                    # If still not found, create new
                    if not product:
                        product = Product.objects.create(
                            name=new_name,
                            barcode=barcode_val if barcode_val else None,
                            category=grn.material_category,
                            uom=new_uom,
                            unit_cost=unit_cost,
                            item_type='battery' if 'battery' in new_name.lower() or 'batt' in new_name.lower() else 'general',
                        )

                # Create GRN line
                GRNLine.objects.create(
                    grn=grn,
                    product=product,
                    quantity_expected=qty_expected,
                    quantity_received=qty_received,
                    unit_cost=unit_cost,
                    condition=condition,
                    supplier_batch_number=batch_number,
                    expiry_date=expiry_date,
                    entry_method=entry_method,
                )

                # Record discrepancy if short or damaged
                if condition in ('damaged', 'short') or (qty_expected > 0 and qty_received < qty_expected):
                    # Get the line we just created
                    grn_line_obj = GRNLine.objects.filter(grn=grn).order_by('-id').first()
                    desc = (
                        f'Condition: {condition}. '
                        f'Expected: {qty_expected}, Received: {qty_received}. '
                        f'Item: {product.name}'
                    )
                    GRNDiscrepancy.objects.create(
                        grn=grn,
                        grn_line=grn_line_obj,
                        description=desc,
                        resolution='pending',
                    )

                messages.success(request, f'✓ {product.name} — {qty_received} {product.uom} added.')

            except Exception as e:
                logger.error(f'[grn_receive] {e}')
                messages.error(request, f'Error adding item: {e}')

        elif entry_method == 'excel':
            try:
                excel_file = request.FILES.get('excel_file')
                if not excel_file:
                    messages.error(request, 'Please select an Excel file.')
                    return redirect('receiving:grn_receive', pk=pk)

                import pandas as pd
                from apps.inventory.models import Product
                from django.db.models import Q

                if excel_file.name.endswith('.csv'):
                    df = pd.read_csv(excel_file)
                else:
                    df = pd.read_excel(excel_file)

                added = 0
                errors = 0
                for _, row in df.iterrows():
                    try:
                        # Try to get item name from common column names
                        name = None
                        for col in ['name', 'item', 'description', 'product', 'material', 'Name', 'Item', 'Description']:
                            if col in df.columns and str(row.get(col, '')).strip() not in ('', 'nan'):
                                name = str(row[col]).strip()
                                break
                        if not name:
                            name = str(row.iloc[0]).strip()

                        # Quantity
                        qty = 0
                        for col in ['qty', 'quantity', 'received', 'Qty', 'Quantity', 'Received']:
                            if col in df.columns:
                                try: qty = float(row[col]); break
                                except: pass
                        if qty <= 0:
                            try: qty = float(row.iloc[1])
                            except: pass

                        # Cost
                        cost = 0
                        for col in ['cost', 'price', 'unit_cost', 'Cost', 'Price']:
                            if col in df.columns:
                                try: cost = float(row[col]); break
                                except: pass

                        if not name or qty <= 0 or name in ('nan', 'None'):
                            continue

                        # Find or create product
                        product = Product.objects.filter(
                            Q(name__iexact=name) | Q(sku__iexact=name)
                        ).first()
                        if not product:
                            product = Product.objects.create(
                                name=name,
                                category=grn.material_category,
                                uom='EA',
                                unit_cost=cost,
                                item_type='battery' if 'battery' in name.lower() else 'general',
                            )

                        GRNLine.objects.create(
                            grn=grn,
                            product=product,
                            quantity_received=qty,
                            unit_cost=cost,
                            entry_method='excel',
                        )
                        added += 1
                    except Exception as row_e:
                        errors += 1
                        logger.warning(f'[grn_excel] row error: {row_e}')

                messages.success(request, f'✓ Excel uploaded: {added} items added.{f" {errors} rows skipped." if errors else ""}')

            except Exception as e:
                logger.error(f'[grn_excel] {e}')
                messages.error(request, f'Excel error: {e}. Check your file format.')

        return redirect('receiving:grn_receive', pk=pk)

    lines = grn.lines.select_related('product').order_by('created_at')
    return render(request, 'receiving/grn_receive.html', {
        'grn': grn, 'lines': lines, 'page_title': f'{grn.grn_number} — Receiving',
    })


@login_required
@role_required('admin', 'receiving', 'warehouse', 'factory_manager')
def grn_detail(request, pk):
    grn = get_object_or_404(GRN, pk=pk)
    lines = grn.lines.select_related('product').order_by('created_at')
    discrepancies = grn.discrepancies.all()
    iqc = IQCInspection.objects.filter(grn=grn).first()
    return render(request, 'receiving/grn_detail.html', {
        'grn': grn, 'lines': lines, 'discrepancies': discrepancies,
        'iqc': iqc, 'page_title': grn.grn_number,
    })


@login_required
@role_required('admin', 'receiving', 'warehouse')
def grn_submit(request, pk):
    """Submit GRN — creates stock batches in Waiting Bay"""
    grn = get_object_or_404(GRN, pk=pk)
    if request.method == 'POST':
        if grn.status != 'draft':
            messages.error(request, 'Only draft GRNs can be submitted.')
            return redirect('receiving:grn_detail', pk=pk)
        if not grn.lines.exists():
            messages.error(request, 'Cannot submit a GRN with no items.')
            return redirect('receiving:grn_receive', pk=pk)
        try:
            with transaction.atomic():
                # Create stock batches in waiting bay
                from apps.inventory.models import StockBatch
                from apps.master.models import Warehouse
                waiting_wh = Warehouse.objects.filter(warehouse_type='waiting').first()
                for line in grn.lines.all():
                    StockBatch.objects.create(
                        product=line.product,
                        grn_number=grn.grn_number,
                        warehouse=waiting_wh,
                        quantity_received=line.quantity_received,
                        remaining_quantity=line.quantity_received,
                        unit_cost=line.unit_cost,
                        supplier_batch_number=line.supplier_batch_number,
                        expiry_date=line.expiry_date,
                        status='waiting',
                        created_by=request.user,
                    )
                grn.status = 'submitted'
                grn.submitted_at = timezone.now()
                grn.save(update_fields=['status', 'submitted_at'])
                messages.success(request, f'✓ GRN {grn.grn_number} submitted. {grn.lines.count()} batches created in Waiting Bay. Warehouse Controller to verify.')
        except Exception as e:
            logger.error(f'[grn_submit] {e}')
            messages.error(request, f'Error submitting GRN: {e}')
    return redirect('receiving:grn_detail', pk=pk)


@login_required
@role_required('admin', 'warehouse')
def grn_verify(request, pk):
    """Warehouse Controller countersigns — moves to IQC queue"""
    grn = get_object_or_404(GRN, pk=pk)
    if request.method == 'POST':
        if grn.received_by == request.user:
            messages.error(request, '⚠ You cannot verify your own GRN. A different person must countersign.')
            return redirect('receiving:grn_detail', pk=pk)
        if grn.status != 'submitted':
            messages.error(request, 'Only submitted GRNs can be verified.')
            return redirect('receiving:grn_detail', pk=pk)
        grn.status = 'verified'
        grn.verified_by = request.user
        grn.verified_at = timezone.now()
        grn.save(update_fields=['status', 'verified_by', 'verified_at'])
        # Update batch status to iqc
        from apps.inventory.models import StockBatch
        batch_count = StockBatch.objects.filter(grn_number=grn.grn_number, status='waiting').update(status='iqc')
        # Auto-notify QC Officers
        try:
            from apps.messaging.models import Message, MessageRecipient
            from apps.accounts.models import User
            qc_officers = User.objects.filter(role='qc', is_active=True)
            for qc in qc_officers:
                msg = Message.objects.create(
                    sender=request.user,
                    subject=f'IQC Required: {grn.grn_number}',
                    body=f'GRN {grn.grn_number} has been verified and is ready for IQC inspection.\n\nSupplier: {grn.supplier_name}\nBatches: {batch_count}\n\nGo to QC → IQC to inspect.',
                    is_urgent=False,
                    ref_module='grn',
                    ref_number=grn.grn_number,
                )
                MessageRecipient.objects.create(message=msg, recipient=qc)
        except Exception:
            pass
        messages.success(request, f'✓ GRN {grn.grn_number} verified. {batch_count} batch(es) moved to IQC queue. QC Officers notified.')
    return redirect('receiving:grn_detail', pk=pk)


@login_required
@role_required('admin', 'receiving', 'warehouse', 'factory_manager', 'qc', 'procurement')
def grn_pdf(request, pk):
    grn = get_object_or_404(GRN, pk=pk)
    lines = grn.lines.select_related('product').all()
    return render(request, 'receiving/grn_pdf.html', {
        'grn': grn, 'lines': lines,
        'sys': __import__('apps.master.models', fromlist=['SystemSettings']).SystemSettings.get_settings(),
    })


@login_required
def product_lookup(request):
    """API: look up a product by barcode/SKU for GRN line entry"""
    q = request.GET.get('q', '').strip()
    if not q:
        return JsonResponse({'found': False, 'message': 'No search term provided'})
    from apps.inventory.models import Product
    from django.db.models import Q
    product = Product.objects.filter(
        Q(barcode=q) | Q(sku=q) | Q(sku__iexact=q)
    ).first()
    if product:
        return JsonResponse({
            'found': True,
            'id': product.pk,
            'name': product.name,
            'sku': product.sku,
            'uom': product.uom,
            'unit_cost': float(product.unit_cost),
            'category': product.get_category_display(),
            'item_type': product.item_type,
            'is_battery': product.is_battery,
        })
    return JsonResponse({
        'found': False,
        'barcode': q,
        'message': f'New item — barcode: {q}. Fill in details below.',
    })


@login_required
@role_required('admin', 'factory_manager')
def grn_cancel(request, pk):
    """Cancel a GRN — Factory Manager or Admin only"""
    from apps.inventory.models import StockBatch
    grn = get_object_or_404(GRN, pk=pk)
    if grn.status in ('verified', 'draft', 'submitted'):
        if request.method == 'POST':
            reason = request.POST.get('reason', '').strip()
            if not reason:
                messages.error(request, 'A reason is required to cancel a GRN.')
                return render(request, 'receiving/grn_cancel.html', {
                    'grn': grn, 'page_title': f'Cancel {grn.grn_number}'
                })
            from django.utils import timezone
            grn.status = 'cancelled'
            grn.cancel_reason = reason
            grn.cancelled_by = request.user
            grn.cancelled_at = timezone.now()
            grn.save(update_fields=['status', 'cancel_reason', 'cancelled_by', 'cancelled_at'])
            # If batches were already created, mark them inactive
            StockBatch.objects.filter(grn_number=grn.grn_number, status='waiting').update(status='depleted')
            messages.success(request, f'GRN {grn.grn_number} cancelled.')
            logger.info(f'[grn_cancel] {grn.grn_number} cancelled by {request.user} — {reason}')
            return redirect('receiving:grn_list')
        return render(request, 'receiving/grn_cancel.html', {
            'grn': grn, 'page_title': f'Cancel {grn.grn_number}'
        })
    else:
        messages.error(request, f'GRN {grn.grn_number} cannot be cancelled — status is {grn.get_status_display()}.')
        return redirect('receiving:grn_detail', pk=pk)


@login_required
@role_required('admin', 'receiving', 'warehouse')
def gate_unloading(request, pk):
    """Mark truck as unloading — in progress at receiving bay"""
    gate = get_object_or_404(GateEntry, pk=pk)
    if request.method == 'POST':
        if gate.status == 'arrived':
            gate.status = 'unloading'
            gate.save(update_fields=['status'])
            messages.success(request, f'{gate.gate_number} — truck is now unloading.')
        else:
            messages.info(request, f'Gate entry is already {gate.get_status_display()}.')
    return redirect('receiving:gate_detail', pk=pk)


@login_required
def gate_pdf(request, pk):
    """Printable gate pass document"""
    gate = get_object_or_404(GateEntry, pk=pk)
    grns = GRN.objects.filter(gate_entry=gate).prefetch_related('lines')
    from apps.master.models import SystemSettings
    return render(request, 'receiving/gate_pdf.html', {
        'gate': gate, 'grns': grns,
        'sys': SystemSettings.get_settings(),
    })


@login_required
@role_required('admin', 'receiving', 'warehouse')
def grn_delete_line(request, pk, line_pk):
    """Delete a line from a draft GRN"""
    grn = get_object_or_404(GRN, pk=pk)
    if grn.status != 'draft':
        messages.error(request, 'Lines can only be deleted from Draft GRNs.')
        return redirect('receiving:grn_receive', pk=pk)
    line = get_object_or_404(GRNLine, pk=line_pk, grn=grn)
    product_name = line.product.name if line.product else 'item'
    line.delete()
    messages.success(request, f'✓ {product_name} removed from GRN.')
    return redirect('receiving:grn_receive', pk=pk)
