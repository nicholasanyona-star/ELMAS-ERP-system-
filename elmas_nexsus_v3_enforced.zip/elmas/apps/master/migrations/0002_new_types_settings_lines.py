"""
ELMAS Master Migration 0002
- Add new warehouse types: battery, repair, aging, production
- Add new SystemSettings fields
- Add ProductionLine model
- Add RepairStation model
"""
from django.db import migrations, models
import django.db.models.deletion
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('master', '0001_initial'),
        ('accounts', '0003_new_roles_fields_auditlog'),
    ]

    operations = [

        # Update warehouse type choices
        migrations.AlterField(
            model_name='warehouse',
            name='warehouse_type',
            field=models.CharField(
                choices=[
                    ('receiving',    'Receiving Bay'),
                    ('waiting',      'Waiting Bay'),
                    ('iqc',          'IQC Area'),
                    ('raw_material', 'Raw Materials Warehouse'),
                    ('packaging',    'Packaging Warehouse'),
                    ('consumables',  'Consumables Warehouse'),
                    ('quarantine',   'Quarantine Bay'),
                    ('sfg',          'SFG Warehouse'),
                    ('fg',           'Finished Goods Warehouse'),
                    ('dispatch',     'Dispatch Bay'),
                    ('battery',      'Battery Store'),
                    ('repair',       'Repair Station Area'),
                    ('aging',        'Aging Room'),
                    ('production',   'Production Floor'),
                    ('other',        'Other'),
                ],
                default='other',
                max_length=20,
            ),
        ),

        # New SystemSettings fields
        migrations.AddField(
            model_name='systemsettings',
            name='high_defect_threshold_pct',
            field=models.IntegerField(default=10),
        ),
        migrations.AddField(
            model_name='systemsettings',
            name='line_stoppage_hours',
            field=models.IntegerField(default=2),
        ),
        migrations.AddField(
            model_name='systemsettings',
            name='aging_hours',
            field=models.IntegerField(default=8),
        ),
        migrations.AddField(
            model_name='systemsettings',
            name='repair_alert_hours',
            field=models.IntegerField(default=24),
        ),
        migrations.AddField(
            model_name='systemsettings',
            name='brn_pending_alert_mins',
            field=models.IntegerField(default=30),
        ),
        migrations.AddField(
            model_name='systemsettings',
            name='dispatch_fm_threshold',
            field=models.IntegerField(default=100),
        ),
        migrations.AddField(
            model_name='systemsettings',
            name='po_fm_threshold',
            field=models.IntegerField(default=50000),
        ),
        migrations.AddField(
            model_name='systemsettings',
            name='po_auto_approve_threshold',
            field=models.IntegerField(default=5000),
        ),
        migrations.AddField(
            model_name='systemsettings',
            name='fm_approval_expiry_hours',
            field=models.IntegerField(default=4),
        ),
        migrations.AddField(
            model_name='systemsettings',
            name='after_hours_start',
            field=models.TimeField(default='18:00'),
        ),
        migrations.AddField(
            model_name='systemsettings',
            name='after_hours_end',
            field=models.TimeField(default='06:00'),
        ),
        migrations.AddField(
            model_name='systemsettings',
            name='password_expiry_days',
            field=models.IntegerField(default=90),
        ),
        migrations.AddField(
            model_name='systemsettings',
            name='inactive_user_days',
            field=models.IntegerField(default=30),
        ),

        # ProductionLine model
        migrations.CreateModel(
            name='ProductionLine',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('code', models.CharField(db_index=True, max_length=10, unique=True)),
                ('name', models.CharField(max_length=100)),
                ('line_type', models.CharField(
                    choices=[('assembly', 'Assembly Line'), ('packaging', 'Packaging Line')],
                    max_length=10,
                )),
                ('status', models.CharField(
                    choices=[
                        ('active', 'Active'),
                        ('inactive', 'Inactive — not in use'),
                        ('maintenance', 'Under Maintenance'),
                    ],
                    default='inactive',
                    max_length=15,
                )),
                ('capacity_per_shift', models.IntegerField(default=200)),
                ('is_active', models.BooleanField(default=False)),
                ('is_system', models.BooleanField(default=True)),
                ('notes', models.TextField(blank=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('supervisor', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='supervised_lines',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('location', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    to='master.room',
                )),
            ],
            options={'ordering': ['line_type', 'code']},
        ),

        # RepairStation model
        migrations.CreateModel(
            name='RepairStation',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('code', models.CharField(db_index=True, max_length=10, unique=True)),
                ('name', models.CharField(max_length=100)),
                ('speciality', models.CharField(
                    choices=[
                        ('board_level', 'Board Level Repair'),
                        ('display',     'Display Replacement'),
                        ('mechanical',  'Mechanical Repair'),
                        ('software',    'Software / Firmware'),
                        ('battery',     'Battery Replacement'),
                        ('general',     'General Repair'),
                    ],
                    default='general',
                    max_length=15,
                )),
                ('status', models.CharField(
                    choices=[
                        ('active',      'Active'),
                        ('inactive',    'Inactive'),
                        ('maintenance', 'Under Maintenance'),
                    ],
                    default='active',
                    max_length=15,
                )),
                ('is_active', models.BooleanField(default=True)),
                ('notes', models.TextField(blank=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('technician', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='repair_stations',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('location', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    to='master.room',
                )),
            ],
            options={'ordering': ['code']},
        ),
    ]
