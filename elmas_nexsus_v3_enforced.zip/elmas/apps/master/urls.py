from django.urls import path
from . import views
app_name = 'master'
urlpatterns = [
    path('settings/', views.system_settings, name='settings'),
    path('warehouses/', views.warehouse_list, name='warehouse_list'),
    path('warehouses/create/', views.warehouse_create, name='warehouse_create'),
    path('warehouses/<int:pk>/edit/', views.warehouse_edit, name='warehouse_edit'),
    path('warehouses/<int:pk>/rooms/', views.room_list, name='room_list'),
    path('warehouses/<int:pk>/rooms/create/', views.room_create, name='room_create'),
    path('rooms/<int:pk>/edit/', views.room_edit, name='room_edit'),
    path('rooms/<int:pk>/zones/', views.zone_list, name='zone_list'),
    path('rooms/<int:pk>/zones/create/', views.zone_create, name='zone_create'),
    path('zones/<int:pk>/edit/', views.zone_edit, name='zone_edit'),
    path('zones/<int:pk>/bins/', views.bin_list, name='bin_list'),
    path('zones/<int:pk>/bins/create/', views.bin_create, name='bin_create'),
    path('bins/<int:pk>/edit/', views.bin_edit, name='bin_edit'),
]
