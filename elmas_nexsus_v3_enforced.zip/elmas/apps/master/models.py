"""
ELMAS Master Models
System settings, warehouse structure, locations
"""
from django.db import models
from django.conf import settings
from django.utils import timezone


class SystemSettings(models.Model):
    """
    Global system settings — one record only
    Managed by System Administrator
    """
    company_name = models.CharField(
        max_length=200,
        default='Ellams Smartphone Manufacturing Company'
    )
    company_address = models.TextField(blank=True)
    company_phone = models.CharField(max_length=50, blank=True)
    company_email = models.EmailField(blank=True)
    company_kra_pin = models.CharField(max_length=20, blank=True)
    logo = models.ImageField(
        upload_to='logos/',
        null=True, blank=True,
        help_text='Upload PNG or JPG logo. Appears on all pages and documents.'
    )
    vat_rate = models.DecimalField(
        max_digits=5, decimal_places=2, default=16.00,
        help_text='VAT rate in % e.g. 16 for 16%'
    )
    currency = models.CharField(max_length=10, default='Kshs')
    currency_code = models.CharField(max_length=5, default='KES')

    # Alert timers
    waiting_bay_alert_hours = models.IntegerField(
        default=4,
        help_text='Alert if items sit in waiting bay longer than this'
    )
    quarantine_alert_hours = models.IntegerField(
        default=48,
        help_text='Alert Factory Manager if quarantine not decided'
    )
    sfg_alert_hours = models.IntegerField(
        default=4,
        help_text='Alert if device in SFG longer than this'
    )
    sfg_escalate_hours = models.IntegerField(
        default=8,
        help_text='Escalate to Factory Manager if device in SFG longer'
    )
    mrn_approval_alert_hours = models.IntegerField(
        default=4,
        help_text='Alert if MRN not approved within this time'
    )
    battery_shelf_life_months = models.IntegerField(
        default=6,
        help_text='Alert when battery approaches this shelf life'
    )

    # Production alerts
    high_defect_threshold_pct = models.IntegerField(
        default=10,
        help_text='Alert FM when defect rate exceeds this % on any line'
    )
    line_stoppage_hours = models.IntegerField(
        default=2,
        help_text='Alert FM if no output logged on a line for this many hours'
    )
    aging_hours = models.IntegerField(
        default=8,
        help_text='Standard aging room duration in hours'
    )
    repair_alert_hours = models.IntegerField(
        default=24,
        help_text='Alert if unit in repair station longer than this'
    )
    brn_pending_alert_mins = models.IntegerField(
        default=30,
        help_text='Alert if battery pick pending longer than this (minutes)'
    )

    # FM approval thresholds
    dispatch_fm_threshold = models.IntegerField(
        default=100,
        help_text='DN qty above this requires FM countersign'
    )
    po_fm_threshold = models.IntegerField(
        default=50000,
        help_text='PO value (Kshs) above this requires FM approval'
    )
    po_auto_approve_threshold = models.IntegerField(
        default=5000,
        help_text='Consumable POs below this value auto-approved'
    )
    fm_approval_expiry_hours = models.IntegerField(
        default=4,
        help_text='FM approval queue items escalate to admin after this'
    )

    # Business hours
    after_hours_start = models.TimeField(
        default='18:00',
        help_text='After-hours period starts (system flags activity after this)'
    )
    after_hours_end = models.TimeField(
        default='06:00',
        help_text='After-hours period ends'
    )

    # Security
    password_expiry_days = models.IntegerField(
        default=90,
        help_text='Force password change after this many days'
    )
    inactive_user_days = models.IntegerField(
        default=30,
        help_text='Flag users inactive for this many days'
    )

    # System info
    system_name = models.CharField(max_length=50, default='ELMAS')
    system_version = models.CharField(max_length=20, default='1.0')
    updated_at = models.DateTimeField(auto_now=True)
    updated_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True
    )

    class Meta:
        verbose_name = 'System Settings'

    def __str__(self):
        return f"ELMAS Settings — {self.company_name}"

    @classmethod
    def get(cls):
        """Get or create the singleton settings object"""
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj

    @classmethod
    def get_settings(cls):
        """Alias for get() — used throughout the system"""
        return cls.get()


# ── WAREHOUSE STRUCTURE ───────────────────────────────────

class Warehouse(models.Model):
    """
    Top-level warehouse — e.g. Raw Materials Warehouse
    Created by system (pre-built) or Warehouse Controller
    """
    WAREHOUSE_TYPE_CHOICES = (
        ('receiving',    'Receiving Bay'),
        ('waiting',      'Waiting Bay'),
        ('iqc',          'IQC Area'),
        ('raw_material', 'Raw Materials Warehouse'),
        ('packaging',    'Packaging Warehouse'),
        ('consumables',  'Consumables Warehouse'),
        ('quarantine',   'Quarantine Bay'),
        ('sfg',          'SFG Warehouse'),
        ('fg',           'Finished Goods Warehouse'),
        ('dispatch',     'Dispatch Bay'),
        ('battery',      'Battery Store'),
        ('repair',       'Repair Station Area'),
        ('aging',        'Aging Room'),
        ('production',   'Production Floor'),
        ('other',        'Other'),
    )

    code = models.CharField(max_length=20, unique=True, db_index=True)
    name = models.CharField(max_length=100)
    warehouse_type = models.CharField(
        max_length=20,
        choices=WAREHOUSE_TYPE_CHOICES,
        default='other'
    )
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    is_system = models.BooleanField(
        default=False,
        help_text='Pre-built by system — cannot be deleted'
    )
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['code']

    def __str__(self):
        return f"{self.code} — {self.name}"


class Room(models.Model):
    """
    Physical room within a warehouse
    e.g. Battery Room within Raw Materials Warehouse
    """
    warehouse = models.ForeignKey(
        Warehouse,
        on_delete=models.CASCADE,
        related_name='rooms'
    )
    code = models.CharField(max_length=30, db_index=True)
    name = models.CharField(max_length=100)
    purpose = models.CharField(max_length=200, blank=True)
    is_active = models.BooleanField(default=True)
    is_system = models.BooleanField(default=False)
    safety_notes = models.TextField(
        blank=True,
        help_text='Safety warnings for dangerous rooms e.g. Battery Room'
    )
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['warehouse', 'code']
        unique_together = ['warehouse', 'code']

    def __str__(self):
        return f"{self.warehouse.code} / {self.code} — {self.name}"

    @property
    def full_code(self):
        return f"{self.warehouse.code}-{self.code}"


class Zone(models.Model):
    """
    Zone or Row within a Room
    e.g. Zone A (Good Stock) within Battery Room
    """
    ZONE_TYPE_CHOICES = (
        ('standard',    'Standard Storage'),
        ('good_stock',  'Good Stock'),
        ('quarantine',  'Quarantine/Hold'),
        ('defective',   'Defective ⚠'),
        ('returns',     'Returns'),
        ('staging',     'Staging Area'),
    )

    room = models.ForeignKey(
        Room,
        on_delete=models.CASCADE,
        related_name='zones'
    )
    code = models.CharField(max_length=30, db_index=True)
    name = models.CharField(max_length=100)
    zone_type = models.CharField(
        max_length=20,
        choices=ZONE_TYPE_CHOICES,
        default='standard'
    )
    is_active = models.BooleanField(default=True)
    is_system = models.BooleanField(default=False)
    is_locked = models.BooleanField(
        default=False,
        help_text='Locked zones cannot have stock issued from them'
    )
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['room', 'code']
        unique_together = ['room', 'code']

    def __str__(self):
        return f"{self.room.full_code}-{self.code} — {self.name}"

    @property
    def full_code(self):
        return f"{self.room.full_code}-{self.code}"


class Bin(models.Model):
    """
    Individual bin/slot/rack within a Zone
    The most granular location level
    """
    zone = models.ForeignKey(
        Zone,
        on_delete=models.CASCADE,
        related_name='bins'
    )
    code = models.CharField(max_length=30, db_index=True)
    name = models.CharField(max_length=100, blank=True)
    capacity = models.IntegerField(
        default=0,
        help_text='Maximum units. 0 = unlimited'
    )
    is_active = models.BooleanField(default=True)
    is_system = models.BooleanField(default=False)
    notes = models.CharField(max_length=255, blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['zone', 'code']
        unique_together = ['zone', 'code']

    def __str__(self):
        return self.full_code

    @property
    def full_code(self):
        return f"{self.zone.full_code}-{self.code}"

    @property
    def current_stock(self):
        """Total quantity currently in this bin"""
        from apps.inventory.models import StockBatch
        return StockBatch.objects.filter(
            bin=self, status='available'
        ).aggregate(
            total=models.Sum('remaining_quantity')
        )['total'] or 0


# ── PRODUCTION LINES ─────────────────────────────────────

class ProductionLine(models.Model):
    """
    Assembly and Packaging lines.
    Pre-loaded: AL-01 to AL-04 (assembly), PL-01 to PL-04 (packaging).
    Only one assembly + one packaging line active initially.
    """
    LINE_TYPE_CHOICES = (
        ('assembly',  'Assembly Line'),
        ('packaging', 'Packaging Line'),
    )
    STATUS_CHOICES = (
        ('active',      'Active'),
        ('inactive',    'Inactive — not in use'),
        ('maintenance', 'Under Maintenance'),
    )

    code = models.CharField(max_length=10, unique=True, db_index=True)
    name = models.CharField(max_length=100)
    line_type = models.CharField(max_length=10, choices=LINE_TYPE_CHOICES)
    status = models.CharField(
        max_length=15, choices=STATUS_CHOICES, default='inactive'
    )
    capacity_per_shift = models.IntegerField(
        default=200,
        help_text='Maximum units this line can produce per shift'
    )
    supervisor = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='supervised_lines',
        help_text='Assigned Production Supervisor'
    )
    location = models.ForeignKey(
        Room,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        help_text='Physical room in factory'
    )
    is_active = models.BooleanField(default=False)
    is_system = models.BooleanField(
        default=True,
        help_text='Pre-built by system'
    )
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['line_type', 'code']

    def __str__(self):
        return f"{self.code} — {self.name}"


class RepairStation(models.Model):
    """
    Dedicated repair station for defective units from QCII.
    """
    SPECIALITY_CHOICES = (
        ('board_level', 'Board Level Repair'),
        ('display',     'Display Replacement'),
        ('mechanical',  'Mechanical Repair'),
        ('software',    'Software / Firmware'),
        ('battery',     'Battery Replacement'),
        ('general',     'General Repair'),
    )
    STATUS_CHOICES = (
        ('active',      'Active'),
        ('inactive',    'Inactive'),
        ('maintenance', 'Under Maintenance'),
    )

    code = models.CharField(max_length=10, unique=True, db_index=True)
    name = models.CharField(max_length=100)
    speciality = models.CharField(
        max_length=15, choices=SPECIALITY_CHOICES, default='general'
    )
    status = models.CharField(
        max_length=15, choices=STATUS_CHOICES, default='active'
    )
    technician = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='repair_stations',
        help_text='Assigned Repair Technician'
    )
    location = models.ForeignKey(
        Room,
        on_delete=models.SET_NULL,
        null=True, blank=True
    )
    is_active = models.BooleanField(default=True)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['code']

    def __str__(self):
        return f"{self.code} — {self.name}"
