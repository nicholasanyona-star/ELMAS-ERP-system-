from django.contrib import admin
from .models import SystemSettings, Warehouse, Room, Zone, Bin


@admin.register(SystemSettings)
class SystemSettingsAdmin(admin.ModelAdmin):
    list_display = ('company_name', 'system_name', 'currency', 'updated_at')


@admin.register(Warehouse)
class WarehouseAdmin(admin.ModelAdmin):
    list_display = ('code', 'name', 'warehouse_type', 'is_active')
    list_filter = ('warehouse_type', 'is_active')
    search_fields = ('code', 'name')


@admin.register(Room)
class RoomAdmin(admin.ModelAdmin):
    list_display = ('code', 'name', 'warehouse', 'is_active')
    list_filter = ('is_active', 'warehouse')
    search_fields = ('code', 'name')


@admin.register(Zone)
class ZoneAdmin(admin.ModelAdmin):
    list_display = ('code', 'name', 'room', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('code', 'name')


@admin.register(Bin)
class BinAdmin(admin.ModelAdmin):
    list_display = ('code', 'name', 'zone', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('code', 'name')
