"""ELMAS Master Views — warehouse structure and system settings"""
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import SystemSettings, Warehouse, Room, Zone, Bin
from apps.accounts.decorators import role_required
import logging
logger = logging.getLogger('elmas')


@login_required
@role_required('admin')
def system_settings(request):
    s = SystemSettings.get_settings()
    if request.method == 'POST':
        s.company_name = request.POST.get('company_name', s.company_name).strip()
        s.company_address = request.POST.get('company_address', '').strip()
        s.company_phone = request.POST.get('company_phone', '').strip()
        s.company_email = request.POST.get('company_email', '').strip()
        s.company_kra_pin = request.POST.get('company_kra_pin', '').strip()
        try: s.vat_rate = float(request.POST.get('vat_rate', s.vat_rate))
        except: pass
        try: s.waiting_bay_alert_hours = int(request.POST.get('waiting_bay_alert_hours', s.waiting_bay_alert_hours))
        except: pass
        try: s.quarantine_alert_hours = int(request.POST.get('quarantine_alert_hours', s.quarantine_alert_hours))
        except: pass
        try: s.sfg_alert_hours = int(request.POST.get('sfg_alert_hours', s.sfg_alert_hours))
        except: pass
        if request.FILES.get('logo'):
            s.logo = request.FILES['logo']
        s.save()
        messages.success(request, '✓ Settings saved. Changes are live on all pages and documents.')
        return redirect('master:settings')
    return render(request, 'master/settings.html', {'settings': s, 'page_title': 'System Settings'})


@login_required
@role_required('admin', 'warehouse', 'factory_manager')
def warehouse_list(request):
    warehouses = Warehouse.objects.prefetch_related('rooms').order_by('code')
    return render(request, 'master/warehouse_list.html', {
        'warehouses': warehouses, 'page_title': 'Warehouse Management',
    })


@login_required
@role_required('admin', 'warehouse')
def warehouse_create(request):
    if request.method == 'POST':
        code = request.POST.get('code', '').strip().upper()
        name = request.POST.get('name', '').strip()
        wtype = request.POST.get('warehouse_type', 'other')
        description = request.POST.get('description', '').strip()
        if not code or not name:
            messages.error(request, 'Code and name are required.')
        elif Warehouse.objects.filter(code=code).exists():
            messages.error(request, f'Warehouse code "{code}" already exists.')
        else:
            Warehouse.objects.create(code=code, name=name, warehouse_type=wtype,
                                     description=description, created_by=request.user)
            messages.success(request, f'Warehouse {code} — {name} created.')
            return redirect('master:warehouse_list')
    return render(request, 'master/warehouse_form.html', {
        'wh_types': Warehouse.WAREHOUSE_TYPE_CHOICES, 'page_title': 'Create Warehouse', 'action': 'Create',
    })


@login_required
@role_required('admin', 'warehouse')
def warehouse_edit(request, pk):
    wh = get_object_or_404(Warehouse, pk=pk)
    if request.method == 'POST':
        wh.name = request.POST.get('name', wh.name).strip()
        wh.warehouse_type = request.POST.get('warehouse_type', wh.warehouse_type)
        wh.description = request.POST.get('description', '').strip()
        wh.is_active = request.POST.get('is_active') == 'on'
        wh.save()
        messages.success(request, f'Warehouse {wh.code} updated.')
        return redirect('master:warehouse_list')
    return render(request, 'master/warehouse_form.html', {
        'wh': wh, 'wh_types': Warehouse.WAREHOUSE_TYPE_CHOICES,
        'page_title': f'Edit {wh.code}', 'action': 'Save Changes',
    })


@login_required
@role_required('admin', 'warehouse', 'factory_manager')
def room_list(request, pk):
    wh = get_object_or_404(Warehouse, pk=pk)
    rooms = wh.rooms.prefetch_related('zones__bins').order_by('code')
    return render(request, 'master/room_list.html', {
        'wh': wh, 'rooms': rooms, 'page_title': f'{wh.name} — Rooms',
    })


@login_required
@role_required('admin', 'warehouse')
def room_create(request, pk):
    wh = get_object_or_404(Warehouse, pk=pk)
    if request.method == 'POST':
        code = request.POST.get('code', '').strip().upper()
        name = request.POST.get('name', '').strip()
        purpose = request.POST.get('purpose', '').strip()
        safety_notes = request.POST.get('safety_notes', '').strip()
        if not code or not name:
            messages.error(request, 'Code and name required.')
        elif Room.objects.filter(warehouse=wh, code=code).exists():
            messages.error(request, f'Room code "{code}" already exists in this warehouse.')
        else:
            Room.objects.create(warehouse=wh, code=code, name=name, purpose=purpose,
                               safety_notes=safety_notes, created_by=request.user)
            messages.success(request, f'Room {code} created in {wh.name}.')
            return redirect('master:room_list', pk=wh.pk)
    return render(request, 'master/room_form.html', {
        'wh': wh, 'page_title': f'Add Room to {wh.name}', 'action': 'Create',
    })


@login_required
@role_required('admin', 'warehouse')
def room_edit(request, pk):
    room = get_object_or_404(Room, pk=pk)
    if request.method == 'POST':
        room.name = request.POST.get('name', room.name).strip()
        room.purpose = request.POST.get('purpose', '').strip()
        room.safety_notes = request.POST.get('safety_notes', '').strip()
        room.is_active = request.POST.get('is_active') == 'on'
        room.save()
        messages.success(request, f'Room {room.code} updated.')
        return redirect('master:room_list', pk=room.warehouse.pk)
    return render(request, 'master/room_form.html', {
        'wh': room.warehouse, 'room': room, 'page_title': f'Edit Room {room.code}', 'action': 'Save',
    })


@login_required
@role_required('admin', 'warehouse', 'factory_manager')
def zone_list(request, pk):
    room = get_object_or_404(Room, pk=pk)
    zones = room.zones.prefetch_related('bins').order_by('code')
    return render(request, 'master/zone_list.html', {
        'room': room, 'zones': zones, 'page_title': f'{room.name} — Zones',
    })


@login_required
@role_required('admin', 'warehouse')
def zone_create(request, pk):
    room = get_object_or_404(Room, pk=pk)
    if request.method == 'POST':
        code = request.POST.get('code', '').strip().upper()
        name = request.POST.get('name', '').strip()
        zone_type = request.POST.get('zone_type', 'standard')
        is_locked = request.POST.get('is_locked') == 'on'
        if not code or not name:
            messages.error(request, 'Code and name required.')
        elif Zone.objects.filter(room=room, code=code).exists():
            messages.error(request, f'Zone code "{code}" already exists in this room.')
        else:
            Zone.objects.create(room=room, code=code, name=name, zone_type=zone_type,
                               is_locked=is_locked, created_by=request.user)
            messages.success(request, f'Zone {code} created.')
            return redirect('master:zone_list', pk=room.pk)
    return render(request, 'master/zone_form.html', {
        'room': room, 'zone_types': Zone.ZONE_TYPE_CHOICES,
        'page_title': f'Add Zone to {room.name}', 'action': 'Create',
    })


@login_required
@role_required('admin', 'warehouse')
def zone_edit(request, pk):
    zone = get_object_or_404(Zone, pk=pk)
    if request.method == 'POST':
        zone.name = request.POST.get('name', zone.name).strip()
        zone.zone_type = request.POST.get('zone_type', zone.zone_type)
        zone.is_locked = request.POST.get('is_locked') == 'on'
        zone.is_active = request.POST.get('is_active') == 'on'
        zone.save()
        messages.success(request, f'Zone {zone.code} updated.')
        return redirect('master:zone_list', pk=zone.room.pk)
    return render(request, 'master/zone_form.html', {
        'room': zone.room, 'zone': zone, 'zone_types': Zone.ZONE_TYPE_CHOICES,
        'page_title': f'Edit Zone {zone.code}', 'action': 'Save',
    })


@login_required
@role_required('admin', 'warehouse', 'factory_manager')
def bin_list(request, pk):
    zone = get_object_or_404(Zone, pk=pk)
    bins = zone.bins.order_by('code')
    return render(request, 'master/bin_list.html', {
        'zone': zone, 'bins': bins, 'page_title': f'{zone.name} — Bins',
    })


@login_required
@role_required('admin', 'warehouse')
def bin_create(request, pk):
    zone = get_object_or_404(Zone, pk=pk)
    if request.method == 'POST':
        code = request.POST.get('code', '').strip().upper()
        name = request.POST.get('name', '').strip()
        capacity = int(request.POST.get('capacity', 0) or 0)
        notes = request.POST.get('notes', '').strip()
        if not code:
            messages.error(request, 'Bin code required.')
        elif Bin.objects.filter(zone=zone, code=code).exists():
            messages.error(request, f'Bin code "{code}" already exists in this zone.')
        else:
            b = Bin.objects.create(zone=zone, code=code, name=name, capacity=capacity,
                                   notes=notes, created_by=request.user)
            messages.success(request, f'Bin {b.full_code} created.')
            return redirect('master:bin_list', pk=zone.pk)
    return render(request, 'master/bin_form.html', {
        'zone': zone, 'page_title': f'Add Bin to {zone.name}', 'action': 'Create',
    })


@login_required
@role_required('admin', 'warehouse')
def bin_edit(request, pk):
    b = get_object_or_404(Bin, pk=pk)
    if request.method == 'POST':
        b.name = request.POST.get('name', b.name).strip()
        b.capacity = int(request.POST.get('capacity', 0) or 0)
        b.notes = request.POST.get('notes', '').strip()
        b.is_active = request.POST.get('is_active') == 'on'
        b.save()
        messages.success(request, f'Bin {b.full_code} updated.')
        return redirect('master:bin_list', pk=b.zone.pk)
    return render(request, 'master/bin_form.html', {
        'zone': b.zone, 'bin': b, 'page_title': f'Edit Bin {b.full_code}', 'action': 'Save',
    })
