"""ELMAS Accounts Views"""
import logging
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from .models import User, LoginAttempt, AccountLock
from .decorators import role_required

logger = logging.getLogger('elmas')


def login_view(request):
    if request.user.is_authenticated:
        return redirect('/dashboard/')
    reason = request.GET.get('reason', '')
    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '')
        ip = request.META.get('REMOTE_ADDR', '')
        # Check if locked
        try:
            lock = AccountLock.objects.get(user__username=username, is_locked=True)
            if lock.locked_until and lock.locked_until > timezone.now():
                mins = int((lock.locked_until - timezone.now()).total_seconds() / 60)
                messages.error(request, f'Account locked. Try again in {mins} minutes.')
                return render(request, 'accounts/login.html', {'reason': reason})
            else:
                lock.is_locked = False
                lock.save()
        except AccountLock.DoesNotExist:
            pass
        user = authenticate(request, username=username, password=password)
        if user:
            if not user.is_active:
                messages.error(request, 'Account is deactivated. Contact System Administrator.')
                return render(request, 'accounts/login.html', {'reason': reason})
            # Clear failed attempts
            LoginAttempt.objects.filter(username=username, was_successful=False).delete()
            login(request, user)
            # Update session key for single session enforcement
            user.session_key = request.session.session_key
            user.last_activity = timezone.now()
            user.save(update_fields=['session_key', 'last_activity'])
            LoginAttempt.objects.create(username=username, ip_address=ip, was_successful=True)
            if user.force_password_change:
                messages.warning(request, 'Please change your password.')
                return redirect('accounts:change_password')
            return redirect(request.POST.get('next', '/dashboard/'))
        else:
            LoginAttempt.objects.create(username=username, ip_address=ip, was_successful=False)
            failed_count = LoginAttempt.objects.filter(username=username, was_successful=False).count()
            from django.conf import settings as dj_settings
            max_attempts = getattr(dj_settings, 'MAX_LOGIN_ATTEMPTS', 5)
            if failed_count >= max_attempts:
                try:
                    u = User.objects.get(username=username)
                    lock_mins = getattr(dj_settings, 'LOCKOUT_DURATION_MINUTES', 30)
                    AccountLock.objects.update_or_create(
                        user=u,
                        defaults={
                            'is_locked': True,
                            'locked_at': timezone.now(),
                            'locked_until': timezone.now() + timezone.timedelta(minutes=lock_mins),
                            'reason': 'Too many failed login attempts',
                        }
                    )
                    messages.error(request, f'Account locked after {max_attempts} failed attempts. Locked for {lock_mins} minutes.')
                except User.DoesNotExist:
                    pass
            else:
                remaining = max_attempts - failed_count
                messages.error(request, f'Invalid username or password. {remaining} attempt(s) remaining.')
    return render(request, 'accounts/login.html', {'reason': reason})


def logout_view(request):
    logout(request)
    return redirect('/accounts/login/')


@login_required
@role_required('admin')
def user_list(request):
    from apps.accounts.models import AccountLock, LoginAttempt
    role_filter = request.GET.get('role', '')
    users = User.objects.all().order_by('last_name', 'first_name')
    if role_filter:
        users = users.filter(role=role_filter)
    # Build lock status map
    locked_ids = set()
    for lock in AccountLock.objects.filter(is_locked=True).select_related('user'):
        if lock.is_active():
            locked_ids.add(lock.user_id)
    # Failed attempts per username
    failed_map = {}
    for attempt in LoginAttempt.objects.filter(was_successful=False).values('username'):
        failed_map[attempt['username']] = failed_map.get(attempt['username'], 0) + 1
    # Annotate users
    for u in users:
        u.is_account_locked = u.pk in locked_ids
        u.failed_attempts = failed_map.get(u.username, 0)
    all_users = User.objects.all()
    return render(request, 'accounts/user_list.html', {
        'users': users,
        'role_filter': role_filter,
        'roles': User.ROLE_CHOICES,
        'total_active': all_users.filter(is_active=True).count(),
        'total_inactive': all_users.filter(is_active=False).count(),
        'total_locked': len(locked_ids),
        'page_title': 'User Management',
    })


@login_required
@role_required('admin')
def user_create(request):
    if request.method == 'POST':
        try:
            username = request.POST['username'].strip()
            email = request.POST.get('email', '').strip()
            first_name = request.POST['first_name'].strip()
            last_name = request.POST['last_name'].strip()
            role = request.POST['role']
            password = request.POST['password']
            employee_id = request.POST.get('employee_id', '').strip() or None
            phone = request.POST.get('phone', '').strip()
            department = request.POST.get('department', '').strip()
            if User.objects.filter(username=username).exists():
                messages.error(request, f'Username "{username}" already exists.')
                return render(request, 'accounts/user_form.html', {
                    'roles': User.ROLE_CHOICES, 'page_title': 'Create User', 'form_data': request.POST,
                })
            user = User.objects.create_user(
                username=username, email=email, password=password,
                first_name=first_name, last_name=last_name,
                role=role, employee_id=employee_id, phone=phone,
                department=department, force_password_change=True,
            )
            messages.success(request, f'User {user.get_full_name()} created. They must change password on first login.')
            return redirect('accounts:user_list')
        except Exception as e:
            messages.error(request, f'Error creating user: {e}')
    return render(request, 'accounts/user_form.html', {
        'roles': User.ROLE_CHOICES, 'page_title': 'Create User',
    })


@login_required
@role_required('admin')
def user_edit(request, pk):
    user = get_object_or_404(User, pk=pk)
    if request.method == 'POST':
        user.first_name = request.POST.get('first_name', user.first_name)
        user.last_name = request.POST.get('last_name', user.last_name)
        user.email = request.POST.get('email', user.email)
        user.role = request.POST.get('role', user.role)
        user.phone = request.POST.get('phone', user.phone)
        user.department = request.POST.get('department', user.department)
        emp_id = request.POST.get('employee_id', '').strip()
        user.employee_id = emp_id or None
        user.save()
        messages.success(request, f'User {user.get_full_name()} updated.')
        return redirect('accounts:user_list')
    return render(request, 'accounts/user_form.html', {
        'user_obj': user, 'roles': User.ROLE_CHOICES, 'page_title': f'Edit {user.get_full_name()}',
    })


@login_required
@role_required('admin')
def reset_password(request, pk):
    user = get_object_or_404(User, pk=pk)
    if request.method == 'POST':
        new_password = request.POST.get('new_password', '').strip()
        if len(new_password) < 8:
            messages.error(request, 'Password must be at least 8 characters.')
            return render(request, 'accounts/reset_password.html', {'user_obj': user, 'page_title': 'Reset Password'})
        user.set_password(new_password)
        user.force_password_change = True
        user.save()
        # Unlock if locked
        AccountLock.objects.filter(user=user).update(is_locked=False)
        LoginAttempt.objects.filter(username=user.username, was_successful=False).delete()
        messages.success(request, f'Password reset for {user.get_full_name()}. They must change it on next login.')
        return redirect('accounts:user_list')
    return render(request, 'accounts/reset_password.html', {
        'user_obj': user, 'page_title': f'Reset Password — {user.get_full_name()}',
    })


@login_required
@role_required('admin')
def user_toggle(request, pk):
    user = get_object_or_404(User, pk=pk)
    if user == request.user:
        messages.error(request, 'You cannot deactivate your own account.')
        return redirect('accounts:user_list')
    if request.method == 'POST':
        user.is_active = not user.is_active
        user.save()
        action = 'activated' if user.is_active else 'deactivated'
        messages.success(request, f'Account {action} for {user.get_full_name()}.')
    return redirect('accounts:user_list')


@login_required
def profile(request):
    if request.method == 'POST':
        request.user.phone = request.POST.get('phone', request.user.phone)
        request.user.department = request.POST.get('department', request.user.department)
        request.user.save()
        messages.success(request, 'Profile updated.')
        return redirect('accounts:profile')
    return render(request, 'accounts/profile.html', {'page_title': 'My Profile'})


@login_required
def change_password(request):
    if request.method == 'POST':
        current = request.POST.get('current_password', '')
        new_pw = request.POST.get('new_password', '')
        confirm = request.POST.get('confirm_password', '')
        if not request.user.check_password(current) and not request.user.force_password_change:
            messages.error(request, 'Current password is incorrect.')
            return render(request, 'accounts/change_password.html', {'page_title': 'Change Password'})
        if len(new_pw) < 8:
            messages.error(request, 'New password must be at least 8 characters.')
            return render(request, 'accounts/change_password.html', {'page_title': 'Change Password'})
        if new_pw != confirm:
            messages.error(request, 'Passwords do not match.')
            return render(request, 'accounts/change_password.html', {'page_title': 'Change Password'})
        request.user.set_password(new_pw)
        request.user.force_password_change = False
        request.user.save()
        update_session_auth_hash(request, request.user)
        messages.success(request, 'Password changed successfully.')
        return redirect('/dashboard/')
    return render(request, 'accounts/change_password.html', {'page_title': 'Change Password'})


@login_required
@role_required('admin')
def user_unlock(request, pk):
    """Unlock an account locked by too many failed login attempts"""
    from apps.accounts.models import AccountLock, LoginAttempt
    user = get_object_or_404(User, pk=pk)
    if request.method == 'POST':
        try:
            lock = AccountLock.objects.get(user=user)
            lock.is_locked = False
            lock.save(update_fields=['is_locked'])
        except AccountLock.DoesNotExist:
            pass
        # Clear all failed login attempts for this user
        LoginAttempt.objects.filter(username=user.username, was_successful=False).delete()
        messages.success(request, f'Account unlocked for {user.get_full_name()}. They can now log in.')
    return redirect('accounts:user_list')

@login_required
@role_required('admin')
def user_detail(request, pk):
    """Admin view of a specific user — full profile + login history"""
    from apps.accounts.models import LoginAttempt, AccountLock
    user = get_object_or_404(User, pk=pk)
    login_history = LoginAttempt.objects.filter(
        username=user.username
    ).order_by('-attempted_at')[:20]
    try:
        lock = AccountLock.objects.get(user=user)
    except AccountLock.DoesNotExist:
        lock = None
    return render(request, 'accounts/user_detail.html', {
        'user_obj': user,
        'login_history': login_history,
        'lock': lock,
        'page_title': user.get_full_name(),
    })


@login_required
@role_required('admin')
def audit_log(request):
    """Show all login attempts — who logged in, when, from which IP"""
    from apps.accounts.models import LoginAttempt
    from django.core.paginator import Paginator
    attempts = LoginAttempt.objects.select_related().order_by('-attempted_at')
    user_filter = request.GET.get('user', '')
    status_filter = request.GET.get('status', '')
    if user_filter:
        attempts = attempts.filter(username__icontains=user_filter)
    if status_filter == 'failed':
        attempts = attempts.filter(was_successful=False)
    elif status_filter == 'success':
        attempts = attempts.filter(was_successful=True)
    paginator = Paginator(attempts, 50)
    page_obj = paginator.get_page(request.GET.get('page', 1))
    return render(request, 'accounts/audit_log.html', {
        'attempts': page_obj, 'page_obj': page_obj,
        'user_filter': user_filter, 'status_filter': status_filter,
        'page_title': 'Login Audit Log',
    })
