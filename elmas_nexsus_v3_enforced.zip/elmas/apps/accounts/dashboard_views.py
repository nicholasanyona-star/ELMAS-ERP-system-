"""ELMAS Dashboard Views — role-specific dashboards"""
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from datetime import timedelta
import logging
logger = logging.getLogger('elmas')


def _get_greeting():
    """Return time-appropriate greeting based on current hour"""
    hour = timezone.localtime(timezone.now()).hour
    if hour < 12:
        return 'Good morning'
    elif hour < 17:
        return 'Good afternoon'
    else:
        return 'Good evening'


@login_required
def dashboard(request):
    role = request.user.role
    # Inject greeting into request so templates can use it
    request.greeting = _get_greeting()
    dispatch = {
        'admin':           _dashboard_admin,
        'factory_manager': _dashboard_factory_manager,
        'warehouse':       _dashboard_warehouse,
        'receiving':       _dashboard_receiving,
        'qc':              _dashboard_qc,
        'qc2':             _dashboard_qc2,
        'pmc':             _dashboard_pmc,
        'production':      _dashboard_production,
        'procurement':     _dashboard_procurement,
        'dispatch':        _dashboard_dispatch,
    }
    view_fn = dispatch.get(role, _dashboard_default)
    return view_fn(request)


def _safe(fn, default=None):
    try:
        return fn()
    except Exception as e:
        logger.warning(f'[dashboard] {e}')
        return default


def _dashboard_admin(request):
    from apps.accounts.models import User, AccountLock, LoginAttempt
    from apps.receiving.models import GRN
    today = timezone.now().date()
    # Count actively locked accounts
    locked_count = 0
    try:
        locked_count = sum(1 for lock in AccountLock.objects.filter(is_locked=True).select_related('user') if lock.is_active())
    except Exception:
        pass
    ctx = {
        'page_title': 'System Administrator Dashboard',
        'total_users': _safe(lambda: User.objects.filter(is_active=True).count(), 0),
        'locked_accounts': locked_count,
        'inactive_users': _safe(lambda: User.objects.filter(is_active=False).count(), 0),
        'recent_grns': _safe(lambda: GRN.objects.order_by('-created_at')[:5], []),
        'users_by_role': _safe(lambda: [
            {'role': r[1], 'count': User.objects.filter(role=r[0], is_active=True).count()}
            for r in User.ROLE_CHOICES
        ], []),
        # System health
        'logins_today': _safe(lambda: LoginAttempt.objects.filter(
            attempted_at__date=today, was_successful=True).count(), 0),
        'failed_today': _safe(lambda: LoginAttempt.objects.filter(
            attempted_at__date=today, was_successful=False).count(), 0),
        'grns_today': _safe(lambda: GRN.objects.filter(created_at__date=today).count(), 0),
        'active_wos': _safe(lambda: __import__('apps.pmc.models', fromlist=['WorkOrder']).WorkOrder.objects.filter(
            status__in=['released', 'in_progress']).count(), 0),
        'fg_ready': _safe(lambda: __import__('apps.production.models', fromlist=['FinishedGood']).FinishedGood.objects.filter(
            status='oqc_passed').count(), 0),
        'open_shortages': _safe(lambda: __import__('apps.procurement.models', fromlist=['ShortageAlert']).ShortageAlert.objects.filter(
            status='open').count(), 0),
        'recent_logins': _safe(lambda: LoginAttempt.objects.filter(
            was_successful=True).order_by('-attempted_at')[:8], []),
    }
    return render(request, 'accounts/dashboard_admin.html', ctx)


def _dashboard_factory_manager(request):
    today = timezone.now().date()
    ctx = {'page_title': 'Factory Manager Dashboard'}
    ctx['grn_today'] = _safe(lambda: __import__('apps.receiving.models', fromlist=['GRN']).GRN.objects.filter(created_at__date=today).count(), 0)
    ctx['quarantine_open'] = _safe(lambda: __import__('apps.receiving.models', fromlist=['Quarantine']).Quarantine.objects.filter(status='pending').count(), 0)
    ctx['quarantine_overdue'] = _safe(lambda: __import__('apps.receiving.models', fromlist=['Quarantine']).Quarantine.objects.filter(status='pending', deadline__lt=timezone.now()).count(), 0)
    ctx['sfg_open'] = _safe(lambda: __import__('apps.qc.models', fromlist=['SFGUnit']).SFGUnit.objects.filter(status='in_sfg').count(), 0)
    ctx['sfg_overdue'] = _safe(lambda: __import__('apps.qc.models', fromlist=['SFGUnit']).SFGUnit.objects.filter(status='in_sfg', created_at__lt=timezone.now()-timedelta(hours=8)).count(), 0)
    return render(request, 'accounts/dashboard_factory_manager.html', ctx)


def _dashboard_warehouse(request):
    ctx = {'page_title': 'Warehouse Controller Dashboard'}
    ctx['pending_grn_verify'] = _safe(lambda: __import__('apps.receiving.models', fromlist=['GRN']).GRN.objects.filter(status='submitted').count(), 0)
    ctx['items_waiting_bay'] = _safe(lambda: __import__('apps.inventory.models', fromlist=['StockBatch']).StockBatch.objects.filter(status='waiting').count(), 0)
    ctx['pending_mrns'] = _safe(lambda: __import__('apps.pmc.models', fromlist=['MRN']).MRN.objects.filter(status='submitted').count(), 0)
    ctx['unsigned_sivs'] = _safe(lambda: __import__('apps.pmc.models', fromlist=['SIV']).SIV.objects.filter(is_signed=False).count(), 0)
    ctx['pending_handovers'] = _safe(lambda: __import__('apps.production.models', fromlist=['StageHandover']).StageHandover.objects.filter(countersigned_by__isnull=True).count(), 0)
    ctx['recent_mrns'] = _safe(lambda: __import__('apps.pmc.models', fromlist=['MRN']).MRN.objects.filter(status='submitted').select_related('work_order__bom', 'requested_by').order_by('-created_at')[:5], [])
    # FG store counts
    ctx['fg_total'] = _safe(lambda: __import__('apps.production.models', fromlist=['FinishedGood']).FinishedGood.objects.filter(status__in=['in_fg','oqc_pending','oqc_passed']).count(), 0)
    ctx['fg_oqc_pending'] = _safe(lambda: __import__('apps.production.models', fromlist=['FinishedGood']).FinishedGood.objects.filter(status='oqc_pending').count(), 0)
    ctx['fg_ready'] = _safe(lambda: __import__('apps.production.models', fromlist=['FinishedGood']).FinishedGood.objects.filter(status='oqc_passed').count(), 0)
    return render(request, 'accounts/dashboard_warehouse.html', ctx)


def _dashboard_receiving(request):
    today = timezone.now().date()
    ctx = {'page_title': 'Receiving Officer Dashboard'}
    ctx['my_draft_grns'] = _safe(lambda: __import__('apps.receiving.models', fromlist=['GRN']).GRN.objects.filter(received_by=request.user, status='draft').count(), 0)
    ctx['my_submitted_grns'] = _safe(lambda: __import__('apps.receiving.models', fromlist=['GRN']).GRN.objects.filter(received_by=request.user, status='submitted').count(), 0)
    ctx['today_gates'] = _safe(lambda: __import__('apps.receiving.models', fromlist=['GateEntry']).GateEntry.objects.filter(time_in__date=today).count(), 0)
    ctx['trucks_on_site'] = _safe(lambda: __import__('apps.receiving.models', fromlist=['GateEntry']).GateEntry.objects.filter(time_in__date=today, status__in=['arrived','unloading']).count(), 0)
    ctx['recent_gates'] = _safe(lambda: __import__('apps.receiving.models', fromlist=['GateEntry']).GateEntry.objects.filter(time_in__date=today).order_by('-time_in')[:8], [])
    return render(request, 'accounts/dashboard_receiving.html', ctx)


def _dashboard_qc(request):
    ctx = {'page_title': 'QC Officer Dashboard'}
    ctx['pending_iqc'] = _safe(lambda: __import__('apps.receiving.models', fromlist=['GRN']).GRN.objects.filter(status='verified').count(), 0)
    ctx['quarantine_open'] = _safe(lambda: __import__('apps.receiving.models', fromlist=['Quarantine']).Quarantine.objects.filter(status='pending').count(), 0)
    ctx['quarantine_overdue'] = _safe(lambda: __import__('apps.receiving.models', fromlist=['Quarantine']).Quarantine.objects.filter(status='pending', deadline__lt=timezone.now()).count(), 0)
    return render(request, 'accounts/dashboard_qc.html', ctx)


def _dashboard_qc2(request):
    ctx = {'page_title': 'QC II Officer Dashboard'}
    ctx['sfg_total'] = _safe(lambda: __import__('apps.qc.models', fromlist=['SFGUnit']).SFGUnit.objects.filter(status='in_sfg').count(), 0)
    ctx['sfg_over4h'] = _safe(lambda: __import__('apps.qc.models', fromlist=['SFGUnit']).SFGUnit.objects.filter(status='in_sfg', created_at__lt=timezone.now()-timedelta(hours=4)).count(), 0)
    ctx['sfg_over8h'] = _safe(lambda: __import__('apps.qc.models', fromlist=['SFGUnit']).SFGUnit.objects.filter(status='in_sfg', created_at__lt=timezone.now()-timedelta(hours=8)).count(), 0)
    ctx['sfg_units'] = _safe(lambda: __import__('apps.qc.models', fromlist=['SFGUnit']).SFGUnit.objects.filter(status='in_sfg').select_related('defect_code').order_by('created_at')[:10], [])
    return render(request, 'accounts/dashboard_qc2.html', ctx)


def _dashboard_pmc(request):
    ctx = {'page_title': 'PMC Officer Dashboard'}
    ctx['active_wos'] = _safe(lambda: __import__('apps.pmc.models', fromlist=['WorkOrder']).WorkOrder.objects.filter(status__in=['released','in_progress']).count(), 0)
    ctx['draft_wos'] = _safe(lambda: __import__('apps.pmc.models', fromlist=['WorkOrder']).WorkOrder.objects.filter(status='draft').count(), 0)
    ctx['pending_mrns'] = _safe(lambda: __import__('apps.pmc.models', fromlist=['MRN']).MRN.objects.filter(status='submitted').count(), 0)
    ctx['shortages'] = _safe(lambda: __import__('apps.procurement.models', fromlist=['ShortageAlert']).ShortageAlert.objects.filter(status='open').count(), 0)
    return render(request, 'accounts/dashboard_pmc.html', ctx)


def _dashboard_production(request):
    ctx = {'page_title': 'Production Supervisor Dashboard'}
    ctx['active_wos'] = _safe(lambda: __import__('apps.pmc.models', fromlist=['WorkOrder']).WorkOrder.objects.filter(status__in=['released','in_progress']).count(), 0)
    ctx['unsigned_handovers'] = _safe(lambda: __import__('apps.production.models', fromlist=['StageHandover']).StageHandover.objects.filter(countersigned_by__isnull=True).count(), 0)
    ctx['sfg_open'] = _safe(lambda: __import__('apps.qc.models', fromlist=['SFGUnit']).SFGUnit.objects.filter(status='in_sfg').count(), 0)
    ctx['fg_pending_oqc'] = _safe(lambda: __import__('apps.production.models', fromlist=['FinishedGood']).FinishedGood.objects.filter(status='oqc_pending').count(), 0)
    return render(request, 'accounts/dashboard_production.html', ctx)


def _dashboard_procurement(request):
    ctx = {'page_title': 'Procurement Officer Dashboard'}
    ctx['open_pos'] = _safe(lambda: __import__('apps.procurement.models', fromlist=['PurchaseOrder']).PurchaseOrder.objects.filter(status__in=['draft','sent','acknowledged']).count(), 0)
    ctx['shortages'] = _safe(lambda: __import__('apps.procurement.models', fromlist=['ShortageAlert']).ShortageAlert.objects.filter(status='open').count(), 0)
    ctx['zero_stock'] = _safe(lambda: sum(1 for p in __import__('apps.inventory.models', fromlist=['Product']).Product.objects.filter(is_active=True, reorder_point__gt=0) if p.current_stock == 0), 0)
    return render(request, 'accounts/dashboard_procurement.html', ctx)


def _dashboard_dispatch(request):
    ctx = {'page_title': 'Dispatch Officer Dashboard'}
    ctx['pending_orders'] = _safe(lambda: __import__('apps.dispatch.models', fromlist=['SalesOrder']).SalesOrder.objects.filter(status__in=['pending','confirmed']).count(), 0)
    ctx['draft_dns'] = _safe(lambda: __import__('apps.dispatch.models', fromlist=['DeliveryNote']).DeliveryNote.objects.filter(status='draft').count(), 0)
    ctx['dispatched_dns'] = _safe(lambda: __import__('apps.dispatch.models', fromlist=['DeliveryNote']).DeliveryNote.objects.filter(status='dispatched').count(), 0)
    ctx['oqc_passed'] = _safe(lambda: __import__('apps.production.models', fromlist=['FinishedGood']).FinishedGood.objects.filter(status='oqc_passed').count(), 0)
    return render(request, 'accounts/dashboard_dispatch.html', ctx)


def _dashboard_default(request):
    return render(request, 'accounts/dashboard_default.html', {'page_title': 'Dashboard'})
