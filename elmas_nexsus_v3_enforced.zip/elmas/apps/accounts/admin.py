from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, LoginAttempt, AccountLock, PasswordHistory


@admin.register(User)
class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'get_full_name', 'email', 'role', 'department', 'is_active', 'date_joined')
    list_filter = ('role', 'department', 'is_active', 'is_staff')
    search_fields = ('username', 'first_name', 'last_name', 'email', 'employee_id')
    ordering = ('last_name', 'first_name')
    fieldsets = UserAdmin.fieldsets + (
        ('ELMAS Profile', {'fields': ('role', 'department', 'phone', 'employee_id', 'force_password_change')}),
    )


@admin.register(LoginAttempt)
class LoginAttemptAdmin(admin.ModelAdmin):
    list_display = ('username', 'ip_address', 'was_successful', 'attempted_at')
    list_filter = ('was_successful',)
    search_fields = ('username', 'ip_address')
    ordering = ('-attempted_at',)


@admin.register(AccountLock)
class AccountLockAdmin(admin.ModelAdmin):
    list_display = ('user', 'is_locked', 'locked_until', 'locked_by_system')
    list_filter = ('is_locked', 'locked_by_system')
    search_fields = ('user__username',)


@admin.register(PasswordHistory)
class PasswordHistoryAdmin(admin.ModelAdmin):
    list_display = ('user', 'created_at')
    search_fields = ('user__username',)
    ordering = ('-created_at',)
