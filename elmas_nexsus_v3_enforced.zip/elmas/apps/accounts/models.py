"""
ELMAS Accounts Models
User model with 14 roles, login tracking, session management
"""
from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone


class User(AbstractUser):
    """
    ELMAS User — extends Django's AbstractUser
    with role-based access control
    """
    ROLE_CHOICES = (
        ('admin',              'System Administrator'),
        ('factory_manager',    'Factory Manager'),
        ('warehouse',          'Warehouse Controller'),
        ('receiving',          'Receiving Officer'),
        ('qc',                 'QC Officer'),
        ('qc2',                'QC II Officer'),
        ('pmc',                'PMC Officer'),
        ('production',         'Production Supervisor'),
        ('procurement',        'Procurement Officer'),
        ('dispatch',           'Dispatch Officer'),
        ('battery_controller', 'Battery Controller'),
        ('sfg_operator',       'SFG Operator'),
        ('repair',             'Repair Technician'),
        ('fg',                 'FG Controller'),
    )

    role = models.CharField(
        max_length=20,
        choices=ROLE_CHOICES,
        default='receiving',
        db_index=True
    )
    employee_id = models.CharField(max_length=50, blank=True, null=True, unique=True)
    department = models.CharField(max_length=100, blank=True)
    phone = models.CharField(max_length=20, blank=True)
    is_active = models.BooleanField(default=True)
    force_password_change = models.BooleanField(default=False)
    last_activity = models.DateTimeField(null=True, blank=True)
    last_password_change = models.DateTimeField(null=True, blank=True)
    session_key = models.CharField(max_length=100, blank=True, null=True)
    profile_photo = models.ImageField(
        upload_to='profiles/', null=True, blank=True
    )
    created_at = models.DateTimeField(auto_now_add=True)

    # Production assignment (production + repair roles)
    assigned_line = models.ForeignKey(
        'master.ProductionLine',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='assigned_users',
        help_text='Assigned production/packaging line (PS and repair roles)'
    )
    assigned_shift = models.CharField(
        max_length=10,
        choices=(
            ('morning',   'Morning Shift'),
            ('afternoon', 'Afternoon Shift'),
            ('night',     'Night Shift'),
            ('any',       'Any Shift'),
        ),
        default='any'
    )

    # FM substitute
    is_fm_substitute = models.BooleanField(
        default=False,
        help_text='Temporarily acting as Factory Manager'
    )
    fm_substitute_until = models.DateTimeField(
        null=True, blank=True,
        help_text='FM substitute authority expires at this time'
    )

    # Two-factor for FM financial actions
    requires_2fa = models.BooleanField(
        default=False,
        help_text='Requires PIN confirmation for financial actions'
    )
    two_fa_pin = models.CharField(
        max_length=255, blank=True,
        help_text='Hashed 6-digit PIN for financial action confirmation'
    )

    class Meta:
        verbose_name = 'User'
        verbose_name_plural = 'Users'
        ordering = ['last_name', 'first_name']

    def __str__(self):
        return f"{self.get_full_name() or self.username} ({self.get_role_display()})"

    def get_role_display_short(self):
        short = {
            'admin':              'Admin',
            'factory_manager':    'Factory Mgr',
            'warehouse':          'Warehouse',
            'receiving':          'Receiving',
            'qc':                 'QC Officer',
            'qc2':                'QC II',
            'pmc':                'PMC',
            'production':         'Production',
            'procurement':        'Procurement',
            'dispatch':           'Dispatch',
            'battery_controller': 'Battery Ctrl',
            'sfg_operator':       'SFG Operator',
            'repair':             'Repair Tech',
            'fg':                 'FG Controller',
        }
        return short.get(self.role, self.role)

    @property
    def is_admin(self):
        return self.role == 'admin' or self.is_superuser

    @property
    def is_factory_manager(self):
        return self.role == 'factory_manager'

    @property
    def is_acting_fm(self):
        """True if this user is currently acting as FM substitute"""
        if not self.is_fm_substitute:
            return False
        if self.fm_substitute_until and timezone.now() > self.fm_substitute_until:
            return False
        return True

    @property
    def has_fm_authority(self):
        """Factory Manager OR active FM substitute"""
        return self.is_factory_manager or self.is_acting_fm

    @property
    def can_see_all(self):
        """Factory Manager, FM substitute and Admin can see all departments"""
        return self.role in ('admin', 'factory_manager') or self.is_acting_fm or self.is_superuser

    @property
    def unread_message_count(self):
        return self.received_messages.filter(is_read=False, is_dismissed=False).count()


class LoginAttempt(models.Model):
    """Track failed login attempts for account lockout"""
    username = models.CharField(max_length=150, db_index=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    attempted_at = models.DateTimeField(auto_now_add=True)
    was_successful = models.BooleanField(default=False)

    class Meta:
        ordering = ['-attempted_at']

    def __str__(self):
        status = 'Success' if self.was_successful else 'Failed'
        return f"{self.username} — {status} — {self.attempted_at}"


class AccountLock(models.Model):
    """Track locked accounts"""
    user = models.OneToOneField(
        User, on_delete=models.CASCADE, related_name='lock'
    )
    is_locked = models.BooleanField(default=True)
    locked_at = models.DateTimeField(auto_now_add=True)
    locked_until = models.DateTimeField(null=True, blank=True)
    locked_by_system = models.BooleanField(default=True)
    reason = models.CharField(max_length=255, blank=True)

    def is_active(self):
        if not self.is_locked:
            return False
        if self.locked_until and timezone.now() > self.locked_until:
            return False
        return True

    def __str__(self):
        return f"{self.user.username} — {'LOCKED' if self.is_locked else 'unlocked'}"


class PasswordHistory(models.Model):
    """Track last 3 passwords to prevent reuse"""
    user = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='password_history'
    )
    password_hash = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.user.username} — {self.created_at}"


class AuditLog(models.Model):
    """
    Immutable record of all significant system actions.
    Cannot be deleted by any role including admin.
    Append-only — no update permissions.
    """
    ACTION_CHOICES = (
        # User management
        ('user_created',        'User Created'),
        ('user_role_changed',   'User Role Changed'),
        ('user_deactivated',    'User Deactivated'),
        ('user_activated',      'User Activated'),
        ('password_reset',      'Password Reset by Admin'),
        ('account_locked',      'Account Locked'),
        ('account_unlocked',    'Account Unlocked'),
        ('fm_substitute_set',   'FM Substitute Assigned'),
        # Financial approvals
        ('mrn_approved',        'MRN Approved'),
        ('mrn_rejected',        'MRN Rejected'),
        ('po_approved',         'PO Approved'),
        ('adjustment_approved', 'Stock Adjustment Approved'),
        ('adjustment_rejected', 'Stock Adjustment Rejected'),
        ('scrap_approved',      'Scrap Approved'),
        ('quarantine_decided',  'Quarantine Decision Made'),
        ('bcr_decided',         'BCR Decision Made'),
        ('dn_released',         'Delivery Note Released'),
        ('fifo_override',       'FIFO Override Approved'),
        ('brn_cancelled',       'BRN Cancelled'),
        # Security events
        ('after_hours_action',  'Action Performed After Hours'),
        ('fm_financial_action', 'FM Financial Action Confirmed'),
        ('pin_wrong',           'Wrong FM PIN Entered'),
        ('override_iqc',        'IQC Recommendation Overridden'),
    )

    action_type    = models.CharField(max_length=30, choices=ACTION_CHOICES, db_index=True)
    performed_by   = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='audit_actions'
    )
    performed_at   = models.DateTimeField(auto_now_add=True, db_index=True)
    ip_address     = models.GenericIPAddressField(null=True, blank=True)

    # What was affected
    target_user    = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='audit_targets'
    )
    document_type  = models.CharField(max_length=30, blank=True)
    document_ref   = models.CharField(max_length=100, blank=True)
    document_id    = models.IntegerField(null=True, blank=True)

    # Before/after for changes
    old_value      = models.TextField(blank=True)
    new_value      = models.TextField(blank=True)

    # Context
    notes          = models.TextField(blank=True)
    was_after_hours = models.BooleanField(default=False)

    class Meta:
        ordering = ['-performed_at']
        verbose_name = 'Audit Log'
        verbose_name_plural = 'Audit Logs'

    def __str__(self):
        return f"{self.action_type} by {self.performed_by} at {self.performed_at}"

    @classmethod
    def log(cls, action_type, performed_by, request=None, **kwargs):
        """Convenience method to create audit log entries"""
        from apps.master.models import SystemSettings
        ip = None
        if request:
            ip = request.META.get('REMOTE_ADDR')
        # Check if after hours
        was_after_hours = False
        try:
            s = SystemSettings.get_settings()
            now = timezone.localtime(timezone.now()).time()
            start = s.after_hours_start
            end = s.after_hours_end
            if start and end:
                if start > end:  # overnight e.g. 18:00 to 06:00
                    was_after_hours = now >= start or now <= end
                else:
                    was_after_hours = start <= now <= end
        except Exception:
            pass
        return cls.objects.create(
            action_type=action_type,
            performed_by=performed_by,
            ip_address=ip,
            was_after_hours=was_after_hours,
            **kwargs
        )
