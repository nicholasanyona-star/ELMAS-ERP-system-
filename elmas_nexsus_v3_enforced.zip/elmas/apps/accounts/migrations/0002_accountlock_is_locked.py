from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('accounts', '0001_initial'),
    ]
    operations = [
        migrations.AddField(
            model_name='accountlock',
            name='is_locked',
            field=models.BooleanField(default=True),
        ),
        migrations.AlterField(
            model_name='accountlock',
            name='locked_until',
            field=models.DateTimeField(null=True, blank=True),
        ),
    ]
