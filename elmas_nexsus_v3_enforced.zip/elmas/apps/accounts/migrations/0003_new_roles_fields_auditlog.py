"""
ELMAS Accounts Migration 0003
- Add new roles: battery_controller, sfg_operator, repair, fg
- Add new User fields: last_password_change, assigned_shift,
  is_fm_substitute, fm_substitute_until, requires_2fa, two_fa_pin
- Add assigned_line FK (deferred — ProductionLine added in production migration)
- Add AuditLog model
"""
from django.db import migrations, models
import django.db.models.deletion
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('accounts', '0002_accountlock_is_locked'),
    ]

    operations = [
        # Update role field max_length to accommodate new roles
        migrations.AlterField(
            model_name='user',
            name='role',
            field=models.CharField(
                choices=[
                    ('admin',              'System Administrator'),
                    ('factory_manager',    'Factory Manager'),
                    ('warehouse',          'Warehouse Controller'),
                    ('receiving',          'Receiving Officer'),
                    ('qc',                 'QC Officer'),
                    ('qc2',               'QC II Officer'),
                    ('pmc',               'PMC Officer'),
                    ('production',        'Production Supervisor'),
                    ('procurement',       'Procurement Officer'),
                    ('dispatch',          'Dispatch Officer'),
                    ('battery_controller','Battery Controller'),
                    ('sfg_operator',      'SFG Operator'),
                    ('repair',            'Repair Technician'),
                    ('fg',                'FG Controller'),
                ],
                db_index=True,
                default='receiving',
                max_length=20,
            ),
        ),

        # New User fields
        migrations.AddField(
            model_name='user',
            name='last_password_change',
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name='user',
            name='assigned_shift',
            field=models.CharField(
                choices=[
                    ('morning',   'Morning Shift'),
                    ('afternoon', 'Afternoon Shift'),
                    ('night',     'Night Shift'),
                    ('any',       'Any Shift'),
                ],
                default='any',
                max_length=10,
            ),
        ),
        migrations.AddField(
            model_name='user',
            name='is_fm_substitute',
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name='user',
            name='fm_substitute_until',
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name='user',
            name='requires_2fa',
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name='user',
            name='two_fa_pin',
            field=models.CharField(blank=True, max_length=255),
        ),

        # AuditLog model
        migrations.CreateModel(
            name='AuditLog',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('action_type', models.CharField(
                    choices=[
                        ('user_created',        'User Created'),
                        ('user_role_changed',   'User Role Changed'),
                        ('user_deactivated',    'User Deactivated'),
                        ('user_activated',      'User Activated'),
                        ('password_reset',      'Password Reset by Admin'),
                        ('account_locked',      'Account Locked'),
                        ('account_unlocked',    'Account Unlocked'),
                        ('fm_substitute_set',   'FM Substitute Assigned'),
                        ('mrn_approved',        'MRN Approved'),
                        ('mrn_rejected',        'MRN Rejected'),
                        ('po_approved',         'PO Approved'),
                        ('adjustment_approved', 'Stock Adjustment Approved'),
                        ('adjustment_rejected', 'Stock Adjustment Rejected'),
                        ('scrap_approved',      'Scrap Approved'),
                        ('quarantine_decided',  'Quarantine Decision Made'),
                        ('bcr_decided',         'BCR Decision Made'),
                        ('dn_released',         'Delivery Note Released'),
                        ('fifo_override',       'FIFO Override Approved'),
                        ('brn_cancelled',       'BRN Cancelled'),
                        ('after_hours_action',  'Action Performed After Hours'),
                        ('fm_financial_action', 'FM Financial Action Confirmed'),
                        ('pin_wrong',           'Wrong FM PIN Entered'),
                        ('override_iqc',        'IQC Recommendation Overridden'),
                    ],
                    db_index=True,
                    max_length=30,
                )),
                ('performed_at', models.DateTimeField(auto_now_add=True, db_index=True)),
                ('ip_address', models.GenericIPAddressField(blank=True, null=True)),
                ('document_type', models.CharField(blank=True, max_length=30)),
                ('document_ref', models.CharField(blank=True, max_length=100)),
                ('document_id', models.IntegerField(blank=True, null=True)),
                ('old_value', models.TextField(blank=True)),
                ('new_value', models.TextField(blank=True)),
                ('notes', models.TextField(blank=True)),
                ('was_after_hours', models.BooleanField(default=False)),
                ('performed_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='audit_actions',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('target_user', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='audit_targets',
                    to=settings.AUTH_USER_MODEL,
                )),
            ],
            options={
                'verbose_name': 'Audit Log',
                'verbose_name_plural': 'Audit Logs',
                'ordering': ['-performed_at'],
            },
        ),
    ]
