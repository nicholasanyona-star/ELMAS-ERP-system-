from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ("auth", "0012_alter_user_first_name_max_length"),
    ]

    operations = [
        migrations.CreateModel(
            name="User",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True)),
                ("password", models.CharField(max_length=128, verbose_name="password")),
                ("last_login", models.DateTimeField(blank=True, null=True)),
                ("is_superuser", models.BooleanField(default=False)),
                ("username", models.CharField(max_length=150, unique=True)),
                ("first_name", models.CharField(blank=True, max_length=150)),
                ("last_name", models.CharField(blank=True, max_length=150)),
                ("email", models.EmailField(blank=True)),
                ("is_staff", models.BooleanField(default=False)),
                ("is_active", models.BooleanField(default=True)),
                ("date_joined", models.DateTimeField(default=django.utils.timezone.now)),
                ("role", models.CharField(choices=[
                    ("admin","System Administrator"),("factory_manager","Factory Manager"),
                    ("warehouse","Warehouse Controller"),("receiving","Receiving Officer"),
                    ("qc","QC Officer"),("qc2","QC II Officer"),("pmc","PMC Officer"),
                    ("production","Production Supervisor"),("procurement","Procurement Officer"),
                    ("dispatch","Dispatch Officer"),
                ], db_index=True, default="receiving", max_length=20)),
                ("employee_id", models.CharField(blank=True, max_length=50, null=True, unique=True)),
                ("department", models.CharField(blank=True, max_length=100)),
                ("phone", models.CharField(blank=True, max_length=20)),
                ("force_password_change", models.BooleanField(default=False)),
                ("last_activity", models.DateTimeField(blank=True, null=True)),
                ("session_key", models.CharField(blank=True, max_length=100, null=True)),
                ("profile_photo", models.ImageField(blank=True, null=True, upload_to="profiles/")),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("groups", models.ManyToManyField(blank=True, related_name="user_set", to="auth.group")),
                ("user_permissions", models.ManyToManyField(blank=True, related_name="user_set", to="auth.permission")),
            ],
            options={"verbose_name":"User","verbose_name_plural":"Users","ordering":["last_name","first_name"]},
        ),
        migrations.CreateModel(
            name="LoginAttempt",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True)),
                ("username", models.CharField(db_index=True, max_length=150)),
                ("ip_address", models.GenericIPAddressField(blank=True, null=True)),
                ("attempted_at", models.DateTimeField(auto_now_add=True)),
                ("was_successful", models.BooleanField(default=False)),
            ],
            options={"ordering":["-attempted_at"]},
        ),
        migrations.CreateModel(
            name="AccountLock",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True)),
                ("locked_at", models.DateTimeField(auto_now_add=True)),
                ("locked_until", models.DateTimeField()),
                ("locked_by_system", models.BooleanField(default=True)),
                ("reason", models.CharField(blank=True, max_length=255)),
                ("user", models.OneToOneField(on_delete=django.db.models.deletion.CASCADE,
                    related_name="lock", to="accounts.user")),
            ],
        ),
        migrations.CreateModel(
            name="PasswordHistory",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True)),
                ("password_hash", models.CharField(max_length=255)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("user", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,
                    related_name="password_history", to="accounts.user")),
            ],
            options={"ordering":["-created_at"]},
        ),
    ]
