"""
ELMAS Accounts Migration 0004
Add assigned_line FK to User — depends on master.ProductionLine existing
"""
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('accounts', '0003_new_roles_fields_auditlog'),
        ('master', '0002_new_types_settings_lines'),
    ]

    operations = [
        migrations.AddField(
            model_name='user',
            name='assigned_line',
            field=models.ForeignKey(
                blank=True,
                help_text='Assigned production/packaging line (PS and repair roles)',
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='assigned_users',
                to='master.productionline',
            ),
        ),
    ]
