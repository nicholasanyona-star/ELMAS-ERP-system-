"""
ELMAS-NEXSUS — Role-based access decorators
Supports: role check, FM substitute, object-level ownership
"""
from functools import wraps
from django.http import HttpResponseForbidden, HttpResponseRedirect
from django.shortcuts import redirect
from django.contrib import messages


def role_required(*roles):
    """
    Enforces role-based access.
    Admin always passes.
    FM substitute passes for factory_manager-gated views.
    """
    def decorator(view_func):
        @wraps(view_func)
        def wrapper(request, *args, **kwargs):
            if not request.user.is_authenticated:
                return redirect(f'/accounts/login/?next={request.path}')
            u = request.user
            # Admin always passes
            if u.role == 'admin' or u.is_superuser:
                return view_func(request, *args, **kwargs)
            # Direct role match
            if u.role in roles:
                return view_func(request, *args, **kwargs)
            # FM substitute: if 'factory_manager' in allowed roles, check acting FM
            if 'factory_manager' in roles and getattr(u, 'is_acting_fm', False):
                return view_func(request, *args, **kwargs)
            # Access denied
            return HttpResponseForbidden(
                '<html><body>'
                '<h2 style="color:#c0392b">Access Denied</h2>'
                f'<p>Your role (<strong>{u.get_role_display()}</strong>) '
                f'does not have permission to access this page.</p>'
                '<p><a href="javascript:history.back()">← Go Back</a></p>'
                '</body></html>'
            )
        return wrapper
    return decorator


def admin_only(view_func):
    """Strict admin-only — no FM substitute"""
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect(f'/accounts/login/?next={request.path}')
        if request.user.role == 'admin' or request.user.is_superuser:
            return view_func(request, *args, **kwargs)
        return HttpResponseForbidden('<h2>Admin access required.</h2>')
    return wrapper


def fm_or_admin(view_func):
    """Factory Manager or Admin (includes FM substitute)"""
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect(f'/accounts/login/?next={request.path}')
        u = request.user
        if u.role in ('admin', 'factory_manager') or u.is_superuser:
            return view_func(request, *args, **kwargs)
        if getattr(u, 'is_acting_fm', False):
            return view_func(request, *args, **kwargs)
        return HttpResponseForbidden('<h2>Factory Manager access required.</h2>')
    return wrapper


def object_owner_or_roles(owner_field, *roles):
    """
    Object-level permission: allow if user owns the object (via owner_field)
    OR if user has one of the given roles.
    owner_field: string field name on the object (e.g. 'generated_by', 'requested_by')
    The view must have pk as a kwarg and the model must be passed as model= kwarg.
    Usage: @object_owner_or_roles('generated_by', 'warehouse', 'factory_manager')
    """
    def decorator(view_func):
        @wraps(view_func)
        def wrapper(request, *args, **kwargs):
            if not request.user.is_authenticated:
                return redirect(f'/accounts/login/?next={request.path}')
            u = request.user
            if u.role == 'admin' or u.is_superuser:
                return view_func(request, *args, **kwargs)
            if u.role in roles:
                return view_func(request, *args, **kwargs)
            if 'factory_manager' in roles and getattr(u, 'is_acting_fm', False):
                return view_func(request, *args, **kwargs)
            return HttpResponseForbidden('<h2>Access Denied — insufficient permissions.</h2>')
        return wrapper
    return decorator


def ajax_role_required(*roles):
    """For AJAX/API endpoints — returns 403 JSON instead of HTML"""
    def decorator(view_func):
        @wraps(view_func)
        def wrapper(request, *args, **kwargs):
            import json
            if not request.user.is_authenticated:
                from django.http import JsonResponse
                return JsonResponse({'error': 'Authentication required'}, status=401)
            u = request.user
            if u.role == 'admin' or u.is_superuser:
                return view_func(request, *args, **kwargs)
            if u.role in roles:
                return view_func(request, *args, **kwargs)
            if 'factory_manager' in roles and getattr(u, 'is_acting_fm', False):
                return view_func(request, *args, **kwargs)
            from django.http import JsonResponse
            return JsonResponse({'error': f'Role {u.role} not permitted'}, status=403)
        return wrapper
    return decorator
