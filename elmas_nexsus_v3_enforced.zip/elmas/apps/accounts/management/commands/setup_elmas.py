"""
ELMAS Setup Command
Creates all initial data:
  - System settings
  - Pre-built warehouse structure
  - 10 user accounts
  - AQL reference data
Run once after: python manage.py migrate
"""
from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from django.utils import timezone


class Command(BaseCommand):
    help = 'Initial ELMAS setup — run once after migrate'

    def handle(self, *args, **options):
        self.stdout.write('\n' + '='*55)
        self.stdout.write('  ELMAS — Ellams Manufacturing Automation System')
        self.stdout.write('  Initial Setup')
        self.stdout.write('='*55 + '\n')

        self._setup_system_settings()
        self._setup_warehouses()
        self._setup_users()
        self._setup_qc_data()
        self._setup_system_user()
        self._setup_production_lines()
        self._setup_repair_station()
        self._setup_new_roles_users()
        self._setup_chart_of_accounts()

        self.stdout.write('\n' + '='*55)
        self.stdout.write(
            self.style.SUCCESS(
                '  ✓ ELMAS setup complete!\n'
                '  Start server: python serve.py\n'
                '  Login at: http://localhost:8000\n'
                '  Admin: admin / Admin@ELMAS2024!'
            )
        )
        self.stdout.write('='*55 + '\n')

    def _setup_system_settings(self):
        from apps.master.models import SystemSettings
        settings, created = SystemSettings.objects.get_or_create(pk=1)
        if created:
            self.stdout.write(
                self.style.SUCCESS('  ✓ System settings created')
            )
        else:
            self.stdout.write('  = System settings already exist')

    def _setup_warehouses(self):
        from apps.master.models import Warehouse, Room, Zone, Bin

        structure = [
            {
                'code': 'REC-BAY',
                'name': 'Receiving Bay',
                'type': 'receiving',
                'rooms': [
                    {
                        'code': 'REC-AREA',
                        'name': 'Receiving Area',
                        'zones': [
                            {
                                'code': 'REC-Z1',
                                'name': 'Receiving Zone',
                                'type': 'staging',
                                'bins': ['DOCK-01', 'DOCK-02', 'DOCK-03']
                            }
                        ]
                    }
                ]
            },
            {
                'code': 'WAIT-BAY',
                'name': 'Waiting Bay',
                'type': 'waiting',
                'rooms': [
                    {
                        'code': 'HOLD-AREA',
                        'name': 'Holding Area',
                        'zones': [
                            {
                                'code': 'HOLD-Z1',
                                'name': 'General Holding',
                                'type': 'staging',
                                'bins': [
                                    'HOLD-01', 'HOLD-02', 'HOLD-03',
                                    'HOLD-04', 'HOLD-05'
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                'code': 'IQC-AREA',
                'name': 'IQC Inspection Area',
                'type': 'iqc',
                'rooms': [
                    {
                        'code': 'INSP-RM',
                        'name': 'Inspection Room',
                        'zones': [
                            {
                                'code': 'INSP-Z1',
                                'name': 'Inspection Zone',
                                'type': 'staging',
                                'bins': [
                                    'BENCH-01', 'BENCH-02', 'BENCH-03'
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                'code': 'RM-STORE',
                'name': 'Raw Materials Warehouse',
                'type': 'raw_material',
                'rooms': [
                    {
                        'code': 'RM-R01',
                        'name': 'General Components Room',
                        'zones': [
                            {
                                'code': 'ROW-A',
                                'name': 'Row A',
                                'type': 'standard',
                                'bins': [
                                    'BIN-A1', 'BIN-A2', 'BIN-A3',
                                    'BIN-A4', 'BIN-A5'
                                ]
                            },
                            {
                                'code': 'ROW-B',
                                'name': 'Row B',
                                'type': 'standard',
                                'bins': [
                                    'BIN-B1', 'BIN-B2', 'BIN-B3',
                                    'BIN-B4', 'BIN-B5'
                                ]
                            },
                            {
                                'code': 'ROW-C',
                                'name': 'Row C',
                                'type': 'standard',
                                'bins': [
                                    'BIN-C1', 'BIN-C2', 'BIN-C3',
                                    'BIN-C4', 'BIN-C5'
                                ]
                            }
                        ]
                    },
                    {
                        'code': 'BAT-RM',
                        'name': 'Battery Room',
                        'purpose': 'Dedicated battery storage — fire safety zone',
                        'safety': 'DANGER: Battery storage. No naked flame. Fire extinguisher required. Max 500 units per bin.',
                        'zones': [
                            {
                                'code': 'ZONE-A',
                                'name': 'Zone A — Good Stock',
                                'type': 'good_stock',
                                'bins': [
                                    'BIN-A1', 'BIN-A2', 'BIN-A3',
                                    'BIN-B1', 'BIN-B2', 'BIN-B3'
                                ]
                            },
                            {
                                'code': 'ZONE-B',
                                'name': 'Zone B — Quarantine / Hold',
                                'type': 'quarantine',
                                'bins': ['HOLD-01', 'HOLD-02', 'HOLD-03']
                            },
                            {
                                'code': 'ZONE-C',
                                'name': 'Zone C — Defective ⚠',
                                'type': 'defective',
                                'bins': [
                                    'DAMAGED-01', 'DAMAGED-02', 'DAMAGED-03'
                                ]
                            },
                            {
                                'code': 'ZONE-D',
                                'name': 'Zone D — Returns from SFG',
                                'type': 'returns',
                                'bins': ['RETURN-01', 'RETURN-02']
                            }
                        ]
                    }
                ]
            },
            {
                'code': 'PKG-STORE',
                'name': 'Packaging Warehouse',
                'type': 'packaging',
                'rooms': [
                    {
                        'code': 'PKG-R01',
                        'name': 'Packaging Materials Room',
                        'zones': [
                            {
                                'code': 'ROW-A',
                                'name': 'Row A',
                                'type': 'standard',
                                'bins': [
                                    'BIN-A1', 'BIN-A2', 'BIN-A3',
                                    'BIN-A4', 'BIN-A5'
                                ]
                            },
                            {
                                'code': 'ROW-B',
                                'name': 'Row B',
                                'type': 'standard',
                                'bins': [
                                    'BIN-B1', 'BIN-B2', 'BIN-B3',
                                    'BIN-B4', 'BIN-B5'
                                ]
                            },
                            {
                                'code': 'ROW-C',
                                'name': 'Row C',
                                'type': 'standard',
                                'bins': [
                                    'BIN-C1', 'BIN-C2', 'BIN-C3',
                                    'BIN-C4', 'BIN-C5'
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                'code': 'CONS-STORE',
                'name': 'Consumables Warehouse',
                'type': 'consumables',
                'rooms': [
                    {
                        'code': 'CONS-R01',
                        'name': 'Consumables Store',
                        'zones': [
                            {
                                'code': 'ROW-A',
                                'name': 'Row A',
                                'type': 'standard',
                                'bins': [
                                    'BIN-A1', 'BIN-A2', 'BIN-A3',
                                    'BIN-A4', 'BIN-A5'
                                ]
                            },
                            {
                                'code': 'ROW-B',
                                'name': 'Row B',
                                'type': 'standard',
                                'bins': [
                                    'BIN-B1', 'BIN-B2', 'BIN-B3',
                                    'BIN-B4', 'BIN-B5'
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                'code': 'QUAR-BAY',
                'name': 'Quarantine Bay',
                'type': 'quarantine',
                'rooms': [
                    {
                        'code': 'QUAR-R01',
                        'name': 'General Quarantine',
                        'zones': [
                            {
                                'code': 'QUAR-Z1',
                                'name': 'Quarantine Zone',
                                'type': 'quarantine',
                                'bins': [
                                    'Q-BIN-01', 'Q-BIN-02', 'Q-BIN-03',
                                    'Q-BIN-04', 'Q-BIN-05', 'Q-BIN-06',
                                    'Q-BIN-07', 'Q-BIN-08', 'Q-BIN-09',
                                    'Q-BIN-10'
                                ]
                            }
                        ]
                    },
                    {
                        'code': 'QUAR-BAT',
                        'name': 'Battery Quarantine',
                        'safety': 'Battery quarantine — fire safety rules apply',
                        'zones': [
                            {
                                'code': 'BAT-Q1',
                                'name': 'Battery Quarantine Zone',
                                'type': 'quarantine',
                                'bins': [
                                    'QB-01', 'QB-02', 'QB-03',
                                    'QB-04', 'QB-05'
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                'code': 'SFG-STORE',
                'name': 'SFG Warehouse',
                'type': 'sfg',
                'rooms': [
                    {
                        'code': 'SFG-ASM',
                        'name': 'Assembly Defects Room',
                        'purpose': 'Devices from Assembly Line',
                        'zones': [
                            {
                                'code': 'ROW-A',
                                'name': 'Row A',
                                'type': 'standard',
                                'bins': [
                                    'RACK-A1', 'RACK-A2', 'RACK-A3'
                                ]
                            },
                            {
                                'code': 'ROW-B',
                                'name': 'Row B',
                                'type': 'standard',
                                'bins': [
                                    'RACK-B1', 'RACK-B2', 'RACK-B3'
                                ]
                            }
                        ]
                    },
                    {
                        'code': 'SFG-AGE',
                        'name': 'Aging Defects Room',
                        'purpose': 'Devices from Aging Room',
                        'zones': [
                            {
                                'code': 'ROW-A',
                                'name': 'Row A',
                                'type': 'standard',
                                'bins': [
                                    'RACK-A1', 'RACK-A2', 'RACK-A3'
                                ]
                            },
                            {
                                'code': 'ROW-B',
                                'name': 'Row B',
                                'type': 'standard',
                                'bins': [
                                    'RACK-B1', 'RACK-B2', 'RACK-B3'
                                ]
                            }
                        ]
                    },
                    {
                        'code': 'SFG-PKG',
                        'name': 'Packaging Defects Room',
                        'purpose': 'Devices from Packaging Line',
                        'zones': [
                            {
                                'code': 'ROW-A',
                                'name': 'Row A',
                                'type': 'standard',
                                'bins': [
                                    'RACK-A1', 'RACK-A2', 'RACK-A3'
                                ]
                            },
                            {
                                'code': 'ROW-B',
                                'name': 'Row B',
                                'type': 'standard',
                                'bins': [
                                    'RACK-B1', 'RACK-B2', 'RACK-B3'
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                'code': 'FG-STORE',
                'name': 'Finished Goods Warehouse',
                'type': 'fg',
                'rooms': [
                    {
                        'code': 'FG-R01',
                        'name': 'Finished Goods Store',
                        'zones': [
                            {
                                'code': 'ROW-A',
                                'name': 'Row A',
                                'type': 'standard',
                                'bins': [
                                    'BIN-A1', 'BIN-A2', 'BIN-A3',
                                    'BIN-A4', 'BIN-A5'
                                ]
                            },
                            {
                                'code': 'ROW-B',
                                'name': 'Row B',
                                'type': 'standard',
                                'bins': [
                                    'BIN-B1', 'BIN-B2', 'BIN-B3',
                                    'BIN-B4', 'BIN-B5'
                                ]
                            },
                            {
                                'code': 'ROW-C',
                                'name': 'Row C',
                                'type': 'standard',
                                'bins': [
                                    'BIN-C1', 'BIN-C2', 'BIN-C3',
                                    'BIN-C4', 'BIN-C5'
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                'code': 'DISP-BAY',
                'name': 'Dispatch Bay',
                'type': 'dispatch',
                'rooms': [
                    {
                        'code': 'LOAD-AREA',
                        'name': 'Loading Area',
                        'zones': [
                            {
                                'code': 'DOCK-Z1',
                                'name': 'Loading Docks',
                                'type': 'staging',
                                'bins': [
                                    'DOCK-01', 'DOCK-02', 'DOCK-03'
                                ]
                            }
                        ]
                    }
                ]
            }
        ]

        created_count = 0
        for wh_data in structure:
            wh, wh_created = Warehouse.objects.get_or_create(
                code=wh_data['code'],
                defaults={
                    'name': wh_data['name'],
                    'warehouse_type': wh_data['type'],
                    'is_system': True,
                    'is_active': True,
                }
            )
            if wh_created:
                created_count += 1

            for rm_data in wh_data.get('rooms', []):
                rm, _ = Room.objects.get_or_create(
                    warehouse=wh,
                    code=rm_data['code'],
                    defaults={
                        'name': rm_data['name'],
                        'purpose': rm_data.get('purpose', ''),
                        'safety_notes': rm_data.get('safety', ''),
                        'is_system': True,
                        'is_active': True,
                    }
                )

                for zn_data in rm_data.get('zones', []):
                    zn, _ = Zone.objects.get_or_create(
                        room=rm,
                        code=zn_data['code'],
                        defaults={
                            'name': zn_data['name'],
                            'zone_type': zn_data.get('type', 'standard'),
                            'is_system': True,
                            'is_active': True,
                        }
                    )

                    for bin_code in zn_data.get('bins', []):
                        Bin.objects.get_or_create(
                            zone=zn,
                            code=bin_code,
                            defaults={
                                'is_system': True,
                                'is_active': True,
                            }
                        )

        self.stdout.write(
            self.style.SUCCESS(
                f'  ✓ Warehouse structure ready — '
                f'{created_count} warehouses created'
            )
        )

    def _setup_users(self):
        User = get_user_model()

        users = [
            {
                'username': 'admin',
                'password': 'Admin@ELMAS2024!',
                'first_name': 'System',
                'last_name': 'Administrator',
                'role': 'admin',
                'employee_id': 'EMP-001',
                'is_superuser': True,
                'is_staff': True,
            },
            {
                'username': 'factory_manager',
                'password': 'ELMAS2024!',
                'first_name': 'Factory',
                'last_name': 'Manager',
                'role': 'factory_manager',
                'employee_id': 'EMP-002',
            },
            {
                'username': 'warehouse',
                'password': 'ELMAS2024!',
                'first_name': 'Warehouse',
                'last_name': 'Controller',
                'role': 'warehouse',
                'employee_id': 'EMP-003',
            },
            {
                'username': 'receiving',
                'password': 'ELMAS2024!',
                'first_name': 'Receiving',
                'last_name': 'Officer',
                'role': 'receiving',
                'employee_id': 'EMP-004',
            },
            {
                'username': 'qc',
                'password': 'ELMAS2024!',
                'first_name': 'QC',
                'last_name': 'Officer',
                'role': 'qc',
                'employee_id': 'EMP-005',
            },
            {
                'username': 'qc2',
                'password': 'ELMAS2024!',
                'first_name': 'QC II',
                'last_name': 'Officer',
                'role': 'qc2',
                'employee_id': 'EMP-006',
            },
            {
                'username': 'pmc',
                'password': 'ELMAS2024!',
                'first_name': 'PMC',
                'last_name': 'Officer',
                'role': 'pmc',
                'employee_id': 'EMP-007',
            },
            {
                'username': 'production',
                'password': 'ELMAS2024!',
                'first_name': 'Production',
                'last_name': 'Supervisor',
                'role': 'production',
                'employee_id': 'EMP-008',
            },
            {
                'username': 'procurement',
                'password': 'ELMAS2024!',
                'first_name': 'Procurement',
                'last_name': 'Officer',
                'role': 'procurement',
                'employee_id': 'EMP-009',
            },
            {
                'username': 'dispatch',
                'password': 'ELMAS2024!',
                'first_name': 'Dispatch',
                'last_name': 'Officer',
                'role': 'dispatch',
                'employee_id': 'EMP-010',
            },
        ]

        created = 0
        for u in users:
            password = u.pop('password')
            is_superuser = u.pop('is_superuser', False)
            is_staff = u.pop('is_staff', False)

            user, user_created = User.objects.get_or_create(
                username=u['username'],
                defaults={**u, 'is_superuser': is_superuser,
                          'is_staff': is_staff}
            )
            if user_created:
                user.set_password(password)
                user.save()
                created += 1

        self.stdout.write(
            self.style.SUCCESS(
                f'  ✓ {created} user accounts created'
            )
        )
        self.stdout.write(
            '  Default credentials:\n'
            '    admin          / Admin@ELMAS2024!\n'
            '    factory_manager / ELMAS2024!\n'
            '    warehouse      / ELMAS2024!\n'
            '    [all others]   / ELMAS2024!\n'
            '  ⚠ Change all passwords after first login!'
        )

    def _setup_qc_data(self):
        from apps.qc.models import AQLTable, DefectCode, SFGDefectCode

        # AQL Tables
        aql_data = [
            (1, 8, 3, 0, 0, 1), (9, 15, 5, 0, 1, 1), (16, 25, 8, 0, 1, 2),
            (26, 50, 13, 0, 1, 3), (51, 90, 20, 0, 2, 5), (91, 150, 32, 0, 3, 7),
            (151, 280, 50, 0, 5, 10), (281, 500, 80, 1, 7, 14), (501, 1200, 125, 1, 10, 21),
            (1201, 3200, 200, 2, 14, 21), (3201, 9999999, 315, 3, 21, 21),
        ]
        created = 0
        for mn, mx, ss, ac, am, ami in aql_data:
            _, c = AQLTable.objects.get_or_create(
                batch_size_min=mn, batch_size_max=mx,
                defaults={'sample_size': ss, 'accept_critical': ac, 'accept_major': am, 'accept_minor': ami}
            )
            if c: created += 1
        self.stdout.write(self.style.SUCCESS(f'  ✓ AQL tables: {AQLTable.objects.count()} records'))

        # IQC Defect codes
        iqc_defects = [
            ('IQC-001', 'Physical damage — cracked, bent, crushed', 'major'),
            ('IQC-002', 'Wrong item — different from order', 'critical'),
            ('IQC-003', 'Short delivery — fewer units than on label', 'major'),
            ('IQC-004', 'Expired / past shelf life', 'critical'),
            ('IQC-005', 'Functional failure — does not work', 'critical'),
            ('IQC-006', 'Labelling error — wrong label or missing', 'minor'),
            ('IQC-007', 'Packaging damage — outer box damaged', 'minor'),
            ('IQC-008', 'Moisture / water damage', 'critical'),
            ('IQC-009', 'Wrong specification — different model/version', 'major'),
            ('IQC-010', 'Cosmetic defect — scratches, dents', 'minor'),
        ]
        for code, desc, sev in iqc_defects:
            DefectCode.objects.get_or_create(code=code, defaults={'description': desc, 'severity': sev})
        self.stdout.write(self.style.SUCCESS(f'  ✓ IQC defect codes: {DefectCode.objects.count()} codes'))

        # SFG defect codes
        sfg_defects = [
            # Assembly
            ('ASM-ISO-001', 'Short circuit detected', 'assembly'),
            ('ASM-ISO-002', 'Mechanical damage', 'assembly'),
            ('ASM-ISO-003', 'Missing component', 'assembly'),
            ('ASM-ISO-004', 'Solder defect', 'assembly'),
            ('ASM-ISO-005', 'LCD / Display fault', 'assembly'),
            ('ASM-ISO-006', 'Touchscreen not responding', 'assembly'),
            ('ASM-ISO-007', 'Camera fault', 'assembly'),
            ('ASM-ISO-008', 'Speaker / microphone fault', 'assembly'),
            ('ASM-ISO-009', 'Charging port fault', 'assembly'),
            ('ASM-ISO-010', 'Button malfunction', 'assembly'),
            ('ASM-ISO-011', 'WiFi / Bluetooth fault', 'assembly'),
            ('ASM-ISO-012', 'Unfinished process — end of shift', 'assembly'),
            ('ASM-ISO-013', 'Other — see notes', 'assembly'),
            # Aging
            ('AGE-ISO-001', 'Overheating', 'aging'),
            ('AGE-ISO-002', 'Battery drain failure', 'aging'),
            ('AGE-ISO-003', 'Random restart', 'aging'),
            ('AGE-ISO-004', 'System shutdown', 'aging'),
            ('AGE-ISO-005', 'Display flickering', 'aging'),
            ('AGE-ISO-006', 'Audio distortion', 'aging'),
            ('AGE-ISO-007', 'Connectivity failure', 'aging'),
            ('AGE-ISO-008', 'Charging failure during aging', 'aging'),
            ('AGE-ISO-009', 'Software crash', 'aging'),
            ('AGE-ISO-010', 'Performance degradation', 'aging'),
            ('AGE-ISO-011', 'Aging cycle incomplete — end of shift', 'aging'),
            ('AGE-ISO-012', 'Other — see notes', 'aging'),
            # Packaging
            ('PKG-ISO-001', 'Wrong box / packaging', 'packaging'),
            ('PKG-ISO-002', 'Missing accessory', 'packaging'),
            ('PKG-ISO-003', 'Wrong IMEI sticker', 'packaging'),
            ('PKG-ISO-004', 'Label error', 'packaging'),
            ('PKG-ISO-005', 'Seal broken', 'packaging'),
            ('PKG-ISO-006', 'Cosmetic damage during packing', 'packaging'),
            ('PKG-ISO-007', 'Wrong documentation', 'packaging'),
            ('PKG-ISO-008', 'Wrong colour variant', 'packaging'),
            ('PKG-ISO-009', 'Firmware mismatch', 'packaging'),
            ('PKG-ISO-010', 'Packing incomplete — end of shift', 'packaging'),
            ('PKG-ISO-011', 'Other — see notes', 'packaging'),
        ]
        for code, desc, stage in sfg_defects:
            SFGDefectCode.objects.get_or_create(code=code, defaults={'description': desc, 'source_stage': stage})
        self.stdout.write(self.style.SUCCESS(f'  ✓ SFG defect codes: {SFGDefectCode.objects.count()} codes'))



def check_and_create_shortages(sender, **kwargs):
    """Signal handler to create shortage alerts when stock is updated"""
    pass

    def _setup_system_user(self):
        User = get_user_model()
        if not User.objects.filter(username='elmas_system').exists():
            u = User.objects.create_user(
                username='elmas_system',
                password='ELMASsystem!2024xyz',
                first_name='ELMAS', last_name='System',
                role='admin', is_active=True,
            )
            self.stdout.write(self.style.SUCCESS('  ✓ elmas_system user created'))
        else:
            self.stdout.write('  · elmas_system user exists')

    def _setup_production_lines(self):
        from apps.master.models import ProductionLine
        lines = [
            ('AL-01', 'Assembly Line 1', 'assembly', True,  200),
            ('AL-02', 'Assembly Line 2', 'assembly', False, 200),
            ('AL-03', 'Assembly Line 3', 'assembly', False, 200),
            ('AL-04', 'Assembly Line 4', 'assembly', False, 200),
            ('PL-01', 'Packaging Line 1', 'packaging', True,  150),
            ('PL-02', 'Packaging Line 2', 'packaging', False, 150),
            ('PL-03', 'Packaging Line 3', 'packaging', False, 150),
            ('PL-04', 'Packaging Line 4', 'packaging', False, 150),
        ]
        created = 0
        for code, name, ltype, active, cap in lines:
            _, c = ProductionLine.objects.get_or_create(
                code=code,
                defaults={
                    'name': name, 'line_type': ltype,
                    'is_active': active, 'capacity_per_shift': cap,
                    'status': 'active' if active else 'inactive',
                    'is_system': True,
                }
            )
            if c:
                created += 1
        self.stdout.write(self.style.SUCCESS(
            f'  ✓ Production lines: {ProductionLine.objects.count()} lines ready'
            f' (AL-01 + PL-01 active)'
        ))

    def _setup_repair_station(self):
        from apps.master.models import RepairStation
        _, created = RepairStation.objects.get_or_create(
            code='RS-01',
            defaults={
                'name': 'Repair Station 1',
                'speciality': 'general',
                'status': 'active',
                'is_active': True,
            }
        )
        if created:
            self.stdout.write(self.style.SUCCESS('  ✓ Repair Station RS-01 created'))
        else:
            self.stdout.write('  · Repair Station RS-01 exists')

    def _setup_new_roles_users(self):
        """Create sample users for new roles"""
        User = get_user_model()
        new_role_users = [
            ('battery_ctrl', 'Battery',    'Controller', 'battery_controller', 'EMP-011'),
            ('sfg_operator', 'SFG',        'Operator',   'sfg_operator',       'EMP-012'),
            ('repair_tech',  'Repair',     'Technician', 'repair',             'EMP-013'),
            ('fg_ctrl',      'FG',         'Controller', 'fg',                 'EMP-014'),
        ]
        created = 0
        for username, first, last, role, emp_id in new_role_users:
            user, c = User.objects.get_or_create(
                username=username,
                defaults={
                    'first_name': first, 'last_name': last,
                    'role': role, 'employee_id': emp_id,
                    'force_password_change': True,
                }
            )
            if c:
                user.set_password('ELMAS2024!')
                user.save()
                created += 1
        if created:
            self.stdout.write(self.style.SUCCESS(
                f'  ✓ {created} new role user(s) created (password: ELMAS2024!)'
            ))

    def _setup_chart_of_accounts(self):
        from apps.gl.models import Account, CostCentre
        from apps.master.models import ProductionLine

        accounts = [
            # Assets
            ('1000', 'Cash & Bank',                'asset',     'cash'),
            ('1100', 'Accounts Receivable',        'asset',     'receivable'),
            ('1200', 'Raw Materials Inventory',    'asset',     'inventory'),
            ('1201', 'Packaging Inventory',        'asset',     'inventory'),
            ('1202', 'Battery Inventory',          'asset',     'inventory'),
            ('1203', 'Consumables Inventory',      'asset',     'inventory'),
            ('1300', 'Work In Progress',           'asset',     'wip'),
            ('1400', 'Finished Goods',             'asset',     'inventory'),
            ('1500', 'Plant & Equipment',          'asset',     'fixed_asset'),
            # Liabilities
            ('2000', 'Accounts Payable',           'liability', 'payable'),
            ('2100', 'PAYE Payable',               'liability', 'tax_payable'),
            ('2200', 'VAT Payable',                'liability', 'tax_payable'),
            ('2300', 'NSSF / NHIF Payable',        'liability', 'other_liability'),
            ('2400', 'Salaries Payable',           'liability', 'payable'),
            # Equity
            ('3000', 'Share Capital',              'equity',    'capital'),
            ('3100', 'Retained Earnings',          'equity',    'retained'),
            # Revenue
            ('4000', 'Sales Revenue',              'revenue',   'sales'),
            ('4100', 'Other Income',               'revenue',   'other_income'),
            # COGS
            ('5000', 'Cost of Goods Sold',         'cogs',      'material_cost'),
            ('5100', 'Direct Labour Cost',         'cogs',      'labour_cost'),
            ('5200', 'Manufacturing Overhead',     'cogs',      'overhead'),
            # Expenses
            ('6000', 'Write-off / Scrap',          'expense',   'write_off'),
            ('6100', 'Operating Expenses',         'expense',   'operating'),
            ('6200', 'Battery Write-off',          'expense',   'write_off'),
        ]
        created = 0
        for code, name, atype, subtype in accounts:
            _, c = Account.objects.get_or_create(
                code=code,
                defaults={
                    'name': name,
                    'account_type': atype,
                    'subtype': subtype,
                    'is_system': True,
                    'is_active': True,
                }
            )
            if c:
                created += 1
        self.stdout.write(self.style.SUCCESS(
            f'  ✓ Chart of accounts: {Account.objects.count()} accounts ({created} new)'
        ))

        # Cost centres — one per production line
        lines = ProductionLine.objects.all()
        for line in lines:
            CostCentre.objects.get_or_create(
                code=f'CC-{line.code}',
                defaults={
                    'name': line.name,
                    'centre_type': 'production_line',
                    'production_line': line,
                    'is_active': True,
                }
            )
        # Overhead pool
        CostCentre.objects.get_or_create(
            code='CC-OVH',
            defaults={
                'name': 'Manufacturing Overhead',
                'centre_type': 'overhead',
                'is_active': True,
            }
        )
        self.stdout.write(self.style.SUCCESS(
            f'  ✓ Cost centres: {CostCentre.objects.count()} centres'
        ))
