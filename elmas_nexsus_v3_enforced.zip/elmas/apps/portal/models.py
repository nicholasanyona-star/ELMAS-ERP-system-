"""
ELMAS-NEXSUS ERP — Supplier & Customer Portal
Token-based read-only access. No Django login. No pricing exposed to customers.
Suppliers see: their POs, GRN status, IQC result, payment status.
Customers see: their SOs, DN status, delivery info, IMEI list per dispatch.
"""
from django.db import models
from django.conf import settings
from django.utils import timezone
import secrets


def generate_token():
    return secrets.token_urlsafe(32)


class SupplierPortalAccess(models.Model):
    """
    Token-based portal access for a supplier.
    One token per supplier — revocable at any time.
    Token is included in a URL link sent to supplier.
    No password, no Django user account required.
    """
    STATUS_CHOICES = (
        ('active',   'Active'),
        ('revoked',  'Revoked'),
        ('expired',  'Expired'),
    )

    supplier     = models.OneToOneField(
        'inventory.Supplier', on_delete=models.CASCADE,
        related_name='portal_access'
    )
    token        = models.CharField(
        max_length=64, unique=True, default=generate_token, db_index=True
    )
    contact_name  = models.CharField(max_length=100, blank=True)
    contact_email = models.EmailField(blank=True)
    status        = models.CharField(max_length=10, choices=STATUS_CHOICES, default='active')
    created_by    = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='supplier_portals_created'
    )
    created_at    = models.DateTimeField(auto_now_add=True)
    expires_at    = models.DateTimeField(
        null=True, blank=True,
        help_text='Leave blank for no expiry. Set to revoke after a date.'
    )
    last_accessed = models.DateTimeField(null=True, blank=True)
    access_count  = models.IntegerField(default=0)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Supplier Portal Access'

    def __str__(self):
        return f"Portal: {self.supplier.name} ({self.status})"

    @property
    def is_valid(self):
        if self.status != 'active':
            return False
        if self.expires_at and timezone.now() > self.expires_at:
            return False
        return True

    def regenerate_token(self):
        self.token = generate_token()
        self.save(update_fields=['token'])
        return self.token

    def record_access(self):
        self.last_accessed = timezone.now()
        self.access_count += 1
        self.save(update_fields=['last_accessed', 'access_count'])


class CustomerPortalAccess(models.Model):
    """
    Token-based portal access for a customer.
    Customer sees their own SOs, DNs, IMEIs — nothing else.
    No pricing, no cost data, no other customers.
    """
    STATUS_CHOICES = (
        ('active',  'Active'),
        ('revoked', 'Revoked'),
        ('expired', 'Expired'),
    )

    customer      = models.OneToOneField(
        'dispatch.Customer', on_delete=models.CASCADE,
        related_name='portal_access'
    )
    token         = models.CharField(
        max_length=64, unique=True, default=generate_token, db_index=True
    )
    contact_name  = models.CharField(max_length=100, blank=True)
    contact_email = models.EmailField(blank=True)
    status        = models.CharField(max_length=10, choices=STATUS_CHOICES, default='active')
    created_by    = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='customer_portals_created'
    )
    created_at    = models.DateTimeField(auto_now_add=True)
    expires_at    = models.DateTimeField(null=True, blank=True)
    last_accessed = models.DateTimeField(null=True, blank=True)
    access_count  = models.IntegerField(default=0)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Customer Portal Access'

    def __str__(self):
        return f"Portal: {self.customer.name} ({self.status})"

    @property
    def is_valid(self):
        if self.status != 'active':
            return False
        if self.expires_at and timezone.now() > self.expires_at:
            return False
        return True

    def regenerate_token(self):
        self.token = generate_token()
        self.save(update_fields=['token'])
        return self.token

    def record_access(self):
        self.last_accessed = timezone.now()
        self.access_count += 1
        self.save(update_fields=['last_accessed', 'access_count'])


class PortalNotification(models.Model):
    """
    System notifications sent to portal users (suppliers or customers).
    Internal record only — actual notification via email.
    """
    RECIPIENT_TYPE_CHOICES = (
        ('supplier', 'Supplier'),
        ('customer', 'Customer'),
    )
    EVENT_CHOICES = (
        # Supplier events
        ('po_sent',        'PO Sent to Supplier'),
        ('grn_verified',   'GRN Verified — Delivery Acknowledged'),
        ('iqc_pass',       'IQC Passed — Materials Accepted'),
        ('iqc_fail',       'IQC Failed — Materials Rejected'),
        ('iqc_partial',    'IQC Partial — Some Accepted'),
        # Customer events
        ('so_confirmed',   'Sales Order Confirmed'),
        ('dn_dispatched',  'Order Dispatched'),
        ('dn_delivered',   'Delivery Confirmed'),
    )

    recipient_type = models.CharField(max_length=10, choices=RECIPIENT_TYPE_CHOICES)
    supplier_portal = models.ForeignKey(
        SupplierPortalAccess, on_delete=models.CASCADE,
        null=True, blank=True, related_name='notifications'
    )
    customer_portal = models.ForeignKey(
        CustomerPortalAccess, on_delete=models.CASCADE,
        null=True, blank=True, related_name='notifications'
    )
    event          = models.CharField(max_length=20, choices=EVENT_CHOICES)
    subject        = models.CharField(max_length=200)
    body           = models.TextField()
    document_ref   = models.CharField(max_length=100, blank=True)
    email_sent     = models.BooleanField(default=False)
    email_sent_at  = models.DateTimeField(null=True, blank=True)
    created_at     = models.DateTimeField(auto_now_add=True)
    created_by     = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True
    )

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.event} — {self.document_ref}"
