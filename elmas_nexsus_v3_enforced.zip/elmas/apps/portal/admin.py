from django.contrib import admin
from .models import SupplierPortalAccess, CustomerPortalAccess, PortalNotification


@admin.register(SupplierPortalAccess)
class SupplierPortalAdmin(admin.ModelAdmin):
    list_display = ('supplier', 'status', 'contact_email', 'last_accessed', 'access_count')
    list_filter = ('status',)
    readonly_fields = ('token', 'last_accessed', 'access_count', 'created_at')
    actions = ['revoke_access', 'regenerate_token']

    def revoke_access(self, request, queryset):
        queryset.update(status='revoked')
        self.message_user(request, f'{queryset.count()} portal(s) revoked.')
    revoke_access.short_description = 'Revoke selected portal access'

    def regenerate_token(self, request, queryset):
        for obj in queryset:
            obj.regenerate_token()
        self.message_user(request, f'{queryset.count()} token(s) regenerated.')
    regenerate_token.short_description = 'Regenerate token'


@admin.register(CustomerPortalAccess)
class CustomerPortalAdmin(admin.ModelAdmin):
    list_display = ('customer', 'status', 'contact_email', 'last_accessed', 'access_count')
    list_filter = ('status',)
    readonly_fields = ('token', 'last_accessed', 'access_count', 'created_at')


@admin.register(PortalNotification)
class PortalNotificationAdmin(admin.ModelAdmin):
    list_display = ('event', 'document_ref', 'recipient_type', 'email_sent', 'created_at')
    list_filter = ('event', 'recipient_type', 'email_sent')
    readonly_fields = ('created_at',)
