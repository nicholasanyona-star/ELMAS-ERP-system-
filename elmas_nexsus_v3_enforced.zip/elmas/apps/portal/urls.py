from django.urls import path
from . import views

app_name = 'portal'

urlpatterns = [
    path('supplier/<str:token>/',                   views.supplier_portal,     name='supplier_home'),
    path('supplier/<str:token>/po/<str:po_number>/',views.supplier_po_detail,  name='supplier_po'),
    path('customer/<str:token>/',                   views.customer_portal,     name='customer_home'),
    path('customer/<str:token>/dn/<str:dn_number>/',views.customer_dn_detail,  name='customer_dn'),
    path('revoked/',                                views.portal_revoked,      name='revoked'),
]
