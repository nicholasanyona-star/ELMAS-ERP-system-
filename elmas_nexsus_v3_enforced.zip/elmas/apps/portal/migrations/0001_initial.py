"""
ELMAS-NEXSUS ERP — Portal Migration 0001
SupplierPortalAccess, CustomerPortalAccess, PortalNotification
"""
from django.db import migrations, models
import django.db.models.deletion
import apps.portal.models
from django.conf import settings


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ('inventory', '0004_product_aql_level'),
        ('dispatch', '0004_dn_status_fm_countersign'),
        ('accounts', '0004_user_assigned_line'),
    ]

    operations = [

        migrations.CreateModel(
            name='SupplierPortalAccess',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True)),
                ('token', models.CharField(
                    db_index=True, default=apps.portal.models.generate_token,
                    max_length=64, unique=True,
                )),
                ('contact_name', models.CharField(blank=True, max_length=100)),
                ('contact_email', models.EmailField(blank=True)),
                ('status', models.CharField(
                    choices=[
                        ('active', 'Active'), ('revoked', 'Revoked'), ('expired', 'Expired'),
                    ],
                    default='active', max_length=10,
                )),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('expires_at', models.DateTimeField(blank=True, null=True)),
                ('last_accessed', models.DateTimeField(blank=True, null=True)),
                ('access_count', models.IntegerField(default=0)),
                ('supplier', models.OneToOneField(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='portal_access', to='inventory.supplier',
                )),
                ('created_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='supplier_portals_created',
                    to=settings.AUTH_USER_MODEL,
                )),
            ],
            options={'ordering': ['-created_at'], 'verbose_name': 'Supplier Portal Access'},
        ),

        migrations.CreateModel(
            name='CustomerPortalAccess',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True)),
                ('token', models.CharField(
                    db_index=True, default=apps.portal.models.generate_token,
                    max_length=64, unique=True,
                )),
                ('contact_name', models.CharField(blank=True, max_length=100)),
                ('contact_email', models.EmailField(blank=True)),
                ('status', models.CharField(
                    choices=[
                        ('active', 'Active'), ('revoked', 'Revoked'), ('expired', 'Expired'),
                    ],
                    default='active', max_length=10,
                )),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('expires_at', models.DateTimeField(blank=True, null=True)),
                ('last_accessed', models.DateTimeField(blank=True, null=True)),
                ('access_count', models.IntegerField(default=0)),
                ('customer', models.OneToOneField(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='portal_access', to='dispatch.customer',
                )),
                ('created_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='customer_portals_created',
                    to=settings.AUTH_USER_MODEL,
                )),
            ],
            options={'ordering': ['-created_at'], 'verbose_name': 'Customer Portal Access'},
        ),

        migrations.CreateModel(
            name='PortalNotification',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True)),
                ('recipient_type', models.CharField(
                    choices=[('supplier', 'Supplier'), ('customer', 'Customer')],
                    max_length=10,
                )),
                ('event', models.CharField(
                    choices=[
                        ('po_sent', 'PO Sent'), ('grn_verified', 'GRN Verified'),
                        ('iqc_pass', 'IQC Passed'), ('iqc_fail', 'IQC Failed'),
                        ('iqc_partial', 'IQC Partial'), ('so_confirmed', 'SO Confirmed'),
                        ('dn_dispatched', 'Order Dispatched'), ('dn_delivered', 'Delivered'),
                    ],
                    max_length=20,
                )),
                ('subject', models.CharField(max_length=200)),
                ('body', models.TextField()),
                ('document_ref', models.CharField(blank=True, max_length=100)),
                ('email_sent', models.BooleanField(default=False)),
                ('email_sent_at', models.DateTimeField(blank=True, null=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('supplier_portal', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='notifications', to='portal.supplierportalaccess',
                )),
                ('customer_portal', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='notifications', to='portal.customerportalaccess',
                )),
                ('created_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    to=settings.AUTH_USER_MODEL,
                )),
            ],
            options={'ordering': ['-created_at']},
        ),
    ]
