"""
ELMAS-NEXSUS ERP — Portal Views
Token-based, read-only. No Django login required.
"""
from django.shortcuts import render, get_object_or_404, redirect
from django.http import Http404
from django.utils import timezone
from .models import SupplierPortalAccess, CustomerPortalAccess


def _get_supplier_portal(token):
    """Validate supplier token and return portal object"""
    portal = get_object_or_404(SupplierPortalAccess, token=token)
    if not portal.is_valid:
        raise Http404("Portal access has expired or been revoked.")
    portal.record_access()
    return portal


def _get_customer_portal(token):
    """Validate customer token and return portal object"""
    portal = get_object_or_404(CustomerPortalAccess, token=token)
    if not portal.is_valid:
        raise Http404("Portal access has expired or been revoked.")
    portal.record_access()
    return portal


def supplier_portal(request, token):
    """
    Supplier portal home — shows POs, GRN status, IQC results.
    No pricing shown. No other supplier data accessible.
    """
    portal = _get_supplier_portal(token)
    supplier = portal.supplier

    from apps.procurement.models import PurchaseOrder
    from apps.receiving.models import GRN, IQCInspection

    # Their open POs (last 90 days + all open)
    from datetime import date, timedelta
    cutoff = date.today() - timedelta(days=90)
    pos = PurchaseOrder.objects.filter(
        supplier=supplier
    ).exclude(
        status='cancelled'
    ).order_by('-created_at')[:20]

    # Their GRNs and IQC results
    grns = GRN.objects.filter(
        supplier=supplier
    ).select_related().order_by('-created_at')[:20]

    # Build GRN + IQC combined view
    grn_data = []
    for grn in grns:
        inspection = grn.inspections.first()
        grn_data.append({
            'grn': grn,
            'iqc_status': inspection.decision if inspection else None,
            'iqc_date': inspection.inspected_at if inspection else None,
        })

    return render(request, 'portal/supplier_home.html', {
        'portal':    portal,
        'supplier':  supplier,
        'pos':       pos,
        'grn_data':  grn_data,
        'page_title': f'Supplier Portal — {supplier.name}',
        'system_name': 'ELMAS-NEXSUS ERP',
    })


def supplier_po_detail(request, token, po_number):
    """Supplier sees their own PO detail — quantities, items, status only"""
    portal = _get_supplier_portal(token)
    from apps.procurement.models import PurchaseOrder, POLine
    po = get_object_or_404(
        PurchaseOrder, po_number=po_number, supplier=portal.supplier
    )
    lines = po.lines.select_related('product').all()
    return render(request, 'portal/supplier_po_detail.html', {
        'portal': portal, 'po': po, 'lines': lines,
        'page_title': f'PO {po.po_number}',
        'system_name': 'ELMAS-NEXSUS ERP',
    })


def customer_portal(request, token):
    """
    Customer portal home — their SOs and DN status.
    No pricing, no cost data, no other customer data.
    """
    portal = _get_customer_portal(token)
    customer = portal.customer

    from apps.dispatch.models import SalesOrder, DeliveryNote

    sales_orders = SalesOrder.objects.filter(
        customer=customer
    ).order_by('-created_at')[:20]

    delivery_notes = DeliveryNote.objects.filter(
        sales_order__customer=customer
    ).order_by('-created_at')[:20]

    return render(request, 'portal/customer_home.html', {
        'portal':         portal,
        'customer':       customer,
        'sales_orders':   sales_orders,
        'delivery_notes': delivery_notes,
        'page_title':     f'Customer Portal — {customer.name}',
        'system_name':    'ELMAS-NEXSUS ERP',
    })


def customer_dn_detail(request, token, dn_number):
    """Customer sees their own DN — items, IMEIs, delivery status"""
    portal = _get_customer_portal(token)
    from apps.dispatch.models import DeliveryNote, IMEIDispatch
    dn = get_object_or_404(
        DeliveryNote, dn_number=dn_number,
        sales_order__customer=portal.customer
    )
    imeis = IMEIDispatch.objects.filter(
        delivery_note=dn
    ).select_related('finished_good').all()
    return render(request, 'portal/customer_dn_detail.html', {
        'portal': portal, 'dn': dn, 'imeis': imeis,
        'page_title': f'Delivery — {dn.dn_number}',
        'system_name': 'ELMAS-NEXSUS ERP',
    })


def portal_revoked(request):
    return render(request, 'portal/revoked.html', {
        'system_name': 'ELMAS-NEXSUS ERP',
    })
