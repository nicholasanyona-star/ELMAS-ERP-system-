"""
ELMAS Middleware
Single session enforcement
"""
from django.contrib.auth import logout
from django.shortcuts import redirect


class SingleSessionMiddleware:
    """Ensure only one active session per user"""
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.user.is_authenticated:
            stored_key = request.user.session_key
            current_key = request.session.session_key
            if stored_key and stored_key != current_key:
                logout(request)
                return redirect('/accounts/login/?reason=session')
        return self.get_response(request)
