"""
ELMAS SMS Module — Africa's Talking
Sends SMS alerts to staff for critical events
"""
import logging
from django.conf import settings

logger = logging.getLogger('elmas')


def send_sms(phone_numbers, message):
    """
    Send SMS via Africa's Talking
    phone_numbers: list of phone numbers e.g. ['+254712345678']
    message: string
    Returns: dict with success/failure per number
    """
    if not phone_numbers:
        return {}

    try:
        import africastalking
        africastalking.initialize(
            username=settings.AT_USERNAME,
            api_key=settings.AT_API_KEY,
        )
        sms = africastalking.SMS
        results = {}
        # Send in batches of 10
        for i in range(0, len(phone_numbers), 10):
            batch = phone_numbers[i:i+10]
            try:
                response = sms.send(message, batch)
                for recipient in response.get('SMSMessageData', {}).get('Recipients', []):
                    results[recipient.get('number')] = recipient.get('status')
            except Exception as e:
                logger.error(f'[SMS] Batch send error: {e}')
                for num in batch:
                    results[num] = f'error: {e}'
        return results
    except ImportError:
        logger.warning('[SMS] africastalking not installed. Run: pip install africastalking')
        return {}
    except Exception as e:
        logger.error(f'[SMS] Error: {e}')
        return {}


def get_role_phones(role):
    """Get all active phone numbers for a given role"""
    try:
        from apps.accounts.models import User
        phones = list(
            User.objects.filter(role=role, is_active=True, phone__isnull=False)
            .exclude(phone='')
            .values_list('phone', flat=True)
        )
        return phones
    except Exception as e:
        logger.error(f'[SMS] get_role_phones error: {e}')
        return []


def alert_factory_manager(message, subject='ELMAS Alert'):
    """Send SMS + internal message to all Factory Managers"""
    phones = get_role_phones('factory_manager')
    if phones:
        send_sms(phones, f'ELMAS: {message}')
    _send_internal_message('factory_manager', subject, message, is_urgent=True)


def alert_procurement(message, subject='Stock Alert'):
    """Send SMS + internal message to all Procurement Officers"""
    phones = get_role_phones('procurement')
    if phones:
        send_sms(phones, f'ELMAS: {message}')
    _send_internal_message('procurement', subject, message, is_urgent=False)


def alert_warehouse(message, subject='Warehouse Alert'):
    """Send SMS + internal message to Warehouse Controllers"""
    phones = get_role_phones('warehouse')
    if phones:
        send_sms(phones, f'ELMAS: {message}')
    _send_internal_message('warehouse', subject, message, is_urgent=False)


def alert_qc(message, subject='QC Alert'):
    """Send SMS + internal message to QC Officers"""
    phones = get_role_phones('qc')
    if phones:
        send_sms(phones, f'ELMAS: {message}')
    _send_internal_message('qc', subject, message, is_urgent=False)


def _send_internal_message(role, subject, body, is_urgent=False):
    """Send internal ELMAS message to all users of a role"""
    try:
        from apps.messaging.models import Message, MessageRecipient
        from apps.accounts.models import User
        admin = User.objects.filter(role='admin', is_active=True).first()
        if not admin:
            return
        msg = Message.objects.create(
            sender=admin,
            subject=subject,
            body=body,
            is_urgent=is_urgent,
            reference_type='system_alert',
        )
        recipients = User.objects.filter(role=role, is_active=True)
        for user in recipients:
            MessageRecipient.objects.create(message=msg, recipient=user)
    except Exception as e:
        logger.error(f'[SMS] internal message error: {e}')
