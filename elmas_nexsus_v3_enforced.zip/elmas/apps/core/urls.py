from django.urls import path
from . import views
app_name = 'core'
urlpatterns = [
    path('settings/', views.system_settings, name='settings'),
    path('search/', views.global_search, name='global_search'),
]
