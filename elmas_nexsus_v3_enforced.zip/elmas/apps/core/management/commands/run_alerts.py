"""
ELMAS Alert Runner — Extended
Run with: python manage.py run_alerts
Schedule via Windows Task Scheduler every 30 minutes

Morning summary: schedule at 06:00 daily with --morning flag
"""
import logging
from django.core.management.base import BaseCommand
from django.utils import timezone

logger = logging.getLogger('elmas')


class Command(BaseCommand):
    help = 'Run all ELMAS alert checks — schedule every 30 minutes'

    def add_arguments(self, parser):
        parser.add_argument('--morning', action='store_true')
        parser.add_argument('--check', type=str, default='all')

    def handle(self, *args, **options):
        from apps.core.alerts import (
            check_quarantine_overdue,
            check_sfg_overdue,
            check_stock_levels,
            check_waiting_bay,
            check_mrn_pending,
            check_battery_expiry,
            check_brn_pending,
            check_aging_overdue,
            check_repair_overdue,
            check_po_overdue,
            check_fm_approval_queue,
            check_inactive_users,
            check_password_expiry,
            send_morning_summary,
        )
        check = options.get('check', 'all')
        morning = options.get('morning', False)
        now = timezone.now()
        self.stdout.write(f'[{now.strftime("%Y-%m-%d %H:%M")}] ELMAS Alert Runner starting...')

        # Morning summary
        if morning or check in ('all', 'morning'):
            hour = now.hour
            minute = now.minute
            if morning or (hour == 6 and minute <= 10) or (hour == 5 and minute >= 50):
                self.stdout.write('  → Sending morning summary...')
                send_morning_summary()
                self.stdout.write(self.style.SUCCESS('  ✓ Morning summary sent'))

        checks = [
            ('quarantine',   check_quarantine_overdue,  'Quarantine overdue'),
            ('sfg',          check_sfg_overdue,          'SFG overdue'),
            ('stock',        check_stock_levels,         'Stock levels'),
            ('waiting',      check_waiting_bay,          'Waiting bay'),
            ('mrn',          check_mrn_pending,          'MRN pending'),
            ('battery',      check_battery_expiry,       'Battery expiry'),
            ('brn',          check_brn_pending,          'BRN pending'),
            ('aging',        check_aging_overdue,        'Aging overdue'),
            ('repair',       check_repair_overdue,       'Repair overdue'),
            ('po',           check_po_overdue,           'PO overdue'),
            ('fm_queue',     check_fm_approval_queue,    'FM approval queue'),
            ('inactive',     check_inactive_users,       'Inactive users'),
            ('passwords',    check_password_expiry,      'Password expiry'),
        ]

        for key, fn, label in checks:
            if check in ('all', key):
                self.stdout.write(f'  → Checking {label}...')
                try:
                    fn()
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f'  ✗ {label}: {e}'))

        self.stdout.write(self.style.SUCCESS(
            f'[{timezone.now().strftime("%H:%M")}] All checks complete.'
        ))
