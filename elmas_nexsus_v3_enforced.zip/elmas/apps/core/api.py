"""
ELMAS-NEXSUS ERP — REST API
Clean JSON endpoints for dashboards, integrations, and portal.
No external dependency (no DRF) — plain Django JsonResponse.
All endpoints require authentication except portal token endpoints.
"""
from django.http import JsonResponse
from django.views.decorators.http import require_GET, require_POST
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from apps.accounts.decorators import ajax_role_required
import json
import logging
logger = logging.getLogger('elmas')


def api_response(data, status=200):
    return JsonResponse({'status': 'ok', 'data': data}, status=status)


def api_error(message, status=400):
    return JsonResponse({'status': 'error', 'message': message}, status=status)


# ── STOCK API ─────────────────────────────────────────────────────────────────

@login_required
@require_GET
def api_stock_level(request, product_id):
    """GET /api/stock/<id>/ — current stock level for a product"""
    try:
        from apps.inventory.models import Product, get_current_stock
        product = Product.objects.get(pk=product_id, is_active=True)
        stock = float(get_current_stock(product))
        return api_response({
            'product_id': product.pk,
            'sku': product.sku,
            'name': product.name,
            'current_stock': stock,
            'uom': product.uom,
            'reorder_point': float(product.reorder_point),
            'minimum_stock': float(product.minimum_stock),
            'stock_status': product.stock_status,
            'is_battery': product.is_battery,
        })
    except Product.DoesNotExist:
        return api_error('Product not found', 404)
    except Exception as e:
        return api_error(str(e), 500)


@login_required
@require_GET
def api_stock_list(request):
    """GET /api/stock/?category=battery&status=low — filtered stock list"""
    from apps.inventory.models import Product, get_current_stock
    qs = Product.objects.filter(is_active=True)
    category = request.GET.get('category')
    if category:
        qs = qs.filter(item_type=category)
    status_filter = request.GET.get('status')
    results = []
    for p in qs.order_by('name')[:100]:
        stock = float(get_current_stock(p))
        st = p.stock_status
        if status_filter and st != status_filter.upper():
            continue
        results.append({
            'id': p.pk, 'sku': p.sku, 'name': p.name,
            'stock': stock, 'uom': p.uom,
            'status': st, 'is_battery': p.is_battery,
        })
    return api_response(results)


# ── WORK ORDER API ────────────────────────────────────────────────────────────

@login_required
@require_GET
def api_wo_status(request, wo_number):
    """GET /api/wo/<wo_number>/ — WO status and completion"""
    try:
        from apps.pmc.models import WorkOrder
        wo = WorkOrder.objects.select_related('bom').get(wo_number=wo_number)
        return api_response({
            'wo_number': wo.wo_number,
            'status': wo.status,
            'phone_model': wo.bom.phone_model,
            'wo_type': wo.wo_type,
            'planned_qty': wo.planned_qty,
            'completed_qty': wo.completed_qty,
            'completion_pct': wo.completion_pct,
            'planned_date': str(wo.planned_date),
            'quality_hold': wo.quality_hold,
        })
    except Exception as e:
        return api_error(str(e), 404)


@login_required
@require_GET
def api_wo_list(request):
    """GET /api/wo/?status=in_progress — list work orders"""
    from apps.pmc.models import WorkOrder
    qs = WorkOrder.objects.select_related('bom').order_by('-created_at')
    status = request.GET.get('status')
    if status:
        qs = qs.filter(status=status)
    results = [{
        'wo_number': wo.wo_number,
        'status': wo.status,
        'phone_model': wo.bom.phone_model,
        'wo_type': wo.wo_type,
        'planned_qty': wo.planned_qty,
        'completed_qty': wo.completed_qty,
        'completion_pct': wo.completion_pct,
    } for wo in qs[:50]]
    return api_response(results)


# ── PRODUCTION OUTPUT API ─────────────────────────────────────────────────────

@login_required
@ajax_role_required('production', 'factory_manager', 'pmc')
@require_POST
@csrf_exempt
def api_log_output(request):
    """
    POST /api/production/output/
    Body: {wo_number, qty_produced, qty_defective, shift, line_code, notes}
    Logs production output and updates WO completion %.
    """
    try:
        data = json.loads(request.body)
        from apps.pmc.models import WorkOrder
        from apps.master.models import ProductionLine
        from apps.production.models import ProductionOutput
        wo = WorkOrder.objects.get(wo_number=data['wo_number'])
        if wo.status not in ('released', 'in_progress'):
            return api_error(f'WO {wo.wo_number} is not active (status: {wo.status})')
        qty_produced = int(data.get('qty_produced', 0))
        qty_defective = int(data.get('qty_defective', 0))
        if qty_produced <= 0:
            return api_error('qty_produced must be greater than zero')
        if qty_defective > qty_produced:
            return api_error('qty_defective cannot exceed qty_produced')
        line = None
        if data.get('line_code'):
            line = ProductionLine.objects.filter(code=data['line_code']).first()
        output = ProductionOutput.objects.create(
            work_order=wo,
            line=line,
            shift=data.get('shift', 'morning'),
            output_date=timezone.now().date(),
            qty_produced=qty_produced,
            qty_defective=qty_defective,
            stage=data.get('stage', 'assembly'),
            notes=data.get('notes', ''),
            logged_by=request.user,
        )
        good_qty = qty_produced - qty_defective
        wo.completed_qty = (wo.completed_qty or 0) + good_qty
        if wo.completed_qty >= wo.planned_qty:
            wo.status = 'completed'
        elif wo.completed_qty > 0:
            wo.status = 'in_progress'
        wo.save(update_fields=['completed_qty', 'status'])
        return api_response({
            'output_id': output.pk,
            'wo_number': wo.wo_number,
            'qty_produced': qty_produced,
            'qty_defective': qty_defective,
            'qty_good': good_qty,
            'wo_completed_qty': wo.completed_qty,
            'wo_completion_pct': wo.completion_pct,
            'wo_status': wo.status,
        }, status=201)
    except WorkOrder.DoesNotExist:
        return api_error('Work order not found', 404)
    except (KeyError, ValueError) as e:
        return api_error(f'Invalid data: {e}')
    except Exception as e:
        logger.error(f'[API] api_log_output: {e}')
        return api_error(str(e), 500)


# ── SALES ORDER COMPLETION API ────────────────────────────────────────────────

@login_required
@require_GET
def api_so_completion(request, so_number):
    """GET /api/so/<so_number>/completion/ — SO dispatch completion %"""
    try:
        from apps.dispatch.models import SalesOrder
        so = SalesOrder.objects.get(so_number=so_number)
        return api_response({
            'so_number': so.so_number,
            'customer': so.customer.name,
            'phone_model': so.phone_model,
            'qty_ordered': so.qty_ordered,
            'qty_dispatched': so.qty_dispatched,
            'completion_pct': so.completion_pct,
            'status': so.status,
            'total_value': float(so.total_value),
            'dispatched_value': float(so.dispatched_value),
        })
    except Exception as e:
        return api_error(str(e), 404)


# ── GL SUMMARY API ────────────────────────────────────────────────────────────

@login_required
@ajax_role_required('factory_manager', 'admin')
@require_GET
def api_gl_summary(request):
    """GET /api/gl/summary/ — P&L summary for FM dashboard widget"""
    try:
        from apps.gl.models import Account
        from decimal import Decimal
        accounts = Account.objects.filter(is_active=True)
        rev = sum(a.balance for a in accounts if a.account_type == 'revenue')
        cogs = sum(a.balance for a in accounts if a.account_type == 'cogs')
        exp = sum(a.balance for a in accounts if a.account_type == 'expense')
        assets = sum(a.balance for a in accounts if a.account_type == 'asset')
        return api_response({
            'total_revenue': float(rev),
            'total_cogs': float(cogs),
            'gross_profit': float(rev - cogs),
            'total_expenses': float(exp),
            'net_profit': float(rev - cogs - exp),
            'total_assets': float(assets),
            'as_of': timezone.now().isoformat(),
        })
    except Exception as e:
        return api_error(str(e), 500)


# ── UNREAD MESSAGES API ───────────────────────────────────────────────────────

@login_required
@require_GET
def api_unread_count(request):
    """GET /api/messages/unread/ — unread message count for badge"""
    try:
        from apps.messaging.models import MessageRecipient
        count = MessageRecipient.objects.filter(
            recipient=request.user, is_read=False, is_dismissed=False
        ).count()
        urgent = MessageRecipient.objects.filter(
            recipient=request.user, is_read=False, message__is_urgent=True
        ).count()
        return api_response({'unread': count, 'urgent': urgent})
    except Exception as e:
        return api_error(str(e), 500)


@login_required
@require_GET
def api_pending_urgent(request):
    """GET /api/messages/urgent/ — urgent unread messages for popup"""
    try:
        from apps.messaging.models import MessageRecipient
        items = MessageRecipient.objects.filter(
            recipient=request.user,
            is_read=False,
            message__is_urgent=True,
            popup_shown=False,
        ).select_related('message')[:5]
        results = [{
            'id': item.pk,
            'subject': item.message.subject,
            'body': item.message.body[:200],
            'sent_at': item.message.sent_at.isoformat(),
            'action_url': item.message.action_url if hasattr(item.message, 'action_url') else '',
        } for item in items]
        # Mark popup shown
        for item in items:
            item.popup_shown = True
            item.save(update_fields=['popup_shown'])
        return api_response(results)
    except Exception as e:
        return api_error(str(e), 500)


# ── FM APPROVAL QUEUE API ─────────────────────────────────────────────────────

@login_required
@ajax_role_required('factory_manager', 'admin')
@require_GET
def api_fm_queue(request):
    """GET /api/fm/queue/ — pending FM approvals"""
    try:
        from apps.core.models import FMApprovalQueue
        items = FMApprovalQueue.objects.filter(status='pending').order_by('-raised_at')[:20]
        return api_response([{
            'id': item.pk,
            'document_type': item.document_type,
            'document_ref': item.document_ref,
            'urgency': item.urgency,
            'description': item.description,
            'raised_at': item.raised_at.isoformat(),
            'expires_at': item.expires_at.isoformat() if item.expires_at else None,
            'is_overdue': item.is_overdue,
        } for item in items])
    except Exception as e:
        return api_error(str(e), 500)


# ── SHORTAGE ALERTS API ───────────────────────────────────────────────────────

@login_required
@require_GET
def api_shortage_alerts(request):
    """GET /api/stock/shortages/ — open shortage alerts"""
    try:
        from apps.procurement.models import ShortageAlert
        alerts = ShortageAlert.objects.filter(
            status='open'
        ).select_related('product').order_by('-created_at')[:50]
        return api_response([{
            'id': a.pk,
            'product': a.product.name,
            'sku': a.product.sku,
            'current_stock': float(a.current_stock),
            'reorder_point': float(a.reorder_point),
            'suggested_order_qty': float(a.suggested_order_qty),
            'alert_type': a.alert_type,
            'created_at': a.created_at.isoformat(),
        } for a in alerts])
    except Exception as e:
        return api_error(str(e), 500)


# ── BETTERY STOCK API ─────────────────────────────────────────────────────────

@login_required
@ajax_role_required('battery_controller', 'warehouse', 'factory_manager', 'admin', 'pmc')
@require_GET
def api_bettery_stock(request):
    """GET /api/bettery/stock/ — battery stock summary"""
    try:
        from apps.inventory.models import Product, get_current_stock
        batteries = Product.objects.filter(is_active=True, item_type='battery')
        results = []
        for p in batteries:
            stock = float(get_current_stock(p))
            results.append({
                'id': p.pk, 'sku': p.sku, 'name': p.name,
                'stock': stock, 'uom': p.uom,
                'status': p.stock_status,
                'reorder_point': float(p.reorder_point),
            })
        return api_response({
            'batteries': results,
            'total_products': len(results),
            'out_of_stock': sum(1 for r in results if r['stock'] == 0),
            'low_stock': sum(1 for r in results if r['status'] == 'LOW'),
        })
    except Exception as e:
        return api_error(str(e), 500)
