"""ELMAS Core Views — System Settings and Global Search"""
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages


def admin_required(view_func):
    from functools import wraps
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated or request.user.role != 'admin':
            from django.http import HttpResponseForbidden
            return HttpResponseForbidden("Admin access required.")
        return view_func(request, *args, **kwargs)
    return wrapper


@login_required
@admin_required
def system_settings(request):
    from apps.master.models import SystemSettings
    s = SystemSettings.get_settings()
    if request.method == 'POST':
        s.company_name = request.POST.get('company_name', s.company_name)
        s.company_address = request.POST.get('company_address', '')
        s.company_phone = request.POST.get('company_phone', '')
        s.company_email = request.POST.get('company_email', '')
        s.company_kra_pin = request.POST.get('company_kra_pin', '')
        s.vat_rate = request.POST.get('vat_rate', 16)
        s.waiting_bay_alert_hours = request.POST.get('waiting_bay_alert_hours', 4)
        s.quarantine_alert_hours = request.POST.get('quarantine_alert_hours', 48)
        s.sfg_alert_hours = request.POST.get('sfg_alert_hours', 4)
        s.sfg_escalate_hours = request.POST.get('sfg_escalate_hours', 8)
        if request.FILES.get('logo'):
            s.logo = request.FILES['logo']
        s.save()
        messages.success(request, '✓ System settings saved.')
        return redirect('core:settings')
    return render(request, 'core/settings.html', {
        'settings': s,
        'page_title': 'System Settings',
    })


# Import global_search from search.py — it has the complete implementation
from apps.core.search import global_search  # noqa
