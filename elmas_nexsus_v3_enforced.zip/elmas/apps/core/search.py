"""
ELMAS Global Search
Searches across: IMEI, GRN, WO, SIV, MRN, DN, PO, Products, Suppliers
"""
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
import logging
logger = logging.getLogger('elmas')


@login_required
def global_search(request):
    q = request.GET.get('q', '').strip()
    results = {}

    if len(q) >= 2:
        try:
            from apps.production.models import FinishedGood
            results['fg'] = FinishedGood.objects.filter(imei__icontains=q).select_related('work_order')[:10]
        except Exception: results['fg'] = []

        try:
            from apps.qc.models import SFGUnit
            results['sfg'] = SFGUnit.objects.filter(imei__icontains=q).select_related('defect_code')[:10]
        except Exception: results['sfg'] = []

        try:
            from apps.receiving.models import GRN
            results['grn'] = GRN.objects.filter(grn_number__icontains=q).select_related('received_by')[:10]
        except Exception: results['grn'] = []

        try:
            from apps.pmc.models import WorkOrder
            results['wo'] = WorkOrder.objects.filter(
                wo_number__icontains=q
            ).select_related('bom')[:10]
        except Exception: results['wo'] = []

        try:
            from apps.pmc.models import MRN
            results['mrn'] = MRN.objects.filter(mrn_number__icontains=q).select_related('work_order')[:5]
        except Exception: results['mrn'] = []

        try:
            from apps.pmc.models import SIV
            results['siv'] = SIV.objects.filter(siv_number__icontains=q).select_related('mrn')[:5]
        except Exception: results['siv'] = []

        try:
            from apps.dispatch.models import DeliveryNote, SalesOrder
            results['dn'] = DeliveryNote.objects.filter(dn_number__icontains=q).select_related('sales_order__customer')[:5]
            results['so'] = SalesOrder.objects.filter(so_number__icontains=q).select_related('customer')[:5]
        except Exception:
            results['dn'] = []
            results['so'] = []

        try:
            from apps.procurement.models import PurchaseOrder
            results['po'] = PurchaseOrder.objects.filter(po_number__icontains=q).select_related('supplier')[:5]
        except Exception: results['po'] = []

        try:
            from apps.inventory.models import Product
            results['product'] = Product.objects.filter(
                name__icontains=q
            ).filter(is_active=True)[:10]
            results['sku'] = Product.objects.filter(
                sku__icontains=q
            ).filter(is_active=True)[:10]
        except Exception:
            results['product'] = []
            results['sku'] = []

        try:
            from apps.inventory.models import Supplier
            results['supplier'] = Supplier.objects.filter(
                name__icontains=q, is_active=True
            )[:5]
        except Exception: results['supplier'] = []

    total = sum(len(v) for v in results.values() if hasattr(v, '__len__'))

    return render(request, 'core/search_results.html', {
        'q': q,
        'results': results,
        'total': total,
        'page_title': f'Search: {q}' if q else 'Search',
    })
