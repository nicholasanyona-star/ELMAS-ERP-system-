"""
ELMAS Template Tags
{% load elmas_tags %}
{% money value %} — shows Kshs value to FM/Admin, masked to others
"""
from django import template
from django.utils.html import format_html

register = template.Library()


@register.simple_tag(takes_context=True)
def money(context, value, label='Kshs', decimals=0):
    """
    Role-aware currency display.
    FM and Admin see full value: Kshs 3,050
    Everyone else sees: Kshs ****
    """
    request = context.get('request')
    if not request or not hasattr(request, 'user'):
        return format_html('<span class="text-muted">Kshs ****</span>')

    user = request.user
    can_see = (
        user.is_authenticated and
        (user.role in ('admin', 'factory_manager') or
         getattr(user, 'is_acting_fm', False) or
         user.is_superuser)
    )
    if can_see:
        try:
            fmt = f"{float(value):,.{decimals}f}"
            return format_html(
                '<span class="money-value">{} {}</span>', label, fmt
            )
        except (TypeError, ValueError):
            return format_html('<span class="text-muted">{} —</span>', label)
    else:
        return format_html(
            '<span class="money-masked text-muted">{} ****</span>', label
        )


@register.simple_tag(takes_context=True)
def money_raw(context, value):
    """Returns raw float for FM/Admin, None for others — for use in calculations"""
    request = context.get('request')
    if not request or not hasattr(request, 'user'):
        return None
    user = request.user
    if user.is_authenticated and user.role in ('admin', 'factory_manager'):
        try:
            return float(value)
        except (TypeError, ValueError):
            return 0
    return None


@register.filter
def multiply(value, arg):
    """Multiply filter: {{ qty|multiply:unit_cost }}"""
    try:
        return float(value) * float(arg)
    except (TypeError, ValueError):
        return 0


@register.filter
def defect_rate(defective, total):
    """Calculate defect rate percentage"""
    try:
        if float(total) == 0:
            return 0
        return round((float(defective) / float(total)) * 100, 1)
    except (TypeError, ValueError):
        return 0


@register.simple_tag
def completion_pct(done, total):
    """Calculate completion percentage"""
    try:
        if float(total) == 0:
            return 0
        return round((float(done) / float(total)) * 100)
    except (TypeError, ValueError):
        return 0
