"""
ELMAS Core Migration 0002
- Add FMApprovalQueue model (moved from pmc to core to avoid circular imports)
"""
from django.db import migrations, models
import django.db.models.deletion
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('core', '0001_initial'),
        ('accounts', '0004_user_assigned_line'),
    ]

    operations = [
        migrations.CreateModel(
            name='FMApprovalQueue',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True)),
                ('document_type', models.CharField(
                    choices=[
                        ('mrn', 'Material Request Note'),
                        ('po', 'Purchase Order'),
                        ('adjustment', 'Stock Adjustment'),
                        ('quarantine', 'Quarantine Decision'),
                        ('bcr', 'Battery Condition Report'),
                        ('scrap', 'Scrap Authorization'),
                        ('stocktake', 'Stock Take Results'),
                        ('mmn_void', 'MMN Void Request'),
                        ('dn_large', 'Large Dispatch Authorization'),
                        ('so_cancel', 'Sales Order Cancellation'),
                        ('fifo_override', 'FIFO Override Request'),
                        ('wo_cancel', 'Work Order Cancellation'),
                        ('bom_change', 'BOM Change Request'),
                        ('brn_cancel', 'BRN Cancellation'),
                    ],
                    db_index=True, max_length=20,
                )),
                ('document_ref', models.CharField(blank=True, db_index=True, max_length=100)),
                ('document_id', models.IntegerField(blank=True, null=True)),
                ('raised_at', models.DateTimeField(auto_now_add=True)),
                ('urgency', models.CharField(
                    choices=[
                        ('critical', '🔴 Critical'),
                        ('urgent', '🟠 Urgent'),
                        ('normal', '🟡 Normal'),
                    ],
                    default='normal', max_length=10,
                )),
                ('description', models.TextField()),
                ('status', models.CharField(
                    choices=[
                        ('pending', 'Pending FM Action'),
                        ('approved', 'Approved'),
                        ('rejected', 'Rejected'),
                        ('escalated', 'Escalated to Admin'),
                    ],
                    db_index=True, default='pending', max_length=10,
                )),
                ('decided_at', models.DateTimeField(blank=True, null=True)),
                ('decision_notes', models.TextField(blank=True)),
                ('expires_at', models.DateTimeField(blank=True, null=True)),
                ('sms_sent', models.BooleanField(default=False)),
                ('email_sent', models.BooleanField(default=False)),
                ('raised_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='fm_queue_raised',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('decided_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='fm_queue_decided',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('escalated_to', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='fm_queue_escalated',
                    to=settings.AUTH_USER_MODEL,
                )),
            ],
            options={
                'verbose_name': 'FM Approval Queue',
                'ordering': ['-raised_at'],
            },
        ),
    ]
