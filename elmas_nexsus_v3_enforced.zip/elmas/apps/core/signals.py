"""
ELMAS-NEXSUS ERP — Signal handlers
Auto-wired on app ready. Covers:
- AuditLog on all key create/update/delete events
- Cost history tracking on Product.unit_cost changes
- Procurement→Inventory: PO receipt auto-updates PO status
- Inventory→Production: SIV complete auto-notifies production
- Production→GL: output logged auto-updates WO completion
- ShortageAlert: auto-create when stock goes below reorder_point
"""
from django.db.models.signals import post_save, pre_save, post_delete
from django.dispatch import receiver
from django.utils import timezone
import logging
logger = logging.getLogger('elmas')


# ── COST HISTORY ─────────────────────────────────────────────────────────────

class CostChangeRecord(object):
    """In-memory snapshot of unit_cost before save"""
    pass

_cost_snapshots = {}


@receiver(pre_save, sender='inventory.Product')
def snapshot_product_cost(sender, instance, **kwargs):
    """Capture unit_cost before save to detect changes"""
    if instance.pk:
        try:
            from apps.inventory.models import Product
            old = Product.objects.get(pk=instance.pk)
            _cost_snapshots[instance.pk] = float(old.unit_cost)
        except Exception:
            pass


@receiver(post_save, sender='inventory.Product')
def track_cost_change(sender, instance, created, **kwargs):
    """Record unit_cost change to CostHistory after save"""
    if created:
        return
    old_cost = _cost_snapshots.pop(instance.pk, None)
    if old_cost is None:
        return
    new_cost = float(instance.unit_cost)
    if abs(old_cost - new_cost) > 0.001:
        try:
            from apps.inventory.models import CostHistory
            CostHistory.objects.create(
                product=instance,
                old_cost=old_cost,
                new_cost=new_cost,
            )
            logger.info(f'[CostHistory] {instance.sku}: {old_cost} → {new_cost}')
        except Exception as e:
            logger.error(f'[CostHistory] {e}')


# ── AUDIT LOG — KEY MODELS ────────────────────────────────────────────────────

def _audit(action_type, instance, extra=''):
    """Create an AuditLog entry from a signal"""
    try:
        from apps.accounts.models import AuditLog
        doc_ref = getattr(instance, 'mrn_number', None) or \
                  getattr(instance, 'grn_number', None) or \
                  getattr(instance, 'wo_number', None) or \
                  getattr(instance, 'po_number', None) or \
                  getattr(instance, 'brn_number', None) or \
                  getattr(instance, 'bcr_number', None) or \
                  getattr(instance, 'siv_number', None) or \
                  getattr(instance, 'dn_number', None) or \
                  getattr(instance, 'so_number', None) or \
                  str(instance.pk)
        AuditLog.objects.create(
            action_type=action_type,
            performed_by=None,  # No request in signal; caller can override
            document_type=instance.__class__.__name__,
            document_ref=str(doc_ref),
            document_id=instance.pk,
            notes=extra,
        )
    except Exception as e:
        logger.debug(f'[Audit signal] {e}')


# MRN status changes
@receiver(post_save, sender='pmc.MRN')
def audit_mrn(sender, instance, created, **kwargs):
    if created:
        _audit('mrn_approved', instance, f'MRN created: {instance.mrn_number}')
    elif instance.status == 'approved':
        _audit('mrn_approved', instance, f'MRN approved: {instance.mrn_number}')
    elif instance.status == 'rejected':
        _audit('mrn_rejected', instance, f'MRN rejected: {instance.mrn_number}')


# BRN events
@receiver(post_save, sender='bettery.BatteryReleaseNote')
def audit_brn(sender, instance, created, **kwargs):
    if instance.status == 'cancelled' and not created:
        _audit('brn_cancelled', instance, f'BRN cancelled: {instance.brn_number}')


# BCR events
@receiver(post_save, sender='bettery.BatteryConditionReport')
def audit_bcr(sender, instance, created, **kwargs):
    if instance.fm_decision and instance.fm_decision != 'pending' and not created:
        _audit('bcr_decided', instance, f'BCR decision: {instance.fm_decision}')


# Quarantine decisions
@receiver(post_save, sender='receiving.Quarantine')
def audit_quarantine(sender, instance, created, **kwargs):
    if instance.decision and not created:
        _audit('quarantine_decided', instance, f'Decision: {instance.decision}')


# DN dispatched
@receiver(post_save, sender='dispatch.DeliveryNote')
def audit_dn(sender, instance, created, **kwargs):
    if instance.status == 'dispatched' and not created:
        _audit('dn_released', instance, f'DN dispatched: {instance.dn_number}')


# ── PROCUREMENT → INVENTORY AUTO-FLOW ────────────────────────────────────────

@receiver(post_save, sender='receiving.GRN')
def update_po_on_grn_status(sender, instance, **kwargs):
    """
    When GRN reaches iqc_pass → update linked PO status.
    GRN.purchase_order_ref links to PO.po_number.
    """
    if instance.status not in ('iqc_pass', 'partial', 'iqc_fail'):
        return
    if not instance.purchase_order_ref:
        return
    try:
        from apps.procurement.models import PurchaseOrder
        po = PurchaseOrder.objects.filter(
            po_number=instance.purchase_order_ref
        ).first()
        if not po:
            return
        # Count total ordered vs received across all GRNs for this PO
        from apps.receiving.models import GRN
        all_grns = GRN.objects.filter(purchase_order_ref=po.po_number)
        passed = all_grns.filter(status__in=['iqc_pass', 'partial']).count()
        total = all_grns.count()
        # Update PO line received quantities
        from apps.pmc.models import BOMLine  # not needed — check POLines
        total_po_qty = sum(
            float(l.quantity) for l in po.lines.all()
        )
        # Sum quantities in IQC-passed GRN lines for this PO
        from apps.receiving.models import GRNLine
        received_qty = sum(
            float(l.quantity_received)
            for g in all_grns.filter(status__in=['iqc_pass', 'partial'])
            for l in g.lines.all()
        )
        if received_qty >= total_po_qty:
            po.status = 'completed'
        elif received_qty > 0:
            po.status = 'partial'
        po.save(update_fields=['status'])
        logger.info(f'[Signal] PO {po.po_number} → {po.status} (received {received_qty}/{total_po_qty})')
    except Exception as e:
        logger.error(f'[Signal] update_po_on_grn_status: {e}')


# ── INVENTORY → PRODUCTION AUTO-FLOW ─────────────────────────────────────────

@receiver(post_save, sender='pmc.SIV')
def notify_production_on_siv_complete(sender, instance, **kwargs):
    """
    When SIV reaches 'complete' → notify Production Supervisor
    that materials are ready to collect.
    """
    if instance.status != 'complete':
        return
    try:
        from apps.messaging.views import send_system_message
        wo = instance.work_order
        if not wo:
            return
        ps = wo.assembly_line.assigned_users.filter(
            role='production', is_active=True
        ).first() if wo.assembly_line else None
        msg = (f'Materials for {wo.wo_number} are ready for collection. '
               f'SIV {instance.siv_number} complete. Please collect from warehouse.')
        send_system_message(
            subject=f'Materials Ready: {instance.siv_number}',
            body=msg,
            role='production',
            is_urgent=False,
            ref_type='siv',
            ref_num=instance.siv_number,
        )
    except Exception as e:
        logger.warning(f'[Signal] notify_production_on_siv_complete: {e}')


# ── PRODUCTION → GL AUTO-FLOW ─────────────────────────────────────────────────

@receiver(post_save, sender='production.ProductionOutput')
def post_labour_on_output(sender, instance, created, **kwargs):
    """
    When output is logged → check if WO is now complete.
    If WO complete → move WIP to FG in GL: DR FG Inventory / CR WIP.
    """
    if not created:
        return
    wo = instance.work_order
    if not wo:
        return
    if wo.completed_qty >= wo.planned_qty:
        try:
            from apps.gl.models import get_system_account, post_journal
            from decimal import Decimal
            wip_acc = get_system_account('wip')
            fg_acc  = get_system_account('inventory')
            if not wip_acc or not fg_acc:
                return
            # Estimate FG value from BOM cost
            materials = wo.calculate_materials()
            total_cost = Decimal(str(sum(m['line_cost'] for m in materials)))
            if total_cost <= 0:
                return
            post_journal(
                description=f'WO complete — WIP to FG: {wo.wo_number}',
                source='stock_movement',
                reference=wo.wo_number,
                source_app='production',
                source_model='WorkOrder',
                source_id=wo.pk,
                lines=[
                    (fg_acc,  total_cost, Decimal('0'), f'FG: {wo.bom.phone_model} × {wo.planned_qty}'),
                    (wip_acc, Decimal('0'), total_cost,  f'WIP clearance: {wo.wo_number}'),
                ]
            )
            logger.info(f'[GL Signal] WO {wo.wo_number} complete — WIP→FG posted {total_cost}')
        except Exception as e:
            logger.warning(f'[GL Signal] post_labour_on_output: {e}')


# ── STOCK SHORTAGE AUTO-ALERT ─────────────────────────────────────────────────

@receiver(post_save, sender='inventory.StockBatch')
def check_shortage_on_depletion(sender, instance, **kwargs):
    """
    When a StockBatch is depleted → check if product is now below reorder_point.
    If yes and no open ShortageAlert exists → create one.
    """
    if instance.status != 'depleted':
        return
    try:
        from apps.inventory.models import get_current_stock
        from apps.procurement.models import ShortageAlert
        product = instance.product
        stock = float(get_current_stock(product))
        reorder = float(product.reorder_point)
        if stock <= reorder:
            existing = ShortageAlert.objects.filter(
                product=product, status='open'
            ).exists()
            if not existing:
                ShortageAlert.objects.create(
                    product=product,
                    alert_type='reactive',
                    current_stock=stock,
                    reorder_point=reorder,
                    suggested_order_qty=float(product.reorder_point) * 2,
                    status='open',
                )
                # Notify procurement + FM
                try:
                    from apps.messaging.views import send_system_message
                    send_system_message(
                        subject=f'Stock Alert: {product.name} below reorder point',
                        body=f'{product.name} stock: {stock} {product.uom}. '
                             f'Reorder point: {reorder}. Please raise PO.',
                        role='procurement',
                        is_urgent=True,
                    )
                    send_system_message(
                        subject=f'Stock Alert: {product.name}',
                        body=f'{product.name} is below reorder point ({stock} remaining).',
                        role='factory_manager',
                        is_urgent=False,
                    )
                except Exception:
                    pass
                logger.info(f'[Signal] ShortageAlert created for {product.sku}')
    except Exception as e:
        logger.error(f'[Signal] check_shortage_on_depletion: {e}')


# ── LABOUR COST → WORK ORDER ──────────────────────────────────────────────────

@receiver(post_save, sender='hr.ShiftRecord')
def update_wo_labour_cost(sender, instance, **kwargs):
    """
    When a ShiftRecord closes with labour_cost > 0 and links to a WO,
    add the labour cost to WorkOrder.total_labour_cost.
    """
    if instance.status != 'closed' or not instance.work_order_id:
        return
    if float(instance.labour_cost or 0) <= 0:
        return
    try:
        from apps.pmc.models import WorkOrder
        from django.db.models import F
        WorkOrder.objects.filter(pk=instance.work_order_id).update(
            total_labour_cost=F('total_labour_cost') + float(instance.labour_cost)
        )
        logger.info(
            f'[Signal] WO {instance.work_order.wo_number} labour cost +{instance.labour_cost}'
        )
    except Exception as e:
        logger.error(f'[Signal] update_wo_labour_cost: {e}')
