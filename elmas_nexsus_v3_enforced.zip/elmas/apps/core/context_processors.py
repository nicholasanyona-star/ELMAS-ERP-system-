"""
ELMAS Context Processors
Makes system settings, unread counts, and FM queue available in all templates
"""


def _nav_tabs_for_role(user):
    """Return only the nav tabs relevant to this role"""
    role = getattr(user, 'role', '')
    is_fm  = role in ('factory_manager', 'admin') or getattr(user, 'is_acting_fm', False)

    all_tabs = {
        'dashboard':   ('dashboard',   'Dashboard',    '🏠', ['admin','factory_manager','warehouse','receiving','qc','qc2','pmc','production','procurement','dispatch','battery_controller','sfg_operator','repair','fg']),
        'receiving':   ('receiving',   'Receiving',    '📥', ['admin','warehouse','receiving','factory_manager']),
        'inventory':   ('inventory',   'Inventory',    '📦', ['admin','warehouse','factory_manager','pmc']),
        'bettery':     ('bettery',     'Bettery',      '🔋', ['admin','warehouse','factory_manager','battery_controller']),
        'qc':          ('qc',          'Quality',      '🔍', ['admin','qc','qc2','factory_manager']),
        'pmc':         ('pmc',         'PMC',          '📋', ['admin','pmc','factory_manager','warehouse','production']),
        'production':  ('production',  'Production',   '🏭', ['admin','production','sfg_operator','repair','fg','factory_manager']),
        'dispatch':    ('dispatch',    'Dispatch',     '🚚', ['admin','dispatch','fg','factory_manager']),
        'procurement': ('procurement', 'Procurement',  '🛒', ['admin','procurement','factory_manager']),
        'gl':          ('gl',          'Ledger',       '💰', ['admin','factory_manager']),
        'hr':          ('hr',          'HR',           '👥', ['admin','factory_manager']),
        'reports':     ('reports',     'Reports',      '📊', ['admin','factory_manager','warehouse','pmc','qc','dispatch']),
        'messaging':   ('messaging',   'Messages',     '✉️',  ['admin','factory_manager','warehouse','receiving','qc','qc2','pmc','production','procurement','dispatch','battery_controller','sfg_operator','repair','fg']),
        'master':      ('master',      'Master Data',  '⚙️',  ['admin','factory_manager']),
    }
    tabs = []
    for key, (ns, label, icon, roles) in all_tabs.items():
        if role in roles or user.is_superuser:
            tabs.append({'ns': ns, 'label': label, 'icon': icon})
    return tabs


def elmas_context(request):
    from apps.master.models import SystemSettings
    try:
        settings = SystemSettings.get_settings()
        unread_count = 0
        urgent_count = 0
        pending_approvals = 0
        fm_substitute_active = False

        if request.user.is_authenticated:
            from apps.messaging.models import MessageRecipient
            unread_count = MessageRecipient.objects.filter(
                recipient=request.user,
                is_read=False,
                is_dismissed=False
            ).count()
            urgent_count = MessageRecipient.objects.filter(
                recipient=request.user,
                is_read=False,
                message__is_urgent=True
            ).count()

            # FM approval queue count (FM and admin only)
            if request.user.role in ('factory_manager', 'admin') or getattr(request.user, 'is_acting_fm', False):
                try:
                    from apps.core.models import FMApprovalQueue
                    pending_approvals = FMApprovalQueue.objects.filter(
                        status='pending'
                    ).count()
                except Exception:
                    pass

            # FM substitute active banner
            try:
                from apps.accounts.models import User
                from django.utils import timezone
                fm_sub = User.objects.filter(
                    is_fm_substitute=True,
                    is_active=True,
                ).exclude(
                    fm_substitute_until__lt=timezone.now()
                ).first()
                fm_substitute_active = fm_sub is not None
            except Exception:
                pass

        return {
            'sys':                settings,
            'ELMAS_VERSION':      '3.0',
            'SYSTEM_NAME':        'ELMAS-NEXSUS ERP',
            'unread_count':       unread_count,
            'urgent_count':       urgent_count,
            'pending_approvals':  pending_approvals,
            'fm_substitute_active': fm_substitute_active,
            'nav_tabs':           _nav_tabs_for_role(request.user) if request.user.is_authenticated else [],
        }
    except Exception:
        return {
            'sys':               None,
            'ELMAS_VERSION':     '3.0',
            'SYSTEM_NAME':       'ELMAS-NEXSUS ERP',
            'unread_count':      0,
            'urgent_count':      0,
            'pending_approvals': 0,
            'fm_substitute_active': False,
            'nav_tabs':          [],
        }
