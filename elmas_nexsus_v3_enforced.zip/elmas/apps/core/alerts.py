"""
ELMAS Alerts Module
Automated email + SMS alerts for critical events
Called by run_alerts management command
"""
import logging
from django.utils import timezone
from django.core.mail import send_mail
from django.conf import settings

logger = logging.getLogger('elmas')


def send_email_alert(subject, body, role=None, emails=None):
    """Send email alert to a role or list of emails"""
    try:
        if role:
            from apps.accounts.models import User
            emails = list(
                User.objects.filter(role=role, is_active=True, email__isnull=False)
                .exclude(email='')
                .values_list('email', flat=True)
            )
        if not emails:
            return
        send_mail(
            subject=f'ELMAS Alert: {subject}',
            message=body,
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=emails,
            fail_silently=True,
        )
        logger.info(f'[ALERTS] Email sent: {subject} → {emails}')
    except Exception as e:
        logger.error(f'[ALERTS] Email error: {e}')


def check_quarantine_overdue():
    """Alert Factory Manager about overdue quarantine items"""
    try:
        from apps.receiving.models import Quarantine
        from apps.core.sms import alert_factory_manager
        overdue = Quarantine.objects.filter(
            status='pending',
            deadline__lt=timezone.now(),
            alert_sent=False,
        )
        count = overdue.count()
        if count > 0:
            message = (
                f'{count} quarantine item(s) require your decision. '
                f'Deadline has passed. Please log in to ELMAS immediately.'
            )
            alert_factory_manager(message, subject=f'⚠ {count} Quarantine Items Overdue')
            send_email_alert(
                subject=f'{count} Quarantine Items Overdue',
                body=message,
                role='factory_manager',
            )
            overdue.update(alert_sent=True)
            logger.info(f'[ALERTS] Quarantine overdue alert sent: {count} items')
    except Exception as e:
        logger.error(f'[ALERTS] check_quarantine_overdue: {e}')


def check_sfg_overdue():
    """Alert QC II and Factory Manager about SFG devices over time limit"""
    try:
        from apps.qc.models import SFGUnit
        from apps.master.models import SystemSettings
        from apps.core.sms import alert_factory_manager, _send_internal_message
        s = SystemSettings.get_settings()
        alert_hours = s.sfg_alert_hours or 4
        escalate_hours = s.sfg_escalate_hours or 8
        now = timezone.now()
        alert_cutoff = now - timezone.timedelta(hours=alert_hours)
        escalate_cutoff = now - timezone.timedelta(hours=escalate_hours)
        # Devices over alert threshold
        over_alert = SFGUnit.objects.filter(
            status='in_sfg',
            created_at__lt=alert_cutoff,
        ).count()
        # Devices over escalate threshold
        over_escalate = SFGUnit.objects.filter(
            status='in_sfg',
            created_at__lt=escalate_cutoff,
        ).count()
        if over_alert > 0:
            msg = f'{over_alert} device(s) in SFG over {alert_hours} hours. Review required.'
            _send_internal_message('qc2', 'SFG Devices Overdue', msg, is_urgent=False)
        if over_escalate > 0:
            msg = f'URGENT: {over_escalate} device(s) in SFG over {escalate_hours} hours. Immediate action required.'
            alert_factory_manager(msg, subject=f'🔴 {over_escalate} SFG Devices Critical')
            send_email_alert(
                subject=f'{over_escalate} SFG Devices Over {escalate_hours} Hours',
                body=msg,
                role='factory_manager',
            )
        if over_alert > 0:
            logger.info(f'[ALERTS] SFG alert: {over_alert} over {alert_hours}h, {over_escalate} over {escalate_hours}h')
    except Exception as e:
        logger.error(f'[ALERTS] check_sfg_overdue: {e}')


def check_stock_levels():
    """Alert Procurement and Factory Manager about low/zero stock"""
    try:
        from apps.inventory.models import Product, StockBatch
        from apps.procurement.models import ShortageAlert
        from apps.core.sms import alert_procurement, alert_factory_manager
        from django.db.models import Sum
        products = Product.objects.filter(is_active=True, reorder_point__gt=0)
        zero_stock = []
        low_stock = []
        for product in products:
            stock = product.current_stock
            if stock == 0:
                zero_stock.append(product)
                # Create shortage alert if not exists
                ShortageAlert.objects.get_or_create(
                    product=product,
                    status='open',
                    defaults={
                        'current_stock': 0,
                        'reorder_point': product.reorder_point,
                        'suggested_order_qty': float(product.reorder_point) * 2,
                    }
                )
            elif stock <= float(product.reorder_point):
                low_stock.append(product)
                ShortageAlert.objects.get_or_create(
                    product=product,
                    status='open',
                    defaults={
                        'current_stock': stock,
                        'reorder_point': product.reorder_point,
                        'suggested_order_qty': float(product.reorder_point) * 2,
                    }
                )
        if zero_stock:
            names = ', '.join(p.name for p in zero_stock[:5])
            msg = f'CRITICAL: {len(zero_stock)} item(s) OUT OF STOCK: {names}. Production may stop.'
            alert_procurement(msg, subject=f'🔴 {len(zero_stock)} Items Out of Stock')
            alert_factory_manager(msg, subject=f'🔴 {len(zero_stock)} Items Out of Stock')
            send_email_alert(
                subject=f'{len(zero_stock)} Items Out of Stock',
                body=msg,
                role='procurement',
            )
        if low_stock:
            names = ', '.join(p.name for p in low_stock[:5])
            msg = f'WARNING: {len(low_stock)} item(s) below reorder point: {names}.'
            alert_procurement(msg, subject=f'⚠ {len(low_stock)} Items Low Stock')
            send_email_alert(
                subject=f'{len(low_stock)} Items Below Reorder Point',
                body=msg,
                role='procurement',
            )
        if zero_stock or low_stock:
            logger.info(f'[ALERTS] Stock: {len(zero_stock)} zero, {len(low_stock)} low')
    except Exception as e:
        logger.error(f'[ALERTS] check_stock_levels: {e}')


def check_waiting_bay():
    """Alert Warehouse Controller about items sitting too long in Waiting Bay"""
    try:
        from apps.inventory.models import StockBatch
        from apps.master.models import SystemSettings, Warehouse
        from apps.core.sms import alert_warehouse
        s = SystemSettings.get_settings()
        alert_hours = s.waiting_bay_alert_hours or 4
        cutoff = timezone.now() - timezone.timedelta(hours=alert_hours)
        waiting_wh = Warehouse.objects.filter(warehouse_type='waiting').first()
        if not waiting_wh:
            return
        old_batches = StockBatch.objects.filter(
            warehouse=waiting_wh,
            status='waiting',
            received_at__lt=cutoff,
        ).count()
        if old_batches > 0:
            msg = f'{old_batches} batch(es) in Waiting Bay over {alert_hours} hours. IQC inspection needed.'
            alert_warehouse(msg, subject=f'⚠ {old_batches} Batches Waiting for IQC')
        logger.info(f'[ALERTS] Waiting Bay: {old_batches} batches over {alert_hours}h')
    except Exception as e:
        logger.error(f'[ALERTS] check_waiting_bay: {e}')


def check_mrn_pending():
    """Alert Warehouse Controller about MRNs waiting too long for approval"""
    try:
        from apps.pmc.models import MRN
        from apps.master.models import SystemSettings
        from apps.core.sms import alert_warehouse, alert_factory_manager
        s = SystemSettings.get_settings()
        alert_hours = s.mrn_approval_alert_hours or 4
        cutoff = timezone.now() - timezone.timedelta(hours=alert_hours)
        pending = MRN.objects.filter(
            status='submitted',
            created_at__lt=cutoff,
        ).count()
        if pending > 0:
            msg = f'{pending} MRN(s) waiting over {alert_hours} hours for Warehouse Controller approval. Production may be delayed.'
            alert_warehouse(msg, subject=f'⚠ {pending} MRNs Pending Approval')
            alert_factory_manager(msg, subject=f'⚠ {pending} MRNs Pending')
        logger.info(f'[ALERTS] MRN pending: {pending}')
    except Exception as e:
        logger.error(f'[ALERTS] check_mrn_pending: {e}')


def send_morning_summary():
    """Send morning summary to Factory Manager at 06:00"""
    try:
        from apps.accounts.models import User
        from apps.messaging.models import Message, MessageRecipient
        from apps.receiving.models import GRN, Quarantine
        from apps.qc.models import SFGUnit
        from apps.production.models import FinishedGood
        from apps.procurement.models import ShortageAlert
        from apps.pmc.models import WorkOrder
        today = timezone.now().date()
        # Gather data
        grns_today = GRN.objects.filter(created_at__date=today).count()
        quarantine_open = Quarantine.objects.filter(status='pending').count()
        quarantine_overdue = Quarantine.objects.filter(
            status='pending', deadline__lt=timezone.now()
        ).count()
        sfg_open = SFGUnit.objects.filter(status='in_sfg').count()
        fg_ready = FinishedGood.objects.filter(status='oqc_passed').count()
        shortages = ShortageAlert.objects.filter(status='open').count()
        active_wos = WorkOrder.objects.filter(status__in=['released', 'in_progress']).count()
        summary = f"""ELMAS Morning Summary — {today.strftime('%A, %d %B %Y')}

FACTORY STATUS:
  GRNs received today: {grns_today}
  Active Work Orders: {active_wos}
  Devices in SFG: {sfg_open}
  Devices ready for dispatch (OQC passed): {fg_ready}

ATTENTION REQUIRED:
  Quarantine items open: {quarantine_open}
  Quarantine items OVERDUE: {quarantine_overdue}
  Stock shortage alerts: {shortages}

Log in to ELMAS to review details and take action.
http://localhost:8000
"""
        # Send as internal message
        admin = User.objects.filter(role='admin', is_active=True).first()
        if not admin:
            return
        msg = Message.objects.create(
            sender=admin,
            subject=f'Morning Summary — {today.strftime("%d %b %Y")}',
            body=summary,
            is_urgent=False,
        )
        managers = User.objects.filter(role='factory_manager', is_active=True)
        for manager in managers:
            MessageRecipient.objects.create(message=msg, recipient=manager)
        # Also send email
        send_email_alert(
            subject=f'Morning Summary — {today.strftime("%d %b %Y")}',
            body=summary,
            role='factory_manager',
        )
        # SMS brief
        from apps.core.sms import alert_factory_manager
        sms_msg = (
            f'ELMAS {today.strftime("%d %b")}: '
            f'WOs={active_wos}, SFG={sfg_open}, '
            f'Quarantine={quarantine_open}({quarantine_overdue} overdue), '
            f'Shortages={shortages}'
        )
        phones = []
        from apps.core.sms import get_role_phones
        phones = get_role_phones('factory_manager')
        if phones:
            from apps.core.sms import send_sms
            send_sms(phones, sms_msg)
        logger.info(f'[ALERTS] Morning summary sent to {managers.count()} manager(s)')
    except Exception as e:
        logger.error(f'[ALERTS] morning_summary error: {e}')


def check_battery_expiry():
    """Alert Battery Controller and FM about batteries approaching shelf life"""
    try:
        from apps.inventory.models import StockBatch
        from apps.master.models import SystemSettings
        from datetime import date, timedelta
        s = SystemSettings.get_settings()
        months = s.battery_shelf_life_months or 6
        # Warn when within 30 days of shelf life limit
        cutoff = date.today() + timedelta(days=30)
        expiring = StockBatch.objects.filter(
            product__item_type='battery',
            status='available',
            expiry_date__lte=cutoff,
            expiry_date__gte=date.today(),
        ).count()
        expired = StockBatch.objects.filter(
            product__item_type='battery',
            status='available',
            expiry_date__lt=date.today(),
        ).count()
        if expired > 0:
            msg = f'URGENT: {expired} expired battery batch(es) still in inventory. Raise BCR immediately.'
            _send_internal_message('battery_controller', 'Expired Batteries in Store', msg, is_urgent=True)
            _send_internal_message('factory_manager', 'Expired Batteries in Store', msg, is_urgent=True)
        if expiring > 0:
            msg = f'WARNING: {expiring} battery batch(es) expiring within 30 days. Review Bettery store.'
            _send_internal_message('battery_controller', 'Batteries Expiring Soon', msg)
            _send_internal_message('factory_manager', 'Batteries Expiring Soon', msg)
    except Exception as e:
        logger.error(f'[ALERTS] check_battery_expiry: {e}')


def check_brn_pending():
    """Alert Battery Controller and WH if BRN actions are overdue"""
    try:
        from apps.bettery.models import BatteryReleaseNote
        from apps.master.models import SystemSettings
        from django.utils import timezone
        s = SystemSettings.get_settings()
        alert_mins = s.brn_pending_alert_mins or 30
        cutoff = timezone.now() - timezone.timedelta(minutes=alert_mins)
        # BRNs generated but not submitted
        pending_pick = BatteryReleaseNote.objects.filter(
            status='generated',
            generated_at__lt=cutoff,
        ).count()
        # BRNs submitted but not accepted
        pending_accept = BatteryReleaseNote.objects.filter(
            status='submitted',
            submitted_at__lt=cutoff,
        ).count()
        if pending_pick > 0:
            msg = f'{pending_pick} BRN(s) generated but not yet picked/submitted. Production waiting.'
            _send_internal_message('battery_controller', 'BRN Pick Overdue', msg, is_urgent=True)
            _send_internal_message('factory_manager', 'BRN Pick Overdue', msg)
        if pending_accept > 0:
            msg = f'{pending_accept} BRN(s) submitted and awaiting WH Controller acceptance.'
            _send_internal_message('warehouse', 'BRN Acceptance Pending', msg, is_urgent=True)
    except Exception as e:
        logger.error(f'[ALERTS] check_brn_pending: {e}')


def check_aging_overdue():
    """Alert production and FM about units overdue in aging room"""
    try:
        from apps.production.models import AgingRecord
        overdue = AgingRecord.objects.filter(
            status='aging',
            expected_exit_at__lt=timezone.now(),
            alert_sent=False,
        )
        count = overdue.count()
        if count > 0:
            msg = f'{count} unit(s) overdue in Aging Room. Check and move to packaging.'
            _send_internal_message('production', 'Aging Room — Units Overdue', msg, is_urgent=True)
            _send_internal_message('factory_manager', 'Aging Room — Units Overdue', msg)
            overdue.update(alert_sent=True, status='overdue')
    except Exception as e:
        logger.error(f'[ALERTS] check_aging_overdue: {e}')


def check_repair_overdue():
    """Alert FM about units stuck in repair too long"""
    try:
        from apps.production.models import RepairRecord
        from apps.master.models import SystemSettings
        s = SystemSettings.get_settings()
        alert_hours = s.repair_alert_hours or 24
        cutoff = timezone.now() - timezone.timedelta(hours=alert_hours)
        overdue = RepairRecord.objects.filter(
            outcome='pending',
            received_at__lt=cutoff,
        ).count()
        if overdue > 0:
            msg = f'{overdue} unit(s) in Repair Station for over {alert_hours} hours. Review required.'
            _send_internal_message('factory_manager', 'Repair Station Overdue', msg)
    except Exception as e:
        logger.error(f'[ALERTS] check_repair_overdue: {e}')


def check_po_overdue():
    """Alert Procurement and FM about overdue purchase orders"""
    try:
        from apps.procurement.models import PurchaseOrder
        from datetime import date
        overdue = PurchaseOrder.objects.filter(
            status__in=['sent', 'acknowledged'],
            expected_date__lt=date.today(),
        ).count()
        if overdue > 0:
            msg = f'{overdue} PO(s) past expected delivery date. Follow up with suppliers.'
            _send_internal_message('procurement', 'POs Overdue', msg, is_urgent=True)
            _send_internal_message('factory_manager', 'POs Overdue', msg)
    except Exception as e:
        logger.error(f'[ALERTS] check_po_overdue: {e}')


def check_fm_approval_queue():
    """Escalate overdue FM approval items to admin"""
    try:
        from apps.core.models import FMApprovalQueue
        from apps.accounts.models import User
        overdue = FMApprovalQueue.objects.filter(
            status='pending',
            expires_at__lt=timezone.now(),
        )
        if overdue.exists():
            admin = User.objects.filter(role='admin', is_active=True).first()
            for item in overdue:
                item.status = 'escalated'
                item.escalated_to = admin
                item.save(update_fields=['status', 'escalated_to'])
            count = overdue.count()
            msg = f'{count} FM approval item(s) escalated — FM did not decide within time limit.'
            if admin:
                _send_internal_message_to_user(admin, 'FM Approval Escalation', msg, is_urgent=True)
    except Exception as e:
        logger.error(f'[ALERTS] check_fm_approval_queue: {e}')


def check_inactive_users():
    """Flag users inactive for more than configured days"""
    try:
        from apps.accounts.models import User
        from apps.master.models import SystemSettings
        s = SystemSettings.get_settings()
        days = s.inactive_user_days or 30
        cutoff = timezone.now() - timezone.timedelta(days=days)
        inactive = User.objects.filter(
            is_active=True,
            last_activity__lt=cutoff,
        ).exclude(role='admin').count()
        if inactive > 0:
            from apps.accounts.models import User as U
            admin = U.objects.filter(role='admin', is_active=True).first()
            if admin:
                msg = f'{inactive} user(s) have not logged in for {days}+ days. Review for ex-employees.'
                _send_internal_message_to_user(admin, 'Inactive Users Detected', msg)
    except Exception as e:
        logger.error(f'[ALERTS] check_inactive_users: {e}')


def check_password_expiry():
    """Alert users whose passwords are expiring"""
    try:
        from apps.accounts.models import User
        from apps.master.models import SystemSettings
        s = SystemSettings.get_settings()
        days = s.password_expiry_days or 90
        warn_cutoff = timezone.now() - timezone.timedelta(days=days - 7)
        expire_cutoff = timezone.now() - timezone.timedelta(days=days)
        # Users whose password expires within 7 days
        expiring_soon = User.objects.filter(
            is_active=True,
            last_password_change__lt=warn_cutoff,
            last_password_change__gte=expire_cutoff,
        )
        for user in expiring_soon:
            _send_internal_message_to_user(
                user,
                'Password Expiring Soon',
                f'Your password will expire in less than 7 days. Please change it now.'
            )
        # Users whose password has expired — force change on next login
        expired = User.objects.filter(
            is_active=True,
            last_password_change__lt=expire_cutoff,
            force_password_change=False,
        )
        expired.update(force_password_change=True)
    except Exception as e:
        logger.error(f'[ALERTS] check_password_expiry: {e}')


def _send_internal_message(role, subject, body, is_urgent=False):
    """Send internal system message to all users of a role"""
    try:
        from apps.messaging.views import send_system_message
        send_system_message(subject, body, role=role, is_urgent=is_urgent)
    except Exception as e:
        logger.error(f'[ALERTS] _send_internal_message: {e}')


def _send_internal_message_to_user(user, subject, body, is_urgent=False):
    """Send internal system message to a specific user"""
    try:
        from apps.messaging.views import send_system_message
        send_system_message(subject, body, user=user, is_urgent=is_urgent)
    except Exception as e:
        logger.error(f'[ALERTS] _send_internal_message_to_user: {e}')
