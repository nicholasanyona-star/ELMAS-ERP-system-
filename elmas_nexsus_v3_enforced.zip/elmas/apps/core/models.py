"""ELMAS Core — no models needed here, handled in master"""
from django.db import models
from django.conf import settings
from django.utils import timezone


class FMApprovalQueue(models.Model):
    """
    Unified FM approval queue — all pending decisions in one place.
    Lives in core so all modules can import without circular dependencies.
    FM sees this on dashboard as action items.
    Auto-escalates to admin if not decided within fm_approval_expiry_hours.
    """
    DOCUMENT_TYPE_CHOICES = (
        ('mrn',           'Material Request Note'),
        ('po',            'Purchase Order'),
        ('adjustment',    'Stock Adjustment'),
        ('quarantine',    'Quarantine Decision'),
        ('bcr',           'Battery Condition Report'),
        ('scrap',         'Scrap Authorization'),
        ('stocktake',     'Stock Take Results'),
        ('mmn_void',      'MMN Void Request'),
        ('dn_large',      'Large Dispatch Authorization'),
        ('so_cancel',     'Sales Order Cancellation'),
        ('fifo_override', 'FIFO Override Request'),
        ('wo_cancel',     'Work Order Cancellation'),
        ('bom_change',    'BOM Change Request'),
        ('brn_cancel',    'BRN Cancellation'),
    )
    URGENCY_CHOICES = (
        ('critical', '🔴 Critical — immediate action'),
        ('urgent',   '🟠 Urgent — within 1 hour'),
        ('normal',   '🟡 Normal — within 4 hours'),
    )
    STATUS_CHOICES = (
        ('pending',   'Pending FM Action'),
        ('approved',  'Approved'),
        ('rejected',  'Rejected'),
        ('escalated', 'Escalated to Admin'),
    )

    document_type  = models.CharField(max_length=20, choices=DOCUMENT_TYPE_CHOICES, db_index=True)
    document_ref   = models.CharField(max_length=100, blank=True, db_index=True)
    document_id    = models.IntegerField(null=True, blank=True)
    raised_by      = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='fm_queue_raised'
    )
    raised_at      = models.DateTimeField(auto_now_add=True)
    urgency        = models.CharField(max_length=10, choices=URGENCY_CHOICES, default='normal')
    description    = models.TextField()
    status         = models.CharField(
        max_length=10, choices=STATUS_CHOICES, default='pending', db_index=True
    )
    decided_by     = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='fm_queue_decided'
    )
    decided_at     = models.DateTimeField(null=True, blank=True)
    decision_notes = models.TextField(blank=True)
    expires_at     = models.DateTimeField(null=True, blank=True)
    escalated_to   = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='fm_queue_escalated'
    )
    sms_sent       = models.BooleanField(default=False)
    email_sent     = models.BooleanField(default=False)

    class Meta:
        ordering = ['-raised_at']
        verbose_name = 'FM Approval Queue'

    def __str__(self):
        return f"{self.document_type} — {self.document_ref} ({self.status})"

    def save(self, *args, **kwargs):
        if not self.expires_at:
            try:
                from apps.master.models import SystemSettings
                s = SystemSettings.get_settings()
                hours = s.fm_approval_expiry_hours or 4
            except Exception:
                hours = 4
            self.expires_at = timezone.now() + timezone.timedelta(hours=hours)
        super().save(*args, **kwargs)

    @property
    def is_overdue(self):
        return (self.status == 'pending' and
                self.expires_at and
                timezone.now() > self.expires_at)
