"""
ELMAS Production Models
Stage handovers, output logging, Assembly units, Aging, Repair, Finished Goods
"""
from django.db import models
from django.conf import settings
from django.utils import timezone

# Unified stage choices used across all production models
STAGE_CHOICES = (
    ('assembly',  'Assembly Line'),
    ('aging',     'Aging Room'),
    ('sfg',       'SFG Warehouse'),
    ('qcii',      'QC II'),
    ('repair',    'Repair Station'),
    ('packaging', 'Packaging Line'),
    ('fg',        'Finished Goods'),
    ('scrap',     'Scrapped'),
)


class StageHandover(models.Model):
    """Handover between production stages — signed by both parties"""
    handover_number = models.CharField(max_length=50, unique=True, db_index=True)
    work_order = models.ForeignKey(
        'pmc.WorkOrder', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='handovers'
    )
    line = models.ForeignKey(
        'master.ProductionLine', on_delete=models.SET_NULL,
        null=True, blank=True,
        help_text='Which line initiated this handover'
    )
    stage_from = models.CharField(max_length=20, choices=STAGE_CHOICES)
    stage_to = models.CharField(max_length=20, choices=STAGE_CHOICES)
    quantity = models.IntegerField()
    is_return = models.BooleanField(default=False)
    notes = models.TextField(blank=True)
    signed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, related_name='handovers_signed'
    )
    countersigned_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='handovers_countersigned'
    )
    countersigned_at = models.DateTimeField(null=True, blank=True)
    handover_date = models.DateTimeField(default=timezone.now)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.handover_number} — {self.stage_from} to {self.stage_to}"

    def save(self, *args, **kwargs):
        if not self.handover_number:
            today = timezone.now().strftime('%Y%m%d')
            count = StageHandover.objects.filter(
                handover_number__startswith=f'HO-{today}'
            ).count() + 1
            self.handover_number = f"HO-{today}-{str(count).zfill(3)}"
        super().save(*args, **kwargs)


class ProductionOutput(models.Model):
    """Daily production output log per shift"""
    SHIFT_CHOICES = (
        ('morning',   'Morning Shift'),
        ('afternoon', 'Afternoon Shift'),
        ('night',     'Night Shift'),
    )
    work_order = models.ForeignKey(
        'pmc.WorkOrder', on_delete=models.CASCADE, related_name='outputs'
    )
    line = models.ForeignKey(
        'master.ProductionLine', on_delete=models.SET_NULL,
        null=True, blank=True
    )
    shift = models.CharField(max_length=15, choices=SHIFT_CHOICES)
    output_date = models.DateField(default=timezone.now)
    qty_produced = models.IntegerField()
    qty_defective = models.IntegerField(default=0)
    stage = models.CharField(max_length=20, choices=STAGE_CHOICES, default='assembly')
    notes = models.TextField(blank=True)
    logged_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-output_date', 'shift']

    def __str__(self):
        return f"{self.work_order.wo_number} — {self.output_date} {self.shift}: {self.qty_produced}"

    @property
    def qty_good(self):
        return self.qty_produced - self.qty_defective

    @property
    def defect_rate(self):
        if self.qty_produced > 0:
            return round((self.qty_defective / self.qty_produced) * 100, 1)
        return 0


class AssemblyUnit(models.Model):
    """Unit-level tracking from assembly exit gate"""
    OUTCOME_CHOICES = (
        ('good',       'Good — proceed'),
        ('defective',  'Defective — to QCII'),
        ('unfinished', 'Unfinished — to SFG hold'),
    )
    UNFINISHED_REASON_CHOICES = (
        ('missing_component', 'Missing Component'),
        ('awaiting_battery',  'Awaiting Battery'),
        ('awaiting_software', 'Awaiting Software Flash'),
        ('shift_ended',       'Shift Ended'),
        ('quality_hold',      'Quality Hold'),
    )
    STATUS_CHOICES = (
        ('at_assembly',          'At Assembly Line'),
        ('to_aging',             'Sent to Aging'),
        ('to_sfg',               'In SFG'),
        ('to_qcii',              'With QCII'),
        ('in_repair',            'In Repair'),
        ('returned_to_assembly', 'Returned to Assembly'),
        ('to_packaging',         'In Packaging'),
        ('ready_for_fg',         'Ready for FG'),
        ('imei_assigned',        'IMEI Assigned'),
        ('complete',             'Complete'),
        ('scrapped',             'Scrapped'),
    )

    tuid = models.CharField(
        max_length=50, unique=True, null=True, blank=True, db_index=True
    )
    imei = models.CharField(
        max_length=20, unique=True, null=True, blank=True, db_index=True
    )
    identity_type = models.CharField(
        max_length=5,
        choices=(('tuid','TUID'),('imei','IMEI')),
        default='tuid'
    )
    identity_entry_method = models.CharField(
        max_length=10,
        choices=(('scan','Scanned'),('manual','Manual Entry')),
        default='manual'
    )
    work_order = models.ForeignKey(
        'pmc.WorkOrder', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='assembly_units'
    )
    assembly_line = models.ForeignKey(
        'master.ProductionLine', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='assembly_units'
    )
    shift = models.CharField(max_length=15, default='morning')
    exit_date = models.DateField(default=timezone.now)
    outcome = models.CharField(max_length=12, choices=OUTCOME_CHOICES)
    destination = models.CharField(max_length=20, choices=STAGE_CHOICES, blank=True)
    defect_code = models.ForeignKey(
        'qc.SFGDefectCode', on_delete=models.SET_NULL, null=True, blank=True
    )
    defect_severity = models.CharField(
        max_length=10,
        choices=(('critical','Critical'),('major','Major'),('minor','Minor')),
        blank=True
    )
    defect_notes = models.TextField(blank=True)
    unfinished_reason = models.CharField(
        max_length=25, choices=UNFINISHED_REASON_CHOICES, blank=True
    )
    missing_component = models.ForeignKey(
        'inventory.Product', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='missing_in_assembly'
    )
    tuid_retired = models.BooleanField(default=False)
    tuid_retired_at = models.DateTimeField(null=True, blank=True)
    imei_assigned_at = models.DateTimeField(null=True, blank=True)
    imei_assigned_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='imei_assignments'
    )
    imei_entry_method = models.CharField(
        max_length=10,
        choices=(('scan','Scanned'),('manual','Manual Entry')),
        blank=True
    )
    label_printed = models.BooleanField(default=False)
    label_printed_at = models.DateTimeField(null=True, blank=True)
    rework_count = models.IntegerField(default=0)
    was_reworked = models.BooleanField(default=False)
    ps_verified_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='ps_verifications'
    )
    ps_verified_at = models.DateTimeField(null=True, blank=True)
    status = models.CharField(
        max_length=25, choices=STATUS_CHOICES, default='at_assembly', db_index=True
    )
    registered_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='units_registered'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.tuid or self.imei or f"Unit-{self.pk}"

    def save(self, *args, **kwargs):
        if not self.tuid and self.identity_type == 'tuid':
            today = timezone.now().strftime('%Y%m%d')
            lc = ''
            if self.assembly_line:
                lc = self.assembly_line.code.replace('-', '')
            else:
                lc = 'XX'
            count = AssemblyUnit.objects.filter(
                tuid__startswith=f'TUID-{today}-{lc}-'
            ).count() + 1
            self.tuid = f"TUID-{today}-{lc}-{str(count).zfill(4)}"
        super().save(*args, **kwargs)

    @property
    def identifier(self):
        return self.imei if self.imei else self.tuid


class AgingRecord(models.Model):
    """Tracks a unit's duration in the aging room"""
    STATUS_CHOICES = (
        ('aging',    'In Aging Room'),
        ('complete', 'Aging Complete'),
        ('overdue',  'Overdue'),
        ('exited',   'Exited'),
    )
    assembly_unit = models.ForeignKey(
        AssemblyUnit, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='aging_records'
    )
    tuid_ref = models.CharField(max_length=50, blank=True, db_index=True)
    work_order = models.ForeignKey(
        'pmc.WorkOrder', on_delete=models.SET_NULL, null=True, blank=True
    )
    from_line = models.ForeignKey(
        'master.ProductionLine', on_delete=models.SET_NULL, null=True, blank=True
    )
    entered_at = models.DateTimeField(default=timezone.now)
    expected_exit_at = models.DateTimeField(null=True, blank=True)
    exited_at = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='aging')
    alert_sent = models.BooleanField(default=False)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-entered_at']

    def __str__(self):
        return f"Aging — {self.tuid_ref or self.pk}"

    def save(self, *args, **kwargs):
        if not self.expected_exit_at:
            try:
                from apps.master.models import SystemSettings
                s = SystemSettings.get_settings()
                hours = s.aging_hours or 8
            except Exception:
                hours = 8
            self.expected_exit_at = self.entered_at + timezone.timedelta(hours=hours)
        if not self.tuid_ref and self.assembly_unit and self.assembly_unit.tuid:
            self.tuid_ref = self.assembly_unit.tuid
        super().save(*args, **kwargs)

    @property
    def hours_in_aging(self):
        end = self.exited_at or timezone.now()
        return round((end - self.entered_at).total_seconds() / 3600, 1)

    @property
    def is_overdue(self):
        return (self.status == 'aging' and
                self.expected_exit_at and
                timezone.now() > self.expected_exit_at)


class RepairRecord(models.Model):
    """Full repair log for a unit at repair station"""
    REPAIR_TYPE_CHOICES = (
        ('board_level', 'Board Level Repair'),
        ('display',     'Display Replacement'),
        ('mechanical',  'Mechanical Repair'),
        ('software',    'Software / Firmware'),
        ('battery',     'Battery Replacement'),
        ('camera',      'Camera Module'),
        ('general',     'General Repair'),
    )
    OUTCOME_CHOICES = (
        ('fixed',       'Fixed — return to production'),
        ('partial',     'Partially Fixed'),
        ('not_fixable', 'Not Fixable — recommend scrap'),
        ('pending',     'Pending'),
    )
    RETURN_TO_CHOICES = (
        ('assembly',  'Assembly Line'),
        ('aging',     'Aging Room'),
        ('packaging', 'Packaging Line'),
    )

    repair_number = models.CharField(max_length=50, unique=True, db_index=True)
    assembly_unit = models.ForeignKey(
        AssemblyUnit, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='repair_records'
    )
    repair_station = models.ForeignKey(
        'master.RepairStation', on_delete=models.SET_NULL, null=True, blank=True
    )
    defect_description = models.TextField()
    repair_type = models.CharField(max_length=15, choices=REPAIR_TYPE_CHOICES)
    work_performed = models.TextField(blank=True)
    components_replaced = models.TextField(blank=True)
    outcome = models.CharField(max_length=15, choices=OUTCOME_CHOICES, default='pending')
    return_to = models.CharField(max_length=12, choices=RETURN_TO_CHOICES, blank=True)
    brn_reference = models.CharField(max_length=50, blank=True)
    fm_decision = models.CharField(
        max_length=15,
        choices=(('scrap','Scrap'),('second_opinion','Second Opinion'),('pending','Pending')),
        default='pending'
    )
    fm_decided_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='repair_fm_decisions'
    )
    fm_decided_at = models.DateTimeField(null=True, blank=True)
    fm_notes = models.TextField(blank=True)
    repaired_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='repairs_done'
    )
    ps_verified_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='repairs_ps_verified'
    )
    ps_verified_at = models.DateTimeField(null=True, blank=True)
    received_at = models.DateTimeField(default=timezone.now)
    repair_started_at = models.DateTimeField(null=True, blank=True)
    repair_completed_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.repair_number

    def save(self, *args, **kwargs):
        if not self.repair_number:
            today = timezone.now().strftime('%Y%m%d')
            count = RepairRecord.objects.filter(
                repair_number__startswith=f'REP-{today}'
            ).count() + 1
            self.repair_number = f"REP-{today}-{str(count).zfill(3)}"
        super().save(*args, **kwargs)

    @property
    def hours_in_repair(self):
        end = self.repair_completed_at or timezone.now()
        return round((end - self.received_at).total_seconds() / 3600, 1)


class FinishedGood(models.Model):
    """Device in Finished Goods warehouse — IMEI mandatory"""
    STATUS_CHOICES = (
        ('in_fg',       'In Finished Goods'),
        ('oqc_pending', 'Awaiting OQC'),
        ('oqc_passed',  'OQC Passed'),
        ('oqc_failed',  'OQC Failed — Returned to SFG'),
        ('dispatched',  'Dispatched'),
    )
    imei = models.CharField(max_length=20, unique=True, db_index=True)
    phone_model = models.CharField(max_length=100, db_index=True)
    colour = models.CharField(max_length=50, blank=True)
    storage = models.CharField(max_length=20, blank=True)
    firmware_version = models.CharField(max_length=50, blank=True)
    work_order = models.ForeignKey(
        'pmc.WorkOrder', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='fg_units'
    )
    assembly_unit = models.OneToOneField(
        AssemblyUnit, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='fg_unit'
    )
    bin_location = models.ForeignKey(
        'master.Bin', on_delete=models.SET_NULL, null=True, blank=True
    )
    status = models.CharField(
        max_length=20, choices=STATUS_CHOICES, default='in_fg', db_index=True
    )
    tuid_origin = models.CharField(max_length=50, blank=True)
    was_reworked = models.BooleanField(default=False)
    rework_count = models.IntegerField(default=0)
    imei_entry_method = models.CharField(
        max_length=10,
        choices=(('scan','Scanned'),('manual','Manual Entry')),
        default='manual'
    )
    allocated_to = models.ForeignKey(
        'dispatch.SalesOrder', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='allocated_fg_units'
    )
    allocated_at = models.DateTimeField(null=True, blank=True)
    allocated_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='fg_allocations'
    )
    received_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, related_name='fg_received'
    )
    received_at = models.DateTimeField(default=timezone.now)
    dispatched_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-received_at']

    def __str__(self):
        return f"IMEI {self.imei} — {self.phone_model}"
