"""ELMAS Production Views — Handovers, Output, FG, OQC"""
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from django.db import transaction
from apps.accounts.decorators import role_required
from .models import StageHandover, ProductionOutput, FinishedGood
import logging
logger = logging.getLogger('elmas')


@login_required
@role_required('admin', 'production', 'warehouse', 'factory_manager')
def handover_list(request):
    handovers = StageHandover.objects.select_related('signed_by', 'countersigned_by').order_by('-created_at')
    return render(request, 'production/handover_list.html', {
        'handovers': handovers, 'page_title': 'Stage Handovers',
    })


@login_required
@role_required('admin', 'production')
def handover_create(request):
    from apps.pmc.models import WorkOrder
    active_wos = WorkOrder.objects.filter(status__in=['released', 'in_progress']).select_related('bom')
    if request.method == 'POST':
        try:
            wo_pk = request.POST.get('work_order')
            handover = StageHandover.objects.create(
                work_order_id=wo_pk or None,
                stage_from=request.POST['stage_from'],
                stage_to=request.POST['stage_to'],
                quantity=int(request.POST['quantity']),
                notes=request.POST.get('notes', '').strip(),
                signed_by=request.user,
                handover_date=timezone.now(),
            )
            messages.success(request, f'✓ Handover {handover.handover_number} recorded. Waiting for Warehouse Controller countersignature.')
            return redirect('production:handover_detail', pk=handover.pk)
        except Exception as e:
            messages.error(request, f'Error: {e}')
    return render(request, 'production/handover_form.html', {
        'active_wos': active_wos,
        'stage_from_choices': StageHandover.STAGE_FROM_CHOICES,
        'stage_to_choices': StageHandover.STAGE_TO_CHOICES,
        'page_title': 'Record Stage Handover',
    })


@login_required
@role_required('admin', 'production', 'warehouse', 'factory_manager')
def handover_detail(request, pk):
    handover = get_object_or_404(StageHandover, pk=pk)
    return render(request, 'production/handover_detail.html', {
        'handover': handover, 'page_title': handover.handover_number,
    })


@login_required
@role_required('admin', 'warehouse')
def handover_countersign(request, pk):
    handover = get_object_or_404(StageHandover, pk=pk)
    if request.method == 'POST':
        if handover.signed_by == request.user:
            messages.error(request, '⚠ The Warehouse Controller must be a different person from the Production Supervisor who created this handover.')
            return redirect('production:handover_detail', pk=pk)
        handover.countersigned_by = request.user
        handover.countersigned_at = timezone.now()
        handover.save(update_fields=['countersigned_by', 'countersigned_at'])
        messages.success(request, f'✓ Handover {handover.handover_number} countersigned by {request.user.get_full_name()}.')
    return redirect('production:handover_detail', pk=pk)


@login_required
def handover_pdf(request, pk):
    from apps.master.models import SystemSettings
    handover = get_object_or_404(StageHandover, pk=pk)
    return render(request, 'production/handover_pdf.html', {
        'handover': handover, 'sys': SystemSettings.get_settings(),
    })


@login_required
@role_required('admin', 'production', 'factory_manager')
def output_log(request):
    from django.core.paginator import Paginator
    from apps.pmc.models import WorkOrder
    outputs = ProductionOutput.objects.select_related('work_order__bom', 'logged_by').order_by('-output_date', '-created_at')
    wo_filter = request.GET.get('wo', '')
    date_filter = request.GET.get('date', '')
    if wo_filter:
        outputs = outputs.filter(work_order_id=wo_filter)
    if date_filter:
        outputs = outputs.filter(output_date=date_filter)
    paginator = Paginator(outputs, 50)
    page_obj = paginator.get_page(request.GET.get('page', 1))
    active_wos = WorkOrder.objects.filter(status__in=['released', 'in_progress', 'completed']).select_related('bom').order_by('-created_at')
    return render(request, 'production/output_log.html', {
        'outputs': page_obj, 'page_obj': page_obj,
        'wo_filter': wo_filter, 'date_filter': date_filter,
        'active_wos': active_wos, 'page_title': 'Production Output Log',
    })


@login_required
@role_required('admin', 'production')
def output_create(request):
    from apps.pmc.models import WorkOrder
    active_wos = WorkOrder.objects.filter(status__in=['released', 'in_progress']).select_related('bom')
    if request.method == 'POST':
        try:
            wo = WorkOrder.objects.get(pk=request.POST['work_order'])
            qty_produced = int(request.POST['qty_produced'])
            qty_defective = int(request.POST.get('qty_defective', 0) or 0)
            output = ProductionOutput.objects.create(
                work_order=wo,
                shift=request.POST['shift'],
                output_date=request.POST.get('output_date') or timezone.now().date(),
                qty_produced=qty_produced,
                qty_defective=qty_defective,
                stage=request.POST.get('stage', 'assembly'),
                notes=request.POST.get('notes', '').strip(),
                logged_by=request.user,
            )
            good_qty = qty_produced - qty_defective
            wo.completed_qty = (wo.completed_qty or 0) + good_qty
            if wo.status != 'completed':
                if wo.completed_qty >= wo.planned_qty:
                    wo.status = 'completed'
                elif wo.completed_qty > 0:
                    wo.status = 'in_progress'
            wo.save(update_fields=['completed_qty', 'status'])
            messages.success(request, f'✓ Output logged: {qty_produced} produced, {qty_defective} defective, {qty_produced - qty_defective} good.')
            return redirect('production:output_log')
        except Exception as e:
            messages.error(request, f'Error: {e}')
    return render(request, 'production/output_form.html', {
        'active_wos': active_wos,
        'shift_choices': ProductionOutput.SHIFT_CHOICES,
        'page_title': 'Log Production Output',
    })


@login_required
@role_required('admin', 'warehouse', 'factory_manager', 'dispatch')
def fg_list(request):
    units = FinishedGood.objects.select_related('work_order', 'received_by').order_by('-received_at')
    status_filter = request.GET.get('status', 'in_fg')
    if status_filter:
        units = units.filter(status=status_filter)
    return render(request, 'production/fg_list.html', {
        'units': units, 'status_filter': status_filter,
        'status_choices': FinishedGood.STATUS_CHOICES,
        'page_title': 'Finished Goods',
    })


@login_required
@role_required('admin', 'warehouse', 'production')
def fg_receive(request):
    """Receive a device into FG — IMEI mandatory"""
    from apps.pmc.models import WorkOrder
    active_wos = WorkOrder.objects.filter(status__in=['released', 'in_progress', 'completed']).select_related('bom')
    from apps.master.models import Bin, Warehouse
    fg_wh = Warehouse.objects.filter(warehouse_type='fg').first()
    bins = Bin.objects.filter(zone__room__warehouse=fg_wh, is_active=True) if fg_wh else []
    if request.method == 'POST':
        imei = request.POST.get('imei', '').strip()
        if not imei:
            messages.error(request, '⚠ IMEI is mandatory for Finished Goods. Every device must be scanned.')
            return render(request, 'production/fg_receive.html', {
                'active_wos': active_wos, 'bins': bins, 'page_title': 'Receive into Finished Goods',
            })
        if FinishedGood.objects.filter(imei=imei).exists():
            messages.error(request, f'⚠ IMEI {imei} already exists in the system.')
            return render(request, 'production/fg_receive.html', {
                'active_wos': active_wos, 'bins': bins, 'page_title': 'Receive into Finished Goods',
            })
        try:
            wo_pk = request.POST.get('work_order')
            bin_pk = request.POST.get('bin_location')
            fg = FinishedGood.objects.create(
                imei=imei,
                phone_model=request.POST.get('phone_model', '').strip(),
                colour=request.POST.get('colour', '').strip(),
                storage=request.POST.get('storage', '').strip(),
                firmware_version=request.POST.get('firmware_version', '').strip(),
                work_order_id=wo_pk or None,
                bin_location_id=bin_pk or None,
                status='oqc_pending',
                received_by=request.user,
            )
            # Update SFG unit if came from SFG
            from apps.qc.models import SFGUnit
            sfg = SFGUnit.objects.filter(imei=imei, status='to_fg').first()
            if sfg:
                sfg.status = 'to_fg'
                sfg.save(update_fields=['status'])
            messages.success(request, f'✓ IMEI {imei} received into Finished Goods. Queued for OQC.')
            return redirect('production:fg_list')
        except Exception as e:
            messages.error(request, f'Error: {e}')
    return render(request, 'production/fg_receive.html', {
        'active_wos': active_wos, 'bins': bins, 'page_title': 'Receive into Finished Goods',
    })


@login_required
def fg_detail(request, pk):
    fg = get_object_or_404(FinishedGood, pk=pk)
    return render(request, 'production/fg_detail.html', {
        'fg': fg, 'page_title': f'IMEI {fg.imei}',
    })


@login_required
@role_required('admin', 'qc', 'qc2', 'factory_manager')
def oqc_list(request):
    pending = FinishedGood.objects.filter(status='oqc_pending').select_related('work_order', 'received_by').order_by('received_at')
    completed = FinishedGood.objects.filter(status__in=['oqc_passed', 'oqc_failed']).order_by('-received_at')[:20]
    return render(request, 'production/oqc_list.html', {
        'pending': pending, 'completed': completed, 'page_title': 'OQC — Outgoing Quality Control',
    })


@login_required
@role_required('admin', 'qc', 'qc2')
def oqc_inspect(request, pk):
    fg = get_object_or_404(FinishedGood, pk=pk)
    if request.method == 'POST':
        decision = request.POST.get('decision')
        notes = request.POST.get('notes', '').strip()
        if decision == 'pass':
            fg.status = 'oqc_passed'
            fg.save(update_fields=['status'])
            messages.success(request, f'✓ IMEI {fg.imei} — OQC PASSED. Ready for dispatch.')
        elif decision == 'fail':
            fg.status = 'oqc_failed'
            fg.save(update_fields=['status'])
            from apps.qc.models import SFGUnit, SFGDefectCode, SFGMovement
            try:
                defect = SFGDefectCode.objects.filter(source_stage='packaging').first()
                sfg = SFGUnit.objects.create(
                    source_stage='packaging',
                    source_location='OQC',
                    imei=fg.imei,
                    defect_notes=f'OQC Failed — {notes}',
                    defect_code=defect,
                    sent_by=request.user,
                    received_by=request.user,
                )
                SFGMovement.objects.create(
                    unit=sfg, movement_type='entry',
                    from_location='Finished Goods — OQC',
                    to_location='SFG',
                    notes=f'Failed OQC: {notes}',
                    signed_by=request.user,
                )
                messages.warning(request, f'✗ IMEI {fg.imei} — OQC FAILED. Moved to SFG as {sfg.sfg_code}.')
            except Exception as e:
                messages.warning(request, f'✗ OQC FAILED. Error moving to SFG: {e}')
        return redirect('production:oqc_list')
    return render(request, 'production/oqc_inspect.html', {
        'fg': fg, 'page_title': f'OQC Inspection — IMEI {fg.imei}',
    })


@login_required
def oqc_pdf(request, pk):
    from apps.master.models import SystemSettings
    fg = get_object_or_404(FinishedGood, pk=pk)
    return render(request, 'production/oqc_pdf.html', {
        'fg': fg, 'sys': SystemSettings.get_settings(),
    })
