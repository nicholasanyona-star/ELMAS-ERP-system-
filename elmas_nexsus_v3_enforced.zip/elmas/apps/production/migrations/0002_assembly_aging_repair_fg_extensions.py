"""
ELMAS Production Migration 0002
- Add line FK to StageHandover and ProductionOutput
- Add is_return to StageHandover
- Add AssemblyUnit model
- Add AgingRecord model
- Add RepairRecord model
- Add fields to FinishedGood (assembly_unit, tuid_origin, was_reworked, etc.)
"""
from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('production', '0001_initial'),
        ('master', '0002_new_types_settings_lines'),
        ('accounts', '0004_user_assigned_line'),
        ('pmc', '0005_mretn'),
        ('inventory', '0004_product_aql_level'),
        ('dispatch', '0003_carton_labels'),
        ('qc', '0002_sfg_extensions'),
    ]

    operations = [

        # StageHandover — add line FK and is_return
        migrations.AddField(
            model_name='stagehandover',
            name='line',
            field=models.ForeignKey(
                blank=True, null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                to='master.productionline',
            ),
        ),
        migrations.AddField(
            model_name='stagehandover',
            name='is_return',
            field=models.BooleanField(default=False),
        ),
        migrations.AlterField(
            model_name='stagehandover',
            name='stage_from',
            field=models.CharField(
                choices=[
                    ('assembly', 'Assembly Line'), ('aging', 'Aging Room'),
                    ('sfg', 'SFG Warehouse'), ('qcii', 'QC II'),
                    ('repair', 'Repair Station'), ('packaging', 'Packaging Line'),
                    ('fg', 'Finished Goods'), ('scrap', 'Scrapped'),
                ],
                max_length=20,
            ),
        ),
        migrations.AlterField(
            model_name='stagehandover',
            name='stage_to',
            field=models.CharField(
                choices=[
                    ('assembly', 'Assembly Line'), ('aging', 'Aging Room'),
                    ('sfg', 'SFG Warehouse'), ('qcii', 'QC II'),
                    ('repair', 'Repair Station'), ('packaging', 'Packaging Line'),
                    ('fg', 'Finished Goods'), ('scrap', 'Scrapped'),
                ],
                max_length=20,
            ),
        ),

        # ProductionOutput — add line FK
        migrations.AddField(
            model_name='productionoutput',
            name='line',
            field=models.ForeignKey(
                blank=True, null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                to='master.productionline',
            ),
        ),

        # AssemblyUnit model
        migrations.CreateModel(
            name='AssemblyUnit',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True)),
                ('tuid', models.CharField(blank=True, db_index=True, max_length=50, null=True, unique=True)),
                ('imei', models.CharField(blank=True, db_index=True, max_length=20, null=True, unique=True)),
                ('identity_type', models.CharField(
                    choices=[('tuid', 'TUID'), ('imei', 'IMEI')],
                    default='tuid', max_length=5,
                )),
                ('identity_entry_method', models.CharField(
                    choices=[('scan', 'Scanned'), ('manual', 'Manual Entry')],
                    default='manual', max_length=10,
                )),
                ('shift', models.CharField(default='morning', max_length=15)),
                ('exit_date', models.DateField(default=django.utils.timezone.now)),
                ('outcome', models.CharField(
                    choices=[
                        ('good', 'Good — proceed'),
                        ('defective', 'Defective — to QCII'),
                        ('unfinished', 'Unfinished — to SFG hold'),
                    ],
                    max_length=12,
                )),
                ('destination', models.CharField(blank=True, max_length=20)),
                ('defect_severity', models.CharField(blank=True, max_length=10)),
                ('defect_notes', models.TextField(blank=True)),
                ('unfinished_reason', models.CharField(blank=True, max_length=25)),
                ('tuid_retired', models.BooleanField(default=False)),
                ('tuid_retired_at', models.DateTimeField(blank=True, null=True)),
                ('imei_assigned_at', models.DateTimeField(blank=True, null=True)),
                ('imei_entry_method', models.CharField(blank=True, max_length=10)),
                ('label_printed', models.BooleanField(default=False)),
                ('label_printed_at', models.DateTimeField(blank=True, null=True)),
                ('rework_count', models.IntegerField(default=0)),
                ('was_reworked', models.BooleanField(default=False)),
                ('ps_verified_at', models.DateTimeField(blank=True, null=True)),
                ('status', models.CharField(
                    choices=[
                        ('at_assembly', 'At Assembly Line'),
                        ('to_aging', 'Sent to Aging'),
                        ('to_sfg', 'In SFG'),
                        ('to_qcii', 'With QCII'),
                        ('in_repair', 'In Repair'),
                        ('returned_to_assembly', 'Returned to Assembly'),
                        ('to_packaging', 'In Packaging'),
                        ('ready_for_fg', 'Ready for FG'),
                        ('imei_assigned', 'IMEI Assigned'),
                        ('complete', 'Complete'),
                        ('scrapped', 'Scrapped'),
                    ],
                    db_index=True, default='at_assembly', max_length=25,
                )),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('notes', models.TextField(blank=True)),
                ('work_order', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='assembly_units', to='pmc.workorder',
                )),
                ('assembly_line', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='assembly_units', to='master.productionline',
                )),
                ('defect_code', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    to='qc.sfgdefectcode',
                )),
                ('missing_component', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='missing_in_assembly', to='inventory.product',
                )),
                ('imei_assigned_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='imei_assignments',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('ps_verified_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='ps_verifications',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('registered_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='units_registered',
                    to=settings.AUTH_USER_MODEL,
                )),
            ],
            options={'ordering': ['-created_at']},
        ),

        # AgingRecord model
        migrations.CreateModel(
            name='AgingRecord',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True)),
                ('tuid_ref', models.CharField(blank=True, db_index=True, max_length=50)),
                ('entered_at', models.DateTimeField(default=django.utils.timezone.now)),
                ('expected_exit_at', models.DateTimeField(blank=True, null=True)),
                ('exited_at', models.DateTimeField(blank=True, null=True)),
                ('status', models.CharField(
                    choices=[
                        ('aging', 'In Aging Room'), ('complete', 'Aging Complete'),
                        ('overdue', 'Overdue'), ('exited', 'Exited'),
                    ],
                    default='aging', max_length=10,
                )),
                ('alert_sent', models.BooleanField(default=False)),
                ('notes', models.TextField(blank=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('assembly_unit', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='aging_records',
                    to='production.assemblyunit',
                )),
                ('work_order', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    to='pmc.workorder',
                )),
                ('from_line', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    to='master.productionline',
                )),
            ],
            options={'ordering': ['-entered_at']},
        ),

        # RepairRecord model
        migrations.CreateModel(
            name='RepairRecord',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True)),
                ('repair_number', models.CharField(db_index=True, max_length=50, unique=True)),
                ('defect_description', models.TextField()),
                ('repair_type', models.CharField(
                    choices=[
                        ('board_level', 'Board Level Repair'), ('display', 'Display Replacement'),
                        ('mechanical', 'Mechanical Repair'), ('software', 'Software / Firmware'),
                        ('battery', 'Battery Replacement'), ('camera', 'Camera Module'),
                        ('general', 'General Repair'),
                    ],
                    max_length=15,
                )),
                ('work_performed', models.TextField(blank=True)),
                ('components_replaced', models.TextField(blank=True)),
                ('outcome', models.CharField(
                    choices=[
                        ('fixed', 'Fixed — return to production'),
                        ('partial', 'Partially Fixed'),
                        ('not_fixable', 'Not Fixable — recommend scrap'),
                        ('pending', 'Pending'),
                    ],
                    default='pending', max_length=15,
                )),
                ('return_to', models.CharField(blank=True, max_length=12)),
                ('brn_reference', models.CharField(blank=True, max_length=50)),
                ('fm_decision', models.CharField(default='pending', max_length=15)),
                ('fm_decided_at', models.DateTimeField(blank=True, null=True)),
                ('fm_notes', models.TextField(blank=True)),
                ('ps_verified_at', models.DateTimeField(blank=True, null=True)),
                ('received_at', models.DateTimeField(default=django.utils.timezone.now)),
                ('repair_started_at', models.DateTimeField(blank=True, null=True)),
                ('repair_completed_at', models.DateTimeField(blank=True, null=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('notes', models.TextField(blank=True)),
                ('assembly_unit', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='repair_records',
                    to='production.assemblyunit',
                )),
                ('repair_station', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    to='master.repairstation',
                )),
                ('fm_decided_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='repair_fm_decisions',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('repaired_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='repairs_done',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('ps_verified_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='repairs_ps_verified',
                    to=settings.AUTH_USER_MODEL,
                )),
            ],
            options={'ordering': ['-created_at']},
        ),

        # FinishedGood — add new fields
        migrations.AddField(
            model_name='finishedgood',
            name='tuid_origin',
            field=models.CharField(blank=True, max_length=50),
        ),
        migrations.AddField(
            model_name='finishedgood',
            name='was_reworked',
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name='finishedgood',
            name='rework_count',
            field=models.IntegerField(default=0),
        ),
        migrations.AddField(
            model_name='finishedgood',
            name='imei_entry_method',
            field=models.CharField(
                choices=[('scan', 'Scanned'), ('manual', 'Manual Entry')],
                default='manual', max_length=10,
            ),
        ),
        migrations.AddField(
            model_name='finishedgood',
            name='assembly_unit',
            field=models.OneToOneField(
                blank=True, null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='fg_unit',
                to='production.assemblyunit',
            ),
        ),
        migrations.AddField(
            model_name='finishedgood',
            name='allocated_to',
            field=models.ForeignKey(
                blank=True, null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='allocated_fg_units',
                to='dispatch.salesorder',
            ),
        ),
        migrations.AddField(
            model_name='finishedgood',
            name='allocated_at',
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name='finishedgood',
            name='allocated_by',
            field=models.ForeignKey(
                blank=True, null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='fg_allocations',
                to=settings.AUTH_USER_MODEL,
            ),
        ),
    ]
