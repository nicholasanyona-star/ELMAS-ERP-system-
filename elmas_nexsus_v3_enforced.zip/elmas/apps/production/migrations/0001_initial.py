from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone
from django.conf import settings


class Migration(migrations.Migration):
    initial = True
    dependencies = [
        ('pmc', '0001_initial'),
        ('master', '0001_initial'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]
    operations = [
        migrations.CreateModel('StageHandover', fields=[
            ('id', models.BigAutoField(auto_created=True, primary_key=True)),
            ('handover_number', models.CharField(db_index=True, max_length=50, unique=True)),
            ('stage_from', models.CharField(choices=[('assembly','Assembly Line'),('aging','Aging Room'),('packaging','Packaging Line')], max_length=20)),
            ('stage_to', models.CharField(choices=[('aging','Aging Room'),('packaging','Packaging Line'),('fg','Finished Goods')], max_length=20)),
            ('quantity', models.IntegerField()),
            ('notes', models.TextField(blank=True)),
            ('handover_date', models.DateTimeField(default=django.utils.timezone.now)),
            ('countersigned_at', models.DateTimeField(blank=True, null=True)),
            ('created_at', models.DateTimeField(auto_now_add=True)),
            ('countersigned_by', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='handovers_countersigned', to=settings.AUTH_USER_MODEL)),
            ('signed_by', models.ForeignKey(null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='handovers_signed', to=settings.AUTH_USER_MODEL)),
            ('work_order', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='handovers', to='pmc.workorder')),
        ], options={'ordering': ['-created_at']}),
        migrations.CreateModel('ProductionOutput', fields=[
            ('id', models.BigAutoField(auto_created=True, primary_key=True)),
            ('shift', models.CharField(choices=[('morning','Morning Shift'),('afternoon','Afternoon Shift'),('night','Night Shift')], max_length=15)),
            ('output_date', models.DateField(default=django.utils.timezone.now)),
            ('qty_produced', models.IntegerField()),
            ('qty_defective', models.IntegerField(default=0)),
            ('stage', models.CharField(default='assembly', max_length=20)),
            ('notes', models.TextField(blank=True)),
            ('created_at', models.DateTimeField(auto_now_add=True)),
            ('logged_by', models.ForeignKey(null=True, on_delete=django.db.models.deletion.SET_NULL, to=settings.AUTH_USER_MODEL)),
            ('work_order', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='outputs', to='pmc.workorder')),
        ], options={'ordering': ['-output_date', 'shift']}),
        migrations.CreateModel('FinishedGood', fields=[
            ('id', models.BigAutoField(auto_created=True, primary_key=True)),
            ('imei', models.CharField(db_index=True, max_length=20, unique=True)),
            ('phone_model', models.CharField(db_index=True, max_length=100)),
            ('colour', models.CharField(blank=True, max_length=50)),
            ('storage', models.CharField(blank=True, max_length=20)),
            ('firmware_version', models.CharField(blank=True, max_length=50)),
            ('status', models.CharField(choices=[('in_fg','In Finished Goods'),('oqc_pending','Awaiting OQC'),('oqc_passed','OQC Passed'),('oqc_failed','OQC Failed — Returned to SFG'),('dispatched','Dispatched')], db_index=True, default='in_fg', max_length=20)),
            ('received_at', models.DateTimeField(default=django.utils.timezone.now)),
            ('dispatched_at', models.DateTimeField(blank=True, null=True)),
            ('created_at', models.DateTimeField(auto_now_add=True)),
            ('bin_location', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to='master.bin')),
            ('received_by', models.ForeignKey(null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='fg_received', to=settings.AUTH_USER_MODEL)),
            ('work_order', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='fg_units', to='pmc.workorder')),
        ], options={'ordering': ['-received_at']}),
    ]
