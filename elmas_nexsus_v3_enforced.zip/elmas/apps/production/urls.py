from django.urls import path
from . import views
app_name = 'production'
urlpatterns = [
    path('handovers/', views.handover_list, name='handover_list'),
    path('handovers/create/', views.handover_create, name='handover_create'),
    path('handovers/<int:pk>/', views.handover_detail, name='handover_detail'),
    path('handovers/<int:pk>/countersign/', views.handover_countersign, name='handover_countersign'),
    path('handovers/<int:pk>/pdf/', views.handover_pdf, name='handover_pdf'),
    path('output/', views.output_log, name='output_log'),
    path('output/create/', views.output_create, name='output_create'),
    path('fg/', views.fg_list, name='fg_list'),
    path('fg/receive/', views.fg_receive, name='fg_receive'),
    path('fg/<int:pk>/', views.fg_detail, name='fg_detail'),
    path('oqc/', views.oqc_list, name='oqc_list'),
    path('oqc/<int:pk>/inspect/', views.oqc_inspect, name='oqc_inspect'),
    path('oqc/pdf/<int:pk>/', views.oqc_pdf, name='oqc_pdf'),
]
