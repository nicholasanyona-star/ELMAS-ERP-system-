from django.contrib import admin
from .models import StageHandover, ProductionOutput, FinishedGood


@admin.register(StageHandover)
class StageHandoverAdmin(admin.ModelAdmin):
    list_display = ('handover_number', 'work_order', 'stage_from', 'stage_to', 'quantity', 'handover_date')
    list_filter = ('stage_from', 'stage_to')
    search_fields = ('handover_number',)
    ordering = ('-handover_date',)


@admin.register(ProductionOutput)
class ProductionOutputAdmin(admin.ModelAdmin):
    list_display = ('work_order', 'shift', 'output_date', 'qty_produced', 'qty_defective', 'logged_by')
    list_filter = ('shift', 'stage')
    ordering = ('-output_date',)


@admin.register(FinishedGood)
class FinishedGoodAdmin(admin.ModelAdmin):
    list_display = ('imei', 'phone_model', 'work_order', 'status', 'received_at', 'received_by')
    list_filter = ('status',)
    search_fields = ('imei', 'phone_model')
    ordering = ('-received_at',)
