"""ELMAS Dispatch Models — Sales Orders, Delivery Notes, IMEI dispatch"""
from django.db import models
from django.conf import settings
from django.utils import timezone


class Customer(models.Model):
    name = models.CharField(max_length=200, db_index=True)
    contact_name = models.CharField(max_length=100, blank=True)
    phone = models.CharField(max_length=30, blank=True)
    email = models.EmailField(blank=True)
    address = models.TextField(blank=True)
    kra_pin = models.CharField(max_length=20, blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return self.name


class SalesOrder(models.Model):
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('confirmed', 'Confirmed'),
        ('partial', 'Partially Dispatched'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    )
    so_number = models.CharField(max_length=50, unique=True, db_index=True)
    customer = models.ForeignKey(Customer, on_delete=models.PROTECT, related_name='orders')
    phone_model = models.CharField(max_length=100)
    qty_ordered = models.IntegerField()
    qty_dispatched = models.IntegerField(default=0)
    unit_price = models.DecimalField(
        max_digits=12, decimal_places=2, default=0,
        help_text='Agreed unit selling price (Kshs)'
    )
    order_date = models.DateField(default=timezone.now)
    required_date = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='pending')
    notes = models.TextField(blank=True)
    cancellation_reason = models.TextField(blank=True)
    cancelled_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='orders_cancelled')
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def clean(self):
        from django.core.exceptions import ValidationError
        if self.qty_ordered is not None and self.qty_ordered <= 0:
            raise ValidationError({'qty_ordered': 'Order quantity must be greater than zero.'})
        if self.unit_price is not None and float(self.unit_price) < 0:
            raise ValidationError({'unit_price': 'Unit price cannot be negative.'})
        if self.required_date and self.order_date and self.required_date < self.order_date:
            raise ValidationError({'required_date': 'Required date cannot be before order date.'})

    @property
    def total_value(self):
        return self.qty_ordered * self.unit_price

    @property
    def dispatched_value(self):
        return self.qty_dispatched * self.unit_price

    @property
    def completion_pct(self):
        if self.qty_ordered > 0:
            return round((self.qty_dispatched / self.qty_ordered) * 100)
        return 0

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.so_number} — {self.customer.name}"

    def save(self, *args, **kwargs):
        if not self.so_number:
            today = timezone.now().strftime('%Y%m%d')
            count = SalesOrder.objects.filter(so_number__startswith=f'SO-{today}').count() + 1
            self.so_number = f"SO-{today}-{str(count).zfill(3)}"
        super().save(*args, **kwargs)


class DeliveryNote(models.Model):
    STATUS_CHOICES = (
        ('draft',      'Draft — adding IMEIs'),
        ('prepared',   'Prepared — submitted for WH release'),
        ('released',   'Released — WH Controller approved'),
        ('dispatched', 'Dispatched — physically left warehouse'),
        ('delivered',  'Delivered — customer signed'),
    )
    dn_number = models.CharField(max_length=50, unique=True, db_index=True)
    sales_order = models.ForeignKey(
        SalesOrder, on_delete=models.PROTECT, related_name='delivery_notes'
    )
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='draft')
    dispatch_date = models.DateTimeField(null=True, blank=True)
    delivery_date = models.DateTimeField(null=True, blank=True)
    vehicle_plate = models.CharField(max_length=20, blank=True)
    driver_name = models.CharField(max_length=100, blank=True)
    customer_signature = models.CharField(max_length=100, blank=True)
    notes = models.TextField(blank=True)
    dispatched_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, related_name='dns_dispatched'
    )
    released_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='dns_released'
    )
    released_at = models.DateTimeField(null=True, blank=True)
    # FM countersign for large orders
    fm_countersigned_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='dns_fm_countersigned'
    )
    fm_countersigned_at = models.DateTimeField(null=True, blank=True)
    requires_fm_countersign = models.BooleanField(
        default=False,
        help_text='Auto-set if IMEI count exceeds dispatch_fm_threshold'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.dn_number} — {self.sales_order.customer.name}"

    def save(self, *args, **kwargs):
        if not self.dn_number:
            today = timezone.now().strftime('%Y%m%d')
            count = DeliveryNote.objects.filter(
                dn_number__startswith=f'DN-{today}'
            ).count() + 1
            self.dn_number = f"DN-{today}-{str(count).zfill(3)}"
        super().save(*args, **kwargs)


class IMEIDispatch(models.Model):
    """Each IMEI scanned and dispatched on a delivery note"""
    delivery_note = models.ForeignKey(DeliveryNote, on_delete=models.CASCADE, related_name='imeis')
    fg_unit = models.ForeignKey('production.FinishedGood', on_delete=models.PROTECT, related_name='dispatch_records')
    imei = models.CharField(max_length=20, db_index=True)
    scanned_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    scanned_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['scanned_at']
        unique_together = ['delivery_note', 'imei']

    def __str__(self):
        return f"{self.imei} — {self.delivery_note.dn_number}"


class CartonLabel(models.Model):
    """
    A shipping carton — groups multiple IMEIs into one physical box.
    Generated at dispatch time. Label printed and stuck on outer carton.
    """
    delivery_note = models.ForeignKey(
        DeliveryNote, on_delete=models.CASCADE, related_name='cartons'
    )
    carton_number = models.IntegerField(help_text='1, 2, 3... within this DN')
    carton_code = models.CharField(max_length=50, unique=True, db_index=True)
    phone_model = models.CharField(max_length=100, blank=True)
    colour = models.CharField(max_length=50, blank=True)
    storage = models.CharField(max_length=20, blank=True)
    qty = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True
    )

    class Meta:
        ordering = ['carton_number']
        unique_together = ['delivery_note', 'carton_number']

    def __str__(self):
        return self.carton_code

    def save(self, *args, **kwargs):
        if not self.carton_code:
            self.carton_code = f"{self.delivery_note.dn_number}-CTN{str(self.carton_number).zfill(3)}"
        super().save(*args, **kwargs)


class CartonIMEI(models.Model):
    """Links each IMEI to a carton"""
    carton = models.ForeignKey(CartonLabel, on_delete=models.CASCADE, related_name='imeis')
    imei_dispatch = models.ForeignKey(IMEIDispatch, on_delete=models.CASCADE, related_name='carton_assignment')
    imei = models.CharField(max_length=20)

    class Meta:
        unique_together = ['carton', 'imei']

    def __str__(self):
        return f"{self.carton.carton_code} — {self.imei}"
