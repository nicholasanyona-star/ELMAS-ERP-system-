from django.urls import path
from . import views
app_name = 'dispatch'
urlpatterns = [
    path('customers/', views.customer_list, name='customer_list'),
    path('customers/create/', views.customer_create, name='customer_create'),
    path('customers/<int:pk>/edit/', views.customer_edit, name='customer_edit'),
    path('orders/', views.so_list, name='so_list'),
    path('orders/create/', views.so_create, name='so_create'),
    path('orders/<int:pk>/', views.so_detail, name='so_detail'),
    path('orders/<int:pk>/cancel/', views.so_cancel, name='so_cancel'),
    path('orders/<int:pk>/dn/create/', views.dn_create, name='dn_create'),
    path('dn/', views.dn_list, name='dn_list'),
    path('dn/<int:pk>/', views.dn_detail, name='dn_detail'),
    path('dn/<int:pk>/scan/', views.dn_scan_imei, name='dn_scan_imei'),
    path('dn/<int:pk>/dispatch/', views.dn_dispatch, name='dn_dispatch'),
    path('dn/<int:pk>/deliver/', views.dn_deliver, name='dn_deliver'),
    path('dn/<int:pk>/pdf/', views.dn_pdf, name='dn_pdf'),
    path('dn/<int:pk>/invoice/', views.dn_invoice, name='dn_invoice'),
    path('dn/<int:pk>/cartons/', views.carton_create, name='carton_create'),
    path('dn/<int:pk>/cartons/labels/', views.carton_labels, name='carton_labels'),
]
