from django.contrib import admin
from .models import Customer, SalesOrder, DeliveryNote, IMEIDispatch, CartonLabel, CartonIMEI


@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ('name', 'contact_name', 'phone', 'email', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('name', 'contact_name', 'phone', 'email')
    ordering = ('name',)


@admin.register(SalesOrder)
class SalesOrderAdmin(admin.ModelAdmin):
    list_display = ('so_number', 'customer', 'phone_model', 'qty_ordered', 'status', 'order_date', 'required_date')
    list_filter = ('status',)
    search_fields = ('so_number', 'customer__name')
    ordering = ('-order_date',)


@admin.register(DeliveryNote)
class DeliveryNoteAdmin(admin.ModelAdmin):
    list_display = ('dn_number', 'sales_order', 'status', 'dispatch_date')
    list_filter = ('status',)
    search_fields = ('dn_number',)
    ordering = ('-dispatch_date',)


@admin.register(IMEIDispatch)
class IMEIDispatchAdmin(admin.ModelAdmin):
    list_display = ('imei', 'delivery_note', 'scanned_at', 'scanned_by')
    search_fields = ('imei',)
    ordering = ('-scanned_at',)


@admin.register(CartonLabel)
class CartonLabelAdmin(admin.ModelAdmin):
    list_display = ('carton_code', 'delivery_note', 'carton_number', 'qty', 'created_at')
    search_fields = ('carton_code',)
    ordering = ('-created_at',)
