from django.db import migrations, models
import django.db.models.deletion
from django.conf import settings


class Migration(migrations.Migration):
    dependencies = [
        ('dispatch', '0001_initial'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]
    operations = [
        migrations.AddField(
            model_name='salesorder',
            name='cancellation_reason',
            field=models.TextField(blank=True),
        ),
        migrations.AddField(
            model_name='salesorder',
            name='cancelled_by',
            field=models.ForeignKey(
                blank=True, null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='orders_cancelled',
                to=settings.AUTH_USER_MODEL
            ),
        ),
        migrations.AddField(
            model_name='salesorder',
            name='cancelled_at',
            field=models.DateTimeField(blank=True, null=True),
        ),
    ]
