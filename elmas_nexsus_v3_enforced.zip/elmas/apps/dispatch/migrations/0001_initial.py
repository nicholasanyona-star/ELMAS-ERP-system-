from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone
from django.conf import settings


class Migration(migrations.Migration):
    initial = True
    dependencies = [
        ('production', '0001_initial'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]
    operations = [
        migrations.CreateModel('Customer', fields=[
            ('id', models.BigAutoField(auto_created=True, primary_key=True)),
            ('name', models.CharField(db_index=True, max_length=200)),
            ('contact_name', models.CharField(blank=True, max_length=100)),
            ('phone', models.CharField(blank=True, max_length=30)),
            ('email', models.EmailField(blank=True)),
            ('address', models.TextField(blank=True)),
            ('kra_pin', models.CharField(blank=True, max_length=20)),
            ('is_active', models.BooleanField(default=True)),
            ('created_at', models.DateTimeField(auto_now_add=True)),
        ], options={'ordering': ['name']}),
        migrations.CreateModel('SalesOrder', fields=[
            ('id', models.BigAutoField(auto_created=True, primary_key=True)),
            ('so_number', models.CharField(db_index=True, max_length=50, unique=True)),
            ('phone_model', models.CharField(max_length=100)),
            ('qty_ordered', models.IntegerField()),
            ('qty_dispatched', models.IntegerField(default=0)),
            ('order_date', models.DateField(default=django.utils.timezone.now)),
            ('required_date', models.DateField(blank=True, null=True)),
            ('status', models.CharField(choices=[('pending','Pending'),('confirmed','Confirmed'),('partial','Partially Dispatched'),('completed','Completed'),('cancelled','Cancelled')], default='pending', max_length=15)),
            ('notes', models.TextField(blank=True)),
            ('created_at', models.DateTimeField(auto_now_add=True)),
            ('created_by', models.ForeignKey(null=True, on_delete=django.db.models.deletion.SET_NULL, to=settings.AUTH_USER_MODEL)),
            ('customer', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='orders', to='dispatch.customer')),
        ], options={'ordering': ['-created_at']}),
        migrations.CreateModel('DeliveryNote', fields=[
            ('id', models.BigAutoField(auto_created=True, primary_key=True)),
            ('dn_number', models.CharField(db_index=True, max_length=50, unique=True)),
            ('status', models.CharField(choices=[('draft','Draft'),('dispatched','Dispatched'),('delivered','Delivered — Signed')], default='draft', max_length=15)),
            ('dispatch_date', models.DateTimeField(blank=True, null=True)),
            ('delivery_date', models.DateTimeField(blank=True, null=True)),
            ('vehicle_plate', models.CharField(blank=True, max_length=20)),
            ('driver_name', models.CharField(blank=True, max_length=100)),
            ('customer_signature', models.CharField(blank=True, max_length=100)),
            ('notes', models.TextField(blank=True)),
            ('created_at', models.DateTimeField(auto_now_add=True)),
            ('dispatched_by', models.ForeignKey(null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='dns_dispatched', to=settings.AUTH_USER_MODEL)),
            ('released_by', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='dns_released', to=settings.AUTH_USER_MODEL)),
            ('sales_order', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='delivery_notes', to='dispatch.salesorder')),
        ], options={'ordering': ['-created_at']}),
        migrations.CreateModel('IMEIDispatch', fields=[
            ('id', models.BigAutoField(auto_created=True, primary_key=True)),
            ('imei', models.CharField(db_index=True, max_length=20)),
            ('scanned_at', models.DateTimeField(auto_now_add=True)),
            ('delivery_note', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='imeis', to='dispatch.deliverynote')),
            ('fg_unit', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='dispatch_records', to='production.finishedgood')),
            ('scanned_by', models.ForeignKey(null=True, on_delete=django.db.models.deletion.SET_NULL, to=settings.AUTH_USER_MODEL)),
        ], options={'ordering': ['scanned_at'], 'unique_together': {('delivery_note', 'imei')}}),
    ]
