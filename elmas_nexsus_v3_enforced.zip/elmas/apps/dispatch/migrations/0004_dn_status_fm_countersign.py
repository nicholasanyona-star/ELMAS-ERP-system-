"""
ELMAS Dispatch Migration 0004
- Add prepared/released statuses to DeliveryNote
- Add released_at, fm_countersigned_by/at, requires_fm_countersign
"""
from django.db import migrations, models
import django.db.models.deletion
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('dispatch', '0003_carton_labels'),
        ('accounts', '0004_user_assigned_line'),
    ]

    operations = [
        migrations.AlterField(
            model_name='deliverynote',
            name='status',
            field=models.CharField(
                choices=[
                    ('draft', 'Draft — adding IMEIs'),
                    ('prepared', 'Prepared — submitted for WH release'),
                    ('released', 'Released — WH Controller approved'),
                    ('dispatched', 'Dispatched — physically left warehouse'),
                    ('delivered', 'Delivered — customer signed'),
                ],
                default='draft', max_length=15,
            ),
        ),
        migrations.AddField(
            model_name='deliverynote',
            name='released_at',
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name='deliverynote',
            name='fm_countersigned_by',
            field=models.ForeignKey(
                blank=True, null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='dns_fm_countersigned',
                to=settings.AUTH_USER_MODEL,
            ),
        ),
        migrations.AddField(
            model_name='deliverynote',
            name='fm_countersigned_at',
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name='deliverynote',
            name='requires_fm_countersign',
            field=models.BooleanField(default=False),
        ),
    ]
