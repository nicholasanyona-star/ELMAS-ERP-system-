"""
ELMAS-NEXSUS Migration: dispatch/0005
- Add unit_price to SalesOrder (needed for GL dispatch posting)
"""
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('dispatch', '0004_dn_status_fm_countersign'),
    ]

    operations = [
        migrations.AddField(
            model_name='salesorder',
            name='unit_price',
            field=models.DecimalField(
                decimal_places=2, default=0, max_digits=12,
                help_text='Agreed unit selling price (Kshs)',
            ),
        ),
    ]
