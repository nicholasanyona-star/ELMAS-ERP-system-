from django.db import migrations, models
import django.db.models.deletion
from django.conf import settings


class Migration(migrations.Migration):
    dependencies = [
        ('dispatch', '0002_so_cancel'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]
    operations = [
        migrations.CreateModel(
            name='CartonLabel',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True)),
                ('carton_number', models.IntegerField()),
                ('carton_code', models.CharField(db_index=True, max_length=50, unique=True)),
                ('phone_model', models.CharField(blank=True, max_length=100)),
                ('colour', models.CharField(blank=True, max_length=50)),
                ('storage', models.CharField(blank=True, max_length=20)),
                ('qty', models.IntegerField(default=0)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('created_by', models.ForeignKey(null=True, on_delete=django.db.models.deletion.SET_NULL, to=settings.AUTH_USER_MODEL)),
                ('delivery_note', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='cartons', to='dispatch.deliverynote')),
            ],
            options={'ordering': ['carton_number']},
        ),
        migrations.AlterUniqueTogether(
            name='cartonlabel',
            unique_together={('delivery_note', 'carton_number')},
        ),
        migrations.CreateModel(
            name='CartonIMEI',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True)),
                ('imei', models.CharField(max_length=20)),
                ('carton', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='imeis', to='dispatch.cartonlabel')),
                ('imei_dispatch', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='carton_assignment', to='dispatch.imeidispatch')),
            ],
        ),
        migrations.AlterUniqueTogether(
            name='cartonimei',
            unique_together={('carton', 'imei')},
        ),
    ]
