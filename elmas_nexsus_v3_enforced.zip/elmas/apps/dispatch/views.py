"""ELMAS Dispatch Views"""
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from django.db import transaction
from apps.accounts.decorators import role_required
from .models import Customer, SalesOrder, DeliveryNote, IMEIDispatch, CartonLabel, CartonIMEI
import logging
logger = logging.getLogger('elmas')


@login_required
@role_required('admin', 'dispatch', 'factory_manager')
def customer_list(request):
    customers = Customer.objects.filter(is_active=True).order_by('name')
    return render(request, 'dispatch/customer_list.html', {
        'customers': customers, 'page_title': 'Customers',
    })


@login_required
@role_required('admin', 'dispatch')
def customer_create(request):
    if request.method == 'POST':
        Customer.objects.create(
            name=request.POST['name'].strip(),
            contact_name=request.POST.get('contact_name', '').strip(),
            phone=request.POST.get('phone', '').strip(),
            email=request.POST.get('email', '').strip(),
            address=request.POST.get('address', '').strip(),
            kra_pin=request.POST.get('kra_pin', '').strip(),
        )
        messages.success(request, 'Customer created.')
        return redirect('dispatch:customer_list')
    return render(request, 'dispatch/customer_form.html', {'page_title': 'Add Customer', 'action': 'Create'})


@login_required
@role_required('admin', 'dispatch')
def customer_edit(request, pk):
    customer = get_object_or_404(Customer, pk=pk)
    if request.method == 'POST':
        customer.name = request.POST.get('name', customer.name).strip()
        customer.contact_name = request.POST.get('contact_name', '').strip()
        customer.phone = request.POST.get('phone', '').strip()
        customer.email = request.POST.get('email', '').strip()
        customer.address = request.POST.get('address', '').strip()
        customer.kra_pin = request.POST.get('kra_pin', '').strip()
        customer.is_active = request.POST.get('is_active') == 'on'
        customer.save()
        messages.success(request, f'Customer {customer.name} updated.')
        return redirect('dispatch:customer_list')
    return render(request, 'dispatch/customer_form.html', {
        'customer': customer, 'page_title': f'Edit {customer.name}', 'action': 'Save',
    })


@login_required
@role_required('admin', 'dispatch', 'factory_manager')
def so_list(request):
    orders = SalesOrder.objects.select_related('customer', 'created_by').order_by('-created_at')
    return render(request, 'dispatch/so_list.html', {
        'orders': orders, 'page_title': 'Sales Orders',
    })


@login_required
@role_required('admin', 'dispatch')
def so_create(request):
    customers = Customer.objects.filter(is_active=True).order_by('name')
    if request.method == 'POST':
        try:
            so = SalesOrder.objects.create(
                customer_id=request.POST['customer'],
                phone_model=request.POST['phone_model'].strip(),
                qty_ordered=int(request.POST['qty_ordered']),
                order_date=request.POST.get('order_date') or timezone.now().date(),
                required_date=request.POST.get('required_date') or None,
                notes=request.POST.get('notes', '').strip(),
                created_by=request.user,
                status='confirmed',
            )
            messages.success(request, f'✓ Sales Order {so.so_number} created.')
            return redirect('dispatch:so_detail', pk=so.pk)
        except Exception as e:
            messages.error(request, f'Error: {e}')
    return render(request, 'dispatch/so_form.html', {
        'customers': customers, 'page_title': 'New Sales Order',
    })


@login_required
@role_required('admin', 'dispatch', 'factory_manager', 'warehouse')
def so_detail(request, pk):
    so = get_object_or_404(SalesOrder, pk=pk)
    dns = so.delivery_notes.select_related('dispatched_by').all()
    return render(request, 'dispatch/so_detail.html', {
        'so': so, 'dns': dns, 'page_title': so.so_number,
    })


@login_required
@role_required('admin', 'dispatch')
def dn_create(request, pk):
    so = get_object_or_404(SalesOrder, pk=pk)
    if request.method == 'POST':
        dn = DeliveryNote.objects.create(
            sales_order=so,
            vehicle_plate=request.POST.get('vehicle_plate', '').strip().upper(),
            driver_name=request.POST.get('driver_name', '').strip(),
            notes=request.POST.get('notes', '').strip(),
            dispatched_by=request.user,
        )
        messages.success(request, f'✓ Delivery Note {dn.dn_number} created. Now scan IMEIs.')
        return redirect('dispatch:dn_scan_imei', pk=dn.pk)
    return render(request, 'dispatch/dn_form.html', {
        'so': so, 'page_title': f'Create Delivery Note — {so.so_number}',
    })


@login_required
@role_required('admin', 'dispatch', 'factory_manager', 'warehouse')
def dn_list(request):
    dns = DeliveryNote.objects.select_related('sales_order__customer', 'dispatched_by').order_by('-created_at')
    return render(request, 'dispatch/dn_list.html', {
        'dns': dns, 'page_title': 'Delivery Notes',
    })


@login_required
@role_required('admin', 'dispatch', 'factory_manager', 'warehouse')
def dn_detail(request, pk):
    dn = get_object_or_404(DeliveryNote, pk=pk)
    imeis = dn.imeis.select_related('fg_unit', 'scanned_by').all()
    return render(request, 'dispatch/dn_detail.html', {
        'dn': dn, 'imeis': imeis, 'page_title': dn.dn_number,
    })


@login_required
@role_required('admin', 'dispatch', 'warehouse')
def dn_scan_imei(request, pk):
    dn = get_object_or_404(DeliveryNote, pk=pk)
    if dn.status == 'delivered':
        messages.info(request, 'This delivery note is already delivered.')
        return redirect('dispatch:dn_detail', pk=pk)
    scanned = dn.imeis.select_related('fg_unit').all()
    if request.method == 'POST':
        imei = request.POST.get('imei', '').strip()
        if not imei:
            messages.error(request, 'Please scan or enter an IMEI.')
        elif IMEIDispatch.objects.filter(delivery_note=dn, imei=imei).exists():
            messages.warning(request, f'IMEI {imei} already scanned on this delivery note.')
        else:
            from apps.production.models import FinishedGood
            fg = FinishedGood.objects.filter(imei=imei, status='oqc_passed').first()
            if not fg:
                messages.error(request, f'⚠ IMEI {imei} not found in OQC-passed stock. Only OQC-passed devices can be dispatched.')
            else:
                IMEIDispatch.objects.create(
                    delivery_note=dn, fg_unit=fg, imei=imei, scanned_by=request.user,
                )
                messages.success(request, f'✓ IMEI {imei} — {fg.phone_model} added.')
        return redirect('dispatch:dn_scan_imei', pk=pk)
    return render(request, 'dispatch/dn_scan_imei.html', {
        'dn': dn, 'scanned': scanned, 'page_title': f'Scan IMEIs — {dn.dn_number}',
    })


@login_required
@role_required('admin', 'dispatch', 'warehouse')
def dn_dispatch(request, pk):
    dn = get_object_or_404(DeliveryNote, pk=pk)
    if request.method == 'POST':
        if not dn.imeis.exists():
            messages.error(request, 'Cannot dispatch — no IMEIs scanned on this delivery note.')
            return redirect('dispatch:dn_detail', pk=pk)
        with transaction.atomic():
            dn.status = 'dispatched'
            dn.dispatch_date = timezone.now()
            dn.released_by = request.user
            dn.save(update_fields=['status', 'dispatch_date', 'released_by'])
            from apps.production.models import FinishedGood
            for imei_rec in dn.imeis.all():
                FinishedGood.objects.filter(imei=imei_rec.imei).update(
                    status='dispatched', dispatched_at=timezone.now()
                )
            so = dn.sales_order
            so.qty_dispatched = (so.qty_dispatched or 0) + dn.imeis.count()
            if so.qty_dispatched >= so.qty_ordered:
                so.status = 'completed'
            else:
                so.status = 'partial'
            so.save(update_fields=['qty_dispatched', 'status'])
            # GL: DR COGS / CR WIP + DR Receivable / CR Revenue
            try:
                from apps.gl.models import post_dispatch
                unit_price = float(so.unit_price) if hasattr(so, 'unit_price') else 0
                qty = dn.imeis.count()
                total_value = qty * unit_price
                # Estimate COGS as 70% of revenue (can be refined per product)
                cogs_value = total_value * 0.70
                if total_value > 0:
                    post_dispatch(
                        sales_order_number=so.so_number,
                        dn_number=dn.dn_number,
                        total_value=total_value,
                        cogs_value=cogs_value,
                        user=request.user,
                    )
            except Exception as gl_err:
                import logging
                logging.getLogger('elmas').warning(f'[GL] DN dispatch post: {gl_err}')
            # Portal notification to customer
            try:
                from apps.portal.models import CustomerPortalAccess, PortalNotification
                customer = dn.sales_order.customer
                portal = CustomerPortalAccess.objects.filter(
                    customer=customer, status='active'
                ).first()
                if portal:
                    PortalNotification.objects.create(
                        recipient_type='customer',
                        customer_portal=portal,
                        event='dn_dispatched',
                        subject=f'Your Order Has Been Dispatched — {dn.dn_number}',
                        body=f'Your order {dn.sales_order.so_number} has been dispatched.\nDelivery Note: {dn.dn_number}\nUnits: {dn.imeis.count()}\nDate: {timezone.now().strftime("%Y-%m-%d")}',
                        document_ref=dn.dn_number,
                    )
            except Exception:
                pass
        messages.success(request, f'✓ {dn.dn_number} dispatched — {dn.imeis.count()} devices. Pending customer signature.')
    return redirect('dispatch:dn_detail', pk=pk)


@login_required
@role_required('admin', 'dispatch')
def dn_deliver(request, pk):
    dn = get_object_or_404(DeliveryNote, pk=pk)
    if request.method == 'POST':
        dn.status = 'delivered'
        dn.delivery_date = timezone.now()
        dn.customer_signature = request.POST.get('customer_signature', '').strip()
        dn.save(update_fields=['status', 'delivery_date', 'customer_signature'])
        # Portal notification to customer
        try:
            from apps.portal.models import CustomerPortalAccess, PortalNotification
            customer = dn.sales_order.customer
            portal = CustomerPortalAccess.objects.filter(
                customer=customer, status='active'
            ).first()
            if portal:
                PortalNotification.objects.create(
                    recipient_type='customer',
                    customer_portal=portal,
                    event='dn_delivered',
                    subject=f'Delivery Confirmed — {dn.dn_number}',
                    body=f'Your delivery {dn.dn_number} has been confirmed.\n'
                         f'Signed by: {dn.customer_signature}\n'
                         f'Order completion: {dn.sales_order.completion_pct}%',
                    document_ref=dn.dn_number,
                )
        except Exception:
            pass
        messages.success(request, f'✓ Delivery confirmed. Customer: {dn.customer_signature}')
    return redirect('dispatch:dn_detail', pk=pk)


@login_required
def dn_pdf(request, pk):
    from apps.master.models import SystemSettings
    dn = get_object_or_404(DeliveryNote, pk=pk)
    imeis = dn.imeis.select_related('fg_unit').all()
    return render(request, 'dispatch/dn_pdf.html', {
        'dn': dn, 'imeis': imeis, 'sys': SystemSettings.get_settings(),
    })


@login_required
@role_required('admin', 'factory_manager', 'dispatch')
def so_cancel(request, pk):
    """Cancel a Sales Order"""
    so = get_object_or_404(SalesOrder, pk=pk)
    if so.status in ('pending', 'confirmed'):
        if so.delivery_notes.exists():
            messages.error(request, 'Cannot cancel — Delivery Notes already exist for this Sales Order.')
            return redirect('dispatch:so_detail', pk=pk)
        if request.method == 'POST':
            reason = request.POST.get('reason', '').strip()
            if not reason:
                messages.error(request, 'A reason is required to cancel a Sales Order.')
                return redirect('dispatch:so_detail', pk=pk)
            so.status = 'cancelled'
            so.cancellation_reason = reason
            so.cancelled_by = request.user
            so.save(update_fields=['status', 'cancellation_reason', 'cancelled_by'])
            messages.success(request, f'Sales Order {so.so_number} cancelled.')
        return redirect('dispatch:so_detail', pk=pk)
    else:
        messages.error(request, f'Sales Order cannot be cancelled — status: {so.get_status_display()}.')
        return redirect('dispatch:so_detail', pk=pk)


@login_required
@role_required('admin', 'dispatch', 'factory_manager')
def dn_invoice(request, pk):
    """Generate invoice from a delivered Delivery Note"""
    from apps.master.models import SystemSettings
    dn = get_object_or_404(DeliveryNote, pk=pk)
    imeis = dn.imeis.select_related('fg_unit').all()
    sys = SystemSettings.get_settings()
    # Simple invoice — all devices on this DN at a fixed price
    unit_price = float(request.GET.get('unit_price', 0) or 0)
    total = unit_price * imeis.count()
    return render(request, 'dispatch/invoice_pdf.html', {
        'dn': dn, 'imeis': imeis, 'sys': sys,
        'unit_price': unit_price,
        'total': total,
        'page_title': f'Invoice — {dn.dn_number}',
    })


@login_required
@role_required('admin', 'dispatch', 'warehouse')
def carton_create(request, pk):
    """
    Pack scanned IMEIs into cartons for shipping.
    Dispatch officer specifies how many devices per carton.
    System auto-splits into numbered cartons and generates labels.
    """
    dn = get_object_or_404(DeliveryNote, pk=pk)
    if dn.status == 'delivered':
        messages.info(request, 'This delivery note is already delivered.')
        return redirect('dispatch:dn_detail', pk=pk)

    # Get all scanned IMEIs not yet assigned to a carton
    all_imeis = dn.imeis.select_related('fg_unit').order_by('scanned_at')
    already_cartoned = CartonIMEI.objects.filter(
        carton__delivery_note=dn
    ).values_list('imei', flat=True)
    unassigned = [r for r in all_imeis if r.imei not in already_cartoned]
    existing_cartons = dn.cartons.prefetch_related('imeis').all()

    if request.method == 'POST':
        qty_per_carton = int(request.POST.get('qty_per_carton', 0) or 0)
        if qty_per_carton <= 0:
            messages.error(request, 'Please enter a valid quantity per carton.')
            return redirect('dispatch:carton_create', pk=pk)

        try:
            with transaction.atomic():
                # Delete any existing cartons for this DN and rebuild
                dn.cartons.all().delete()
                imei_list = list(all_imeis)
                carton_num = 1
                for i in range(0, len(imei_list), qty_per_carton):
                    batch = imei_list[i:i + qty_per_carton]
                    if not batch:
                        break
                    # Use first device in batch for label description
                    first = batch[0].fg_unit
                    carton = CartonLabel.objects.create(
                        delivery_note=dn,
                        carton_number=carton_num,
                        phone_model=first.phone_model if first else '',
                        colour=first.colour if first else '',
                        storage=first.storage if first else '',
                        qty=len(batch),
                        created_by=request.user,
                    )
                    for rec in batch:
                        CartonIMEI.objects.create(
                            carton=carton,
                            imei_dispatch=rec,
                            imei=rec.imei,
                        )
                    carton_num += 1
                total_cartons = carton_num - 1
                messages.success(
                    request,
                    f'✓ {len(imei_list)} devices packed into {total_cartons} cartons '
                    f'({qty_per_carton}/carton). Labels ready to print.'
                )
                return redirect('dispatch:carton_labels', pk=pk)
        except Exception as e:
            logger.error(f'[carton_create] {e}')
            messages.error(request, f'Error: {e}')

    return render(request, 'dispatch/carton_create.html', {
        'dn': dn,
        'total_imeis': all_imeis.count(),
        'existing_cartons': existing_cartons,
        'page_title': f'Pack Cartons — {dn.dn_number}',
    })


@login_required
@role_required('admin', 'dispatch', 'warehouse')
def carton_labels(request, pk):
    """Print all carton shipping labels for a delivery note."""
    from apps.master.models import SystemSettings
    dn = get_object_or_404(DeliveryNote, pk=pk)
    cartons = dn.cartons.prefetch_related('imeis').order_by('carton_number')
    total_cartons = cartons.count()
    if not total_cartons:
        messages.warning(request, 'No cartons created yet. Pack cartons first.')
        return redirect('dispatch:carton_create', pk=pk)
    return render(request, 'dispatch/carton_labels.html', {
        'dn': dn,
        'cartons': cartons,
        'total_cartons': total_cartons,
        'sys': SystemSettings.get_settings(),
        'page_title': f'Carton Labels — {dn.dn_number}',
    })
