from django.urls import path
from . import views
app_name = 'hr'
urlpatterns = [
    path('',                          views.hr_dashboard,      name='dashboard'),
    path('employees/',                views.employee_list,     name='employee_list'),
    path('employees/create/',         views.employee_create,   name='employee_create'),
    path('employees/<int:pk>/',       views.employee_detail,   name='employee_detail'),
    path('employees/<int:pk>/edit/',  views.employee_edit,     name='employee_edit'),
    path('shifts/',                   views.shift_list,        name='shift_list'),
    path('shifts/create/',            views.shift_create,      name='shift_create'),
    path('shifts/<int:pk>/close/',    views.shift_close,       name='shift_close'),
    path('attendance/',               views.attendance_list,   name='attendance_list'),
    path('payroll/',                  views.payroll_list,      name='payroll_list'),
    path('payroll/create/',           views.payroll_create,    name='payroll_create'),
    path('payroll/<int:pk>/',         views.payroll_detail,    name='payroll_detail'),
    path('payroll/<int:pk>/approve/', views.payroll_approve,   name='payroll_approve'),
]
