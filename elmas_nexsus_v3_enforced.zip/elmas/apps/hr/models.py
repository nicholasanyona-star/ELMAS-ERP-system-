"""
ELMAS-NEXSUS ERP — HR & Payroll
Employee records, shift logging, attendance, labour costing, payroll runs.
Labour costs auto-post to GL WIP accounts.
"""
from django.db import models
from django.conf import settings
from django.utils import timezone
from decimal import Decimal


class Employee(models.Model):
    """
    Full employee record linked to system user account.
    One Employee per User — but Employee can exist without a User (floor staff).
    """
    DESIGNATION_CHOICES = (
        ('factory_manager',    'Factory Manager'),
        ('warehouse_ctrl',     'Warehouse Controller'),
        ('battery_ctrl',       'Battery Controller'),
        ('receiving_officer',  'Receiving Officer'),
        ('qc_officer',         'QC Officer'),
        ('qcii_officer',       'QC II Officer'),
        ('pmc_officer',        'PMC Officer'),
        ('production_super',   'Production Supervisor'),
        ('assembly_operator',  'Assembly Operator'),
        ('packaging_operator', 'Packaging Operator'),
        ('repair_tech',        'Repair Technician'),
        ('sfg_operator',       'SFG Operator'),
        ('fg_controller',      'FG Controller'),
        ('dispatch_officer',   'Dispatch Officer'),
        ('procurement_officer','Procurement Officer'),
        ('general_worker',     'General Worker'),
    )
    EMPLOYMENT_TYPE_CHOICES = (
        ('permanent',   'Permanent'),
        ('contract',    'Contract'),
        ('casual',      'Casual / Daily'),
        ('intern',      'Intern'),
    )
    SALARY_GRADE_CHOICES = (
        ('G1', 'Grade 1 — General Worker'),
        ('G2', 'Grade 2 — Operator'),
        ('G3', 'Grade 3 — Technician'),
        ('G4', 'Grade 4 — Officer'),
        ('G5', 'Grade 5 — Supervisor'),
        ('G6', 'Grade 6 — Controller'),
        ('G7', 'Grade 7 — Manager'),
    )
    STATUS_CHOICES = (
        ('active',     'Active'),
        ('on_leave',   'On Leave'),
        ('suspended',  'Suspended'),
        ('terminated', 'Terminated'),
    )

    employee_number = models.CharField(max_length=20, unique=True, db_index=True)
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='employee_record'
    )
    first_name   = models.CharField(max_length=100)
    last_name    = models.CharField(max_length=100)
    id_number    = models.CharField(max_length=20, unique=True)
    phone        = models.CharField(max_length=20, blank=True)
    email        = models.EmailField(blank=True)
    designation  = models.CharField(max_length=25, choices=DESIGNATION_CHOICES)
    department   = models.CharField(max_length=100, blank=True)
    employment_type = models.CharField(max_length=10, choices=EMPLOYMENT_TYPE_CHOICES, default='permanent')
    salary_grade = models.CharField(max_length=3, choices=SALARY_GRADE_CHOICES, default='G2')
    # Pay rates
    basic_salary = models.DecimalField(
        max_digits=10, decimal_places=2, default=0,
        help_text='Monthly gross salary'
    )
    hourly_rate  = models.DecimalField(
        max_digits=8, decimal_places=2, default=0,
        help_text='Hourly rate for overtime and casual workers'
    )
    # Assignment
    assigned_line = models.ForeignKey(
        'master.ProductionLine', on_delete=models.SET_NULL,
        null=True, blank=True
    )
    cost_centre  = models.ForeignKey(
        'gl.CostCentre', on_delete=models.SET_NULL,
        null=True, blank=True
    )
    # Dates
    date_hired   = models.DateField(null=True, blank=True)
    date_left    = models.DateField(null=True, blank=True)
    status       = models.CharField(max_length=12, choices=STATUS_CHOICES, default='active', db_index=True)
    # Banking (for payslip only — no bank integration)
    bank_name    = models.CharField(max_length=100, blank=True)
    bank_account = models.CharField(max_length=30, blank=True)
    mpesa_number = models.CharField(max_length=15, blank=True)
    created_at   = models.DateTimeField(auto_now_add=True)
    notes        = models.TextField(blank=True)

    class Meta:
        ordering = ['last_name', 'first_name']

    def __str__(self):
        return f"{self.employee_number} — {self.first_name} {self.last_name}"

    def save(self, *args, **kwargs):
        if not self.employee_number:
            count = Employee.objects.count() + 1
            self.employee_number = f"EMP-{str(count).zfill(4)}"
        super().save(*args, **kwargs)

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"


class ShiftRecord(models.Model):
    """
    Records an employee's actual shift on a production line.
    Source for attendance, labour costing, and WO labour allocation.
    """
    SHIFT_CHOICES = (
        ('morning',   'Morning — 06:00 to 14:00'),
        ('afternoon', 'Afternoon — 14:00 to 22:00'),
        ('night',     'Night — 22:00 to 06:00'),
    )
    STATUS_CHOICES = (
        ('open',      'Open — shift in progress'),
        ('closed',    'Closed — shift complete'),
        ('absent',    'Absent — did not report'),
        ('half_day',  'Half Day'),
    )

    employee     = models.ForeignKey(Employee, on_delete=models.PROTECT, related_name='shift_records')
    shift_date   = models.DateField(default=timezone.now, db_index=True)
    shift        = models.CharField(max_length=10, choices=SHIFT_CHOICES)
    production_line = models.ForeignKey(
        'master.ProductionLine', on_delete=models.SET_NULL,
        null=True, blank=True
    )
    work_order   = models.ForeignKey(
        'pmc.WorkOrder', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='shift_records'
    )
    time_in      = models.TimeField(null=True, blank=True)
    time_out     = models.TimeField(null=True, blank=True)
    status       = models.CharField(max_length=10, choices=STATUS_CHOICES, default='open')
    # Computed on close
    hours_worked = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    overtime_hours = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    standard_hours = models.DecimalField(
        max_digits=5, decimal_places=2, default=8,
        help_text='Standard shift hours (usually 8)'
    )
    # Labour cost — computed and posted to GL on close
    labour_cost  = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    gl_posted    = models.BooleanField(default=False)
    gl_entry     = models.ForeignKey(
        'gl.JournalEntry', on_delete=models.SET_NULL,
        null=True, blank=True
    )
    # Supervisor sign-off
    signed_off_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='shifts_signed'
    )
    signed_off_at = models.DateTimeField(null=True, blank=True)
    notes        = models.TextField(blank=True)
    created_at   = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-shift_date', 'shift']
        unique_together = ['employee', 'shift_date', 'shift']

    def __str__(self):
        return f"{self.employee.full_name} — {self.shift_date} {self.shift}"

    def compute_hours(self):
        """Compute hours worked from time_in and time_out"""
        if self.time_in and self.time_out:
            from datetime import datetime, date
            base = date.today()
            dt_in  = datetime.combine(base, self.time_in)
            dt_out = datetime.combine(base, self.time_out)
            if dt_out < dt_in:  # overnight shift
                from datetime import timedelta
                dt_out += timedelta(days=1)
            delta = dt_out - dt_in
            total = Decimal(str(round(delta.total_seconds() / 3600, 2)))
            self.hours_worked = total
            self.overtime_hours = max(Decimal('0'), total - self.standard_hours)
            # Compute labour cost
            rate = self.employee.hourly_rate or (self.employee.basic_salary / Decimal('176'))
            self.labour_cost = total * rate
        return self.hours_worked

    def close_shift(self, signed_by=None):
        """Close shift, compute hours, post labour cost to GL"""
        self.compute_hours()
        self.status = 'closed'
        self.signed_off_by = signed_by
        self.signed_off_at = timezone.now()
        self.save()
        # Post to GL
        if not self.gl_posted and self.labour_cost > 0:
            try:
                from apps.gl.models import post_labour_cost
                cc = self.employee.cost_centre
                wo_num = self.work_order.wo_number if self.work_order else 'OVERHEAD'
                je = post_labour_cost(
                    wo_number=wo_num,
                    employee_name=self.employee.full_name,
                    hours=float(self.hours_worked),
                    rate=float(self.employee.hourly_rate or self.employee.basic_salary / 176),
                    cost_centre=cc,
                    user=signed_by,
                )
                self.gl_entry = je
                self.gl_posted = True
                self.save(update_fields=['gl_entry', 'gl_posted'])
            except Exception as e:
                import logging
                logging.getLogger('elmas').error(f'[HR] close_shift GL post: {e}')


class AttendanceRecord(models.Model):
    """
    Daily attendance summary per employee.
    Auto-generated from ShiftRecord when shift closes.
    """
    ATTENDANCE_STATUS_CHOICES = (
        ('present',    'Present'),
        ('absent',     'Absent'),
        ('late',       'Late'),
        ('half_day',   'Half Day'),
        ('leave',      'On Approved Leave'),
        ('public_hol', 'Public Holiday'),
    )

    employee    = models.ForeignKey(Employee, on_delete=models.PROTECT, related_name='attendance')
    date        = models.DateField(db_index=True)
    status      = models.CharField(max_length=12, choices=ATTENDANCE_STATUS_CHOICES)
    shift_record = models.OneToOneField(
        ShiftRecord, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='attendance_record'
    )
    hours_worked = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    notes       = models.TextField(blank=True)
    created_at  = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-date']
        unique_together = ['employee', 'date']

    def __str__(self):
        return f"{self.employee.full_name} — {self.date} — {self.status}"


class PayrollRun(models.Model):
    """
    Monthly payroll calculation. Generates payslips. Does not integrate with banks.
    GL entry: DR Salaries Payable / CR Cash (manual bank payment outside system).
    """
    STATUS_CHOICES = (
        ('draft',     'Draft'),
        ('submitted', 'Submitted — awaiting FM approval'),
        ('approved',  'Approved — ready for payment'),
        ('paid',      'Paid — payment confirmed'),
    )

    run_number   = models.CharField(max_length=30, unique=True, db_index=True)
    period_month = models.IntegerField()   # 1–12
    period_year  = models.IntegerField()
    status       = models.CharField(max_length=12, choices=STATUS_CHOICES, default='draft')
    total_gross  = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    total_deductions = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    total_net    = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    total_employees = models.IntegerField(default=0)
    gl_entry     = models.ForeignKey(
        'gl.JournalEntry', on_delete=models.SET_NULL,
        null=True, blank=True
    )
    prepared_by  = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='payroll_prepared'
    )
    approved_by  = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='payroll_approved'
    )
    approved_at  = models.DateTimeField(null=True, blank=True)
    payment_date = models.DateField(null=True, blank=True)
    notes        = models.TextField(blank=True)
    created_at   = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-period_year', '-period_month']
        unique_together = ['period_month', 'period_year']

    def __str__(self):
        return f"Payroll {self.period_year}-{self.period_month:02d}"

    def save(self, *args, **kwargs):
        if not self.run_number:
            self.run_number = f"PAY-{self.period_year}-{self.period_month:02d}"
        super().save(*args, **kwargs)


class PayslipLine(models.Model):
    """Individual employee payslip within a payroll run"""
    DEDUCTION_TYPE_CHOICES = (
        ('paye',    'PAYE Tax'),
        ('nssf',    'NSSF'),
        ('nhif',    'NHIF / SHA'),
        ('loan',    'Salary Advance Deduction'),
        ('other',   'Other Deduction'),
    )

    payroll_run  = models.ForeignKey(PayrollRun, on_delete=models.CASCADE, related_name='payslips')
    employee     = models.ForeignKey(Employee, on_delete=models.PROTECT, related_name='payslips')
    days_worked  = models.IntegerField(default=0)
    basic_salary = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    allowances   = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    overtime_pay = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    gross_pay    = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    paye         = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    nssf         = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    nhif         = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    other_deductions = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total_deductions = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    net_pay      = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    notes        = models.TextField(blank=True)

    class Meta:
        ordering = ['employee__last_name']
        unique_together = ['payroll_run', 'employee']

    def __str__(self):
        return f"{self.employee.full_name} — {self.payroll_run}"

    def compute(self):
        """Compute gross, deductions, net"""
        self.gross_pay = self.basic_salary + self.allowances + self.overtime_pay
        self.total_deductions = self.paye + self.nssf + self.nhif + self.other_deductions
        self.net_pay = self.gross_pay - self.total_deductions
