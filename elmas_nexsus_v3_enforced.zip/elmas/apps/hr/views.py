"""ELMAS-NEXSUS ERP — HR & Payroll Views"""
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from apps.accounts.decorators import role_required
from .models import Employee, ShiftRecord, AttendanceRecord, PayrollRun, PayslipLine
import logging
logger = logging.getLogger('elmas')


@login_required
@role_required('admin', 'factory_manager')
def hr_dashboard(request):
    total_employees = Employee.objects.filter(status='active').count()
    today = timezone.now().date()
    present_today = AttendanceRecord.objects.filter(
        date=today, status='present'
    ).count()
    absent_today = AttendanceRecord.objects.filter(
        date=today, status='absent'
    ).count()
    open_shifts = ShiftRecord.objects.filter(status='open').count()
    recent_payroll = PayrollRun.objects.order_by('-period_year', '-period_month').first()
    return render(request, 'hr/dashboard.html', {
        'total_employees': total_employees,
        'present_today':   present_today,
        'absent_today':    absent_today,
        'open_shifts':     open_shifts,
        'recent_payroll':  recent_payroll,
        'page_title':      'HR & Payroll',
    })


@login_required
@role_required('admin', 'factory_manager')
def employee_list(request):
    employees = Employee.objects.select_related(
        'assigned_line', 'user'
    ).order_by('last_name', 'first_name')
    status_filter = request.GET.get('status', 'active')
    if status_filter:
        employees = employees.filter(status=status_filter)
    return render(request, 'hr/employee_list.html', {
        'employees': employees,
        'status_filter': status_filter,
        'page_title': 'Employees',
    })


@login_required
@role_required('admin', 'factory_manager')
def employee_create(request):
    from apps.master.models import ProductionLine
    if request.method == 'POST':
        try:
            emp = Employee.objects.create(
                first_name=request.POST['first_name'].strip(),
                last_name=request.POST['last_name'].strip(),
                id_number=request.POST['id_number'].strip(),
                phone=request.POST.get('phone', '').strip(),
                email=request.POST.get('email', '').strip(),
                designation=request.POST['designation'],
                department=request.POST.get('department', '').strip(),
                employment_type=request.POST.get('employment_type', 'permanent'),
                salary_grade=request.POST.get('salary_grade', 'G2'),
                basic_salary=request.POST.get('basic_salary', 0) or 0,
                hourly_rate=request.POST.get('hourly_rate', 0) or 0,
                bank_name=request.POST.get('bank_name', '').strip(),
                bank_account=request.POST.get('bank_account', '').strip(),
                mpesa_number=request.POST.get('mpesa_number', '').strip(),
            )
            messages.success(request, f'✓ Employee {emp.full_name} ({emp.employee_number}) created.')
            return redirect('hr:employee_detail', pk=emp.pk)
        except Exception as e:
            messages.error(request, f'Error: {e}')
    lines = ProductionLine.objects.filter(is_active=True).order_by('code')
    return render(request, 'hr/employee_form.html', {
        'lines': lines,
        'designation_choices': Employee.DESIGNATION_CHOICES,
        'employment_choices': Employee.EMPLOYMENT_TYPE_CHOICES,
        'grade_choices': Employee.SALARY_GRADE_CHOICES,
        'page_title': 'Add Employee',
    })


@login_required
@role_required('admin', 'factory_manager')
def employee_detail(request, pk):
    emp = get_object_or_404(Employee, pk=pk)
    recent_shifts = emp.shift_records.order_by('-shift_date')[:10]
    recent_attendance = emp.attendance.order_by('-date')[:20]
    return render(request, 'hr/employee_detail.html', {
        'emp': emp,
        'recent_shifts': recent_shifts,
        'recent_attendance': recent_attendance,
        'page_title': emp.full_name,
    })


@login_required
@role_required('admin', 'factory_manager')
def employee_edit(request, pk):
    emp = get_object_or_404(Employee, pk=pk)
    if request.method == 'POST':
        emp.phone = request.POST.get('phone', '').strip()
        emp.department = request.POST.get('department', '').strip()
        emp.designation = request.POST.get('designation', emp.designation)
        emp.salary_grade = request.POST.get('salary_grade', emp.salary_grade)
        emp.basic_salary = request.POST.get('basic_salary', emp.basic_salary) or 0
        emp.hourly_rate = request.POST.get('hourly_rate', emp.hourly_rate) or 0
        emp.status = request.POST.get('status', emp.status)
        emp.bank_name = request.POST.get('bank_name', '').strip()
        emp.bank_account = request.POST.get('bank_account', '').strip()
        emp.mpesa_number = request.POST.get('mpesa_number', '').strip()
        emp.notes = request.POST.get('notes', '').strip()
        emp.save()
        messages.success(request, f'✓ {emp.full_name} updated.')
        return redirect('hr:employee_detail', pk=pk)
    return render(request, 'hr/employee_form.html', {
        'emp': emp,
        'designation_choices': Employee.DESIGNATION_CHOICES,
        'employment_choices': Employee.EMPLOYMENT_TYPE_CHOICES,
        'grade_choices': Employee.SALARY_GRADE_CHOICES,
        'page_title': f'Edit — {emp.full_name}',
    })


@login_required
@role_required('admin', 'factory_manager', 'production')
def shift_list(request):
    shifts = ShiftRecord.objects.select_related(
        'employee', 'production_line', 'work_order'
    ).order_by('-shift_date', 'shift')[:100]
    return render(request, 'hr/shift_list.html', {
        'shifts': shifts,
        'page_title': 'Shift Records',
    })


@login_required
@role_required('admin', 'factory_manager', 'production')
def shift_create(request):
    from apps.master.models import ProductionLine
    from apps.pmc.models import WorkOrder
    if request.method == 'POST':
        try:
            emp = Employee.objects.get(pk=request.POST['employee'])
            line_pk = request.POST.get('production_line')
            wo_pk = request.POST.get('work_order')
            ShiftRecord.objects.create(
                employee=emp,
                shift_date=request.POST['shift_date'],
                shift=request.POST['shift'],
                production_line_id=line_pk or None,
                work_order_id=wo_pk or None,
                time_in=request.POST.get('time_in') or None,
                status='open',
            )
            messages.success(request, f'✓ Shift opened for {emp.full_name}.')
            return redirect('hr:shift_list')
        except Exception as e:
            messages.error(request, f'Error: {e}')
    employees = Employee.objects.filter(status='active').order_by('last_name')
    lines = ProductionLine.objects.filter(is_active=True).order_by('code')
    wos = WorkOrder.objects.filter(status='in_progress').order_by('-created_at')[:20]
    return render(request, 'hr/shift_form.html', {
        'employees': employees, 'lines': lines, 'work_orders': wos,
        'shift_choices': ShiftRecord.SHIFT_CHOICES,
        'page_title': 'Open Shift',
    })


@login_required
@role_required('admin', 'factory_manager', 'production')
def shift_close(request, pk):
    shift = get_object_or_404(ShiftRecord, pk=pk)
    if request.method == 'POST':
        shift.time_out = request.POST.get('time_out') or None
        shift.notes = request.POST.get('notes', '').strip()
        shift.save()
        shift.close_shift(signed_by=request.user)
        messages.success(
            request,
            f'✓ Shift closed — {shift.hours_worked}hrs worked. '
            f'Labour cost: Kshs {shift.labour_cost}.'
            f'{" GL posted." if shift.gl_posted else ""}'
        )
    return redirect('hr:shift_list')


@login_required
@role_required('admin', 'factory_manager', 'production')
def attendance_list(request):
    from datetime import date
    today = date.today()
    records = AttendanceRecord.objects.filter(
        date=today
    ).select_related('employee').order_by('employee__last_name')
    return render(request, 'hr/attendance_list.html', {
        'records': records, 'today': today,
        'page_title': f'Attendance — {today}',
    })


@login_required
@role_required('admin', 'factory_manager')
def payroll_list(request):
    runs = PayrollRun.objects.order_by('-period_year', '-period_month')
    return render(request, 'hr/payroll_list.html', {
        'runs': runs, 'page_title': 'Payroll Runs',
    })


@login_required
@role_required('admin', 'factory_manager')
def payroll_create(request):
    if request.method == 'POST':
        month = int(request.POST['month'])
        year = int(request.POST['year'])
        if PayrollRun.objects.filter(period_month=month, period_year=year).exists():
            messages.error(request, f'Payroll for {year}-{month:02d} already exists.')
            return redirect('hr:payroll_list')
        run = PayrollRun.objects.create(
            period_month=month, period_year=year,
            prepared_by=request.user, status='draft',
        )
        # Auto-generate payslip lines from active employees
        employees = Employee.objects.filter(status='active')
        total_gross = 0
        for emp in employees:
            gross = float(emp.basic_salary)
            paye = gross * 0.15 if gross > 24000 else 0
            nssf = min(gross * 0.06, 2160)
            nhif = 500
            deductions = paye + nssf + nhif
            net = gross - deductions
            PayslipLine.objects.create(
                payroll_run=run,
                employee=emp,
                days_worked=26,
                basic_salary=emp.basic_salary,
                gross_pay=gross,
                paye=paye,
                nssf=nssf,
                nhif=nhif,
                total_deductions=deductions,
                net_pay=net,
            )
            total_gross += gross
        run.total_gross = total_gross
        run.total_employees = employees.count()
        run.save(update_fields=['total_gross', 'total_employees'])
        messages.success(request, f'✓ Payroll {run.run_number} created with {run.total_employees} employees.')
        return redirect('hr:payroll_detail', pk=run.pk)
    return render(request, 'hr/payroll_create.html', {'page_title': 'New Payroll Run'})


@login_required
@role_required('admin', 'factory_manager')
def payroll_detail(request, pk):
    run = get_object_or_404(PayrollRun, pk=pk)
    payslips = run.payslips.select_related('employee').order_by('employee__last_name')
    return render(request, 'hr/payroll_detail.html', {
        'run': run, 'payslips': payslips,
        'page_title': str(run),
    })


@login_required
@role_required('admin', 'factory_manager')
def payroll_approve(request, pk):
    run = get_object_or_404(PayrollRun, pk=pk)
    if request.method == 'POST':
        if run.status != 'draft':
            messages.error(request, 'Payroll is not in draft status.')
            return redirect('hr:payroll_detail', pk=pk)
        # Sum totals
        from django.db.models import Sum
        totals = run.payslips.aggregate(
            gross=Sum('gross_pay'), deductions=Sum('total_deductions'), net=Sum('net_pay')
        )
        run.total_gross      = totals['gross'] or 0
        run.total_deductions = totals['deductions'] or 0
        run.total_net        = totals['net'] or 0
        run.status           = 'approved'
        run.approved_by      = request.user
        run.approved_at      = timezone.now()
        run.save()
        # Post to GL
        try:
            from apps.gl.models import get_system_account, post_journal
            from decimal import Decimal
            labour_acc  = get_system_account('labour_cost')
            payable_acc = get_system_account('payable')
            if labour_acc and payable_acc:
                gross = Decimal(str(run.total_gross))
                je = post_journal(
                    description=f'Payroll: {run.run_number} — {run.total_employees} employees',
                    source='payroll_run',
                    reference=run.run_number,
                    source_app='hr',
                    source_model='PayrollRun',
                    source_id=run.pk,
                    posted_by=request.user,
                    lines=[
                        (labour_acc,  gross, 0,     f'Gross payroll: {run.run_number}'),
                        (payable_acc, 0,     gross,  f'Payroll payable: {run.run_number}'),
                    ]
                )
                run.gl_entry = je
                run.save(update_fields=['gl_entry'])
        except Exception as e:
            logger.error(f'[HR] payroll GL post: {e}')
        messages.success(request, f'✓ Payroll {run.run_number} approved. GL entry posted.')
    return redirect('hr:payroll_detail', pk=pk)
