"""
ELMAS-NEXSUS ERP — HR Migration 0001
Initial: Employee, ShiftRecord, AttendanceRecord, PayrollRun, PayslipLine
"""
from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone
from django.conf import settings


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ('master', '0002_new_types_settings_lines'),
        ('pmc', '0009_mrn_submitted_at'),
        ('gl', '0001_initial'),
        ('accounts', '0004_user_assigned_line'),
    ]

    operations = [

        migrations.CreateModel(
            name='Employee',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True)),
                ('employee_number', models.CharField(db_index=True, max_length=20, unique=True)),
                ('first_name', models.CharField(max_length=100)),
                ('last_name', models.CharField(max_length=100)),
                ('id_number', models.CharField(max_length=20, unique=True)),
                ('phone', models.CharField(blank=True, max_length=20)),
                ('email', models.EmailField(blank=True)),
                ('designation', models.CharField(
                    choices=[
                        ('factory_manager', 'Factory Manager'),
                        ('warehouse_ctrl', 'Warehouse Controller'),
                        ('battery_ctrl', 'Battery Controller'),
                        ('receiving_officer', 'Receiving Officer'),
                        ('qc_officer', 'QC Officer'),
                        ('qcii_officer', 'QC II Officer'),
                        ('pmc_officer', 'PMC Officer'),
                        ('production_super', 'Production Supervisor'),
                        ('assembly_operator', 'Assembly Operator'),
                        ('packaging_operator', 'Packaging Operator'),
                        ('repair_tech', 'Repair Technician'),
                        ('sfg_operator', 'SFG Operator'),
                        ('fg_controller', 'FG Controller'),
                        ('dispatch_officer', 'Dispatch Officer'),
                        ('procurement_officer', 'Procurement Officer'),
                        ('general_worker', 'General Worker'),
                    ],
                    max_length=25,
                )),
                ('department', models.CharField(blank=True, max_length=100)),
                ('employment_type', models.CharField(
                    choices=[
                        ('permanent', 'Permanent'), ('contract', 'Contract'),
                        ('casual', 'Casual / Daily'), ('intern', 'Intern'),
                    ],
                    default='permanent', max_length=10,
                )),
                ('salary_grade', models.CharField(
                    choices=[
                        ('G1', 'Grade 1'), ('G2', 'Grade 2'), ('G3', 'Grade 3'),
                        ('G4', 'Grade 4'), ('G5', 'Grade 5'), ('G6', 'Grade 6'),
                        ('G7', 'Grade 7'),
                    ],
                    default='G2', max_length=3,
                )),
                ('basic_salary', models.DecimalField(decimal_places=2, default=0, max_digits=10)),
                ('hourly_rate', models.DecimalField(decimal_places=2, default=0, max_digits=8)),
                ('date_hired', models.DateField(blank=True, null=True)),
                ('date_left', models.DateField(blank=True, null=True)),
                ('status', models.CharField(
                    choices=[
                        ('active', 'Active'), ('on_leave', 'On Leave'),
                        ('suspended', 'Suspended'), ('terminated', 'Terminated'),
                    ],
                    db_index=True, default='active', max_length=12,
                )),
                ('bank_name', models.CharField(blank=True, max_length=100)),
                ('bank_account', models.CharField(blank=True, max_length=30)),
                ('mpesa_number', models.CharField(blank=True, max_length=15)),
                ('notes', models.TextField(blank=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('user', models.OneToOneField(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='employee_record',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('assigned_line', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    to='master.productionline',
                )),
                ('cost_centre', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    to='gl.costcentre',
                )),
            ],
            options={'ordering': ['last_name', 'first_name']},
        ),

        migrations.CreateModel(
            name='ShiftRecord',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True)),
                ('shift_date', models.DateField(db_index=True, default=django.utils.timezone.now)),
                ('shift', models.CharField(
                    choices=[
                        ('morning', 'Morning — 06:00 to 14:00'),
                        ('afternoon', 'Afternoon — 14:00 to 22:00'),
                        ('night', 'Night — 22:00 to 06:00'),
                    ],
                    max_length=10,
                )),
                ('time_in', models.TimeField(blank=True, null=True)),
                ('time_out', models.TimeField(blank=True, null=True)),
                ('status', models.CharField(
                    choices=[
                        ('open', 'Open'), ('closed', 'Closed'),
                        ('absent', 'Absent'), ('half_day', 'Half Day'),
                    ],
                    default='open', max_length=10,
                )),
                ('hours_worked', models.DecimalField(decimal_places=2, default=0, max_digits=5)),
                ('overtime_hours', models.DecimalField(decimal_places=2, default=0, max_digits=5)),
                ('standard_hours', models.DecimalField(decimal_places=2, default=8, max_digits=5)),
                ('labour_cost', models.DecimalField(decimal_places=2, default=0, max_digits=10)),
                ('gl_posted', models.BooleanField(default=False)),
                ('notes', models.TextField(blank=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('signed_off_at', models.DateTimeField(blank=True, null=True)),
                ('employee', models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    related_name='shift_records', to='hr.employee',
                )),
                ('production_line', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    to='master.productionline',
                )),
                ('work_order', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='shift_records', to='pmc.workorder',
                )),
                ('gl_entry', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    to='gl.journalentry',
                )),
                ('signed_off_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='shifts_signed',
                    to=settings.AUTH_USER_MODEL,
                )),
            ],
            options={
                'ordering': ['-shift_date', 'shift'],
                'unique_together': {('employee', 'shift_date', 'shift')},
            },
        ),

        migrations.CreateModel(
            name='AttendanceRecord',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True)),
                ('date', models.DateField(db_index=True)),
                ('status', models.CharField(
                    choices=[
                        ('present', 'Present'), ('absent', 'Absent'),
                        ('late', 'Late'), ('half_day', 'Half Day'),
                        ('leave', 'On Approved Leave'), ('public_hol', 'Public Holiday'),
                    ],
                    max_length=12,
                )),
                ('hours_worked', models.DecimalField(decimal_places=2, default=0, max_digits=5)),
                ('notes', models.TextField(blank=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('employee', models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    related_name='attendance', to='hr.employee',
                )),
                ('shift_record', models.OneToOneField(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='attendance_record', to='hr.shiftrecord',
                )),
            ],
            options={
                'ordering': ['-date'],
                'unique_together': {('employee', 'date')},
            },
        ),

        migrations.CreateModel(
            name='PayrollRun',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True)),
                ('run_number', models.CharField(db_index=True, max_length=30, unique=True)),
                ('period_month', models.IntegerField()),
                ('period_year', models.IntegerField()),
                ('status', models.CharField(
                    choices=[
                        ('draft', 'Draft'), ('submitted', 'Submitted'),
                        ('approved', 'Approved'), ('paid', 'Paid'),
                    ],
                    default='draft', max_length=12,
                )),
                ('total_gross', models.DecimalField(decimal_places=2, default=0, max_digits=12)),
                ('total_deductions', models.DecimalField(decimal_places=2, default=0, max_digits=12)),
                ('total_net', models.DecimalField(decimal_places=2, default=0, max_digits=12)),
                ('total_employees', models.IntegerField(default=0)),
                ('notes', models.TextField(blank=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('payment_date', models.DateField(blank=True, null=True)),
                ('approved_at', models.DateTimeField(blank=True, null=True)),
                ('gl_entry', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    to='gl.journalentry',
                )),
                ('prepared_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='payroll_prepared',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('approved_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='payroll_approved',
                    to=settings.AUTH_USER_MODEL,
                )),
            ],
            options={
                'ordering': ['-period_year', '-period_month'],
                'unique_together': {('period_month', 'period_year')},
            },
        ),

        migrations.CreateModel(
            name='PayslipLine',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True)),
                ('days_worked', models.IntegerField(default=0)),
                ('basic_salary', models.DecimalField(decimal_places=2, default=0, max_digits=10)),
                ('allowances', models.DecimalField(decimal_places=2, default=0, max_digits=10)),
                ('overtime_pay', models.DecimalField(decimal_places=2, default=0, max_digits=10)),
                ('gross_pay', models.DecimalField(decimal_places=2, default=0, max_digits=10)),
                ('paye', models.DecimalField(decimal_places=2, default=0, max_digits=10)),
                ('nssf', models.DecimalField(decimal_places=2, default=0, max_digits=10)),
                ('nhif', models.DecimalField(decimal_places=2, default=0, max_digits=10)),
                ('other_deductions', models.DecimalField(decimal_places=2, default=0, max_digits=10)),
                ('total_deductions', models.DecimalField(decimal_places=2, default=0, max_digits=10)),
                ('net_pay', models.DecimalField(decimal_places=2, default=0, max_digits=10)),
                ('notes', models.TextField(blank=True)),
                ('payroll_run', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='payslips', to='hr.payrollrun',
                )),
                ('employee', models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    related_name='payslips', to='hr.employee',
                )),
            ],
            options={
                'ordering': ['employee__last_name'],
                'unique_together': {('payroll_run', 'employee')},
            },
        ),
    ]
