from django.contrib import admin
from .models import Employee, ShiftRecord, AttendanceRecord, PayrollRun, PayslipLine


class PayslipLineInline(admin.TabularInline):
    model = PayslipLine
    extra = 0
    readonly_fields = ('gross_pay', 'total_deductions', 'net_pay')


@admin.register(Employee)
class EmployeeAdmin(admin.ModelAdmin):
    list_display = ('employee_number', 'full_name', 'designation', 'status', 'assigned_line')
    list_filter = ('status', 'designation', 'employment_type', 'salary_grade')
    search_fields = ('employee_number', 'first_name', 'last_name', 'id_number')
    ordering = ('last_name', 'first_name')


@admin.register(ShiftRecord)
class ShiftRecordAdmin(admin.ModelAdmin):
    list_display = ('employee', 'shift_date', 'shift', 'status', 'hours_worked', 'labour_cost', 'gl_posted')
    list_filter = ('shift', 'status', 'gl_posted', 'shift_date')
    search_fields = ('employee__first_name', 'employee__last_name')
    readonly_fields = ('hours_worked', 'overtime_hours', 'labour_cost', 'gl_posted')


@admin.register(AttendanceRecord)
class AttendanceAdmin(admin.ModelAdmin):
    list_display = ('employee', 'date', 'status', 'hours_worked')
    list_filter = ('status', 'date')
    search_fields = ('employee__first_name', 'employee__last_name')


@admin.register(PayrollRun)
class PayrollRunAdmin(admin.ModelAdmin):
    list_display = ('run_number', 'period_month', 'period_year', 'status', 'total_net', 'total_employees')
    list_filter = ('status', 'period_year')
    readonly_fields = ('total_gross', 'total_deductions', 'total_net', 'total_employees')
    inlines = [PayslipLineInline]
