"""ELMAS QC Views — IQC, Quarantine, SFG"""
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from django.db import transaction
from apps.accounts.decorators import role_required
from .models import AQLTable, DefectCode, SFGDefectCode, SFGUnit, SFGMovement
import logging
logger = logging.getLogger('elmas')


@login_required
@role_required('admin', 'qc', 'warehouse', 'factory_manager')
def iqc_list(request):
    from apps.receiving.models import GRN
    pending = GRN.objects.filter(status='verified').select_related('received_by', 'verified_by').order_by('verified_at')
    completed = GRN.objects.filter(status__in=['iqc_pass', 'iqc_fail', 'partial']).order_by('-verified_at')[:20]
    return render(request, 'qc/iqc_list.html', {
        'pending': pending, 'completed': completed, 'page_title': 'IQC — Incoming Quality Control',
    })


@login_required
@role_required('admin', 'qc', 'factory_manager')
def iqc_detail(request, pk):
    from apps.receiving.models import GRN, IQCInspection
    grn = get_object_or_404(GRN, pk=pk)
    inspection = IQCInspection.objects.filter(grn=grn).first()
    batches = grn.stockbatch_set.all() if hasattr(grn, 'stockbatch_set') else []
    return render(request, 'qc/iqc_detail.html', {
        'grn': grn, 'inspection': inspection, 'page_title': f'IQC — {grn.grn_number}',
    })


@login_required
@role_required('admin', 'qc')
def iqc_inspect(request, pk):
    from apps.receiving.models import GRN, IQCInspection, IQCDefect
    from apps.inventory.models import StockBatch
    grn = get_object_or_404(GRN, pk=pk)
    if grn.status != 'verified':
        messages.error(request, 'GRN must be verified before IQC inspection.')
        return redirect('qc:iqc_list')
    total_qty = sum(line.quantity_received for line in grn.lines.all())
    sample_size = AQLTable.get_sample_size(int(total_qty))
    defect_codes = DefectCode.objects.filter(is_active=True).order_by('severity', 'code')
    if request.method == 'POST':
        try:
            with transaction.atomic():
                inspection, _ = IQCInspection.objects.get_or_create(
                    grn=grn,
                    defaults={'inspected_by': request.user, 'sample_size': sample_size, 'batch_size': int(total_qty)}
                )
                inspection.sample_size = sample_size
                inspection.batch_size = int(total_qty)
                inspection.remarks = request.POST.get('notes', '')
                inspection.save()
                # Record defects
                IQCDefect.objects.filter(inspection=inspection).delete()
                defect_pks = request.POST.getlist('defect_code')
                defect_qtys = request.POST.getlist('defect_qty')
                for dpk, dqty in zip(defect_pks, defect_qtys):
                    if dpk and dqty:
                        try:
                            dc = DefectCode.objects.get(pk=int(dpk))
                            IQCDefect.objects.create(
                                inspection=inspection,
                                defect_type=dc.code,
                                quantity_affected=int(dqty),
                                severity=dc.severity,
                            )
                        except Exception as e:
                            logger.warning(f'[iqc_inspect] defect: {e}')
                messages.success(request, 'Inspection recorded. Now make your decision.')
                return redirect('qc:iqc_decision', pk=pk)
        except Exception as e:
            messages.error(request, f'Error: {e}')
    return render(request, 'qc/iqc_inspect.html', {
        'grn': grn, 'sample_size': sample_size, 'total_qty': total_qty,
        'defect_codes': defect_codes, 'page_title': f'Inspect — {grn.grn_number}',
    })


@login_required
@role_required('admin', 'qc')
def iqc_decision(request, pk):
    from apps.receiving.models import GRN, IQCInspection, Quarantine
    from apps.inventory.models import StockBatch
    from apps.master.models import Warehouse, SystemSettings
    grn = get_object_or_404(GRN, pk=pk)
    inspection = get_object_or_404(IQCInspection, grn=grn)
    defects = inspection.defects.all()
    has_critical = defects.filter(severity='critical').exists()
    if request.method == 'POST':
        decision = request.POST.get('decision')
        qty_accepted = float(request.POST.get('qty_accepted', 0) or 0)
        qty_rejected = float(request.POST.get('qty_rejected', 0) or 0)
        defect_type = request.POST.get('defect_type', '').strip()
        notes = request.POST.get('notes', '').strip()
        try:
            with transaction.atomic():
                inspection.decision = decision
                inspection.quantity_accepted = qty_accepted
                inspection.quantity_rejected = qty_rejected
                inspection.inspected_at = timezone.now()
                inspection.save()
                batches = StockBatch.objects.filter(grn_number=grn.grn_number, status='iqc')
                s = SystemSettings.get_settings()
                if decision == 'pass':
                    _release_to_inventory(batches, grn, request.user)
                    grn.status = 'iqc_pass'
                    messages.success(request, f'✓ IQC PASSED — all items released to inventory.')
                elif decision == 'fail':
                    _send_to_quarantine(batches, grn, inspection, defect_type, notes, request.user, s)
                    grn.status = 'iqc_fail'
                    messages.warning(request, f'✗ IQC FAILED — all items sent to Quarantine.')
                elif decision == 'partial':
                    total = sum(b.quantity_received for b in batches)
                    if qty_accepted > 0:
                        _release_partial(batches, grn, qty_accepted, request.user)
                    if qty_rejected > 0:
                        _quarantine_partial(batches, grn, inspection, qty_rejected, defect_type, notes, request.user, s)
                    grn.status = 'partial'
                    messages.success(request, f'✓ Partial IQC — {qty_accepted:.0f} accepted, {qty_rejected:.0f} to quarantine.')
                grn.save(update_fields=['status'])
                # Portal notification to supplier
                try:
                    from apps.portal.models import SupplierPortalAccess, PortalNotification
                    if grn.supplier:
                        portal = SupplierPortalAccess.objects.filter(
                            supplier=grn.supplier, status='active'
                        ).first()
                        if portal:
                            event_map = {
                                'pass': 'iqc_pass', 'fail': 'iqc_fail', 'partial': 'iqc_partial'
                            }
                            PortalNotification.objects.create(
                                recipient_type='supplier',
                                supplier_portal=portal,
                                event=event_map.get(decision, 'iqc_pass'),
                                subject=f'IQC Result: {grn.grn_number} — {decision.upper()}',
                                body=f'IQC inspection for {grn.grn_number} has been completed.\nResult: {decision.upper()}\nDate: {timezone.now().strftime("%Y-%m-%d")}',
                                document_ref=grn.grn_number,
                                created_by=request.user,
                            )
                except Exception:
                    pass
        except Exception as e:
            logger.error(f'[iqc_decision] {e}')
            messages.error(request, f'Error: {e}')
        return redirect('qc:iqc_list')
    total_qty = sum(b.quantity_received for b in StockBatch.objects.filter(grn_number=grn.grn_number))
    return render(request, 'qc/iqc_decision.html', {
        'grn': grn, 'inspection': inspection, 'defects': defects,
        'has_critical': has_critical, 'total_qty': total_qty,
        'page_title': f'IQC Decision — {grn.grn_number}',
    })


def _release_to_inventory(batches, grn, user):
    """Move batches to correct warehouse based on category and item type"""
    from apps.master.models import Warehouse
    from apps.inventory.models import StockMovement
    category = grn.material_category
    wh_map = {
        'raw_material': 'raw_material',
        'packaging':    'packaging',
        'consumable':   'consumables',
        'battery':      'battery',
    }
    wh_type = wh_map.get(category, 'raw_material')
    target_wh = Warehouse.objects.filter(
        warehouse_type=wh_type, is_active=True
    ).first()
    for batch in batches:
        # Battery products always route to battery warehouse
        if batch.product.is_battery and wh_type != 'battery':
            bat_wh = Warehouse.objects.filter(
                warehouse_type='battery', is_active=True
            ).first()
            if bat_wh:
                target_wh = bat_wh
        batch.warehouse = target_wh
        batch.status = 'available'
        batch.released_at = timezone.now()
        batch.save(update_fields=['warehouse', 'status', 'released_at'])
        StockMovement.objects.create(
            product=batch.product,
            batch=batch,
            movement_type='iqc_pass',
            quantity=batch.quantity_received,
            from_location='IQC Area',
            to_location=target_wh.name if target_wh else 'Inventory',
            performed_by=user,
            reference=grn.grn_number,
        )
        # GL: DR Inventory / CR Accounts Payable
        try:
            from apps.gl.models import post_stock_receipt
            post_stock_receipt(
                product=batch.product,
                qty=float(batch.quantity_received),
                unit_cost=float(batch.product.unit_cost),
                grn_number=grn.grn_number,
                user=user,
            )
        except Exception as e:
            logger.warning(f'[GL] IQC pass post: {e}')


def _send_to_quarantine(batches, grn, inspection, defect_type, notes, user, sys_settings):
    from apps.receiving.models import Quarantine
    from apps.master.models import Warehouse
    quar_wh = Warehouse.objects.filter(warehouse_type='quarantine', is_active=True).first()
    # Determine deadline based on defect severity
    has_critical = inspection.defects.filter(severity='critical').exists()
    has_major = inspection.defects.filter(severity='major').exists()
    if has_critical:
        hours = 24
    elif has_major:
        hours = 48
    else:
        hours = 72
    deadline = timezone.now() + timezone.timedelta(hours=hours)
    for batch in batches:
        batch.warehouse = quar_wh
        batch.status = 'quarantine'
        batch.save(update_fields=['warehouse', 'status'])
    # Get first product from GRN lines for required FK
    from apps.inventory.models import Product
    first_product = None
    try:
        first_product = grn.lines.first().product
    except Exception:
        first_product = Product.objects.filter(is_active=True).first()
    Quarantine.objects.create(
        grn=grn,
        inspection=inspection,
        product=first_product,
        defect_summary=defect_type or notes,
        quantity=sum(b.quantity_received for b in batches),
        deadline=deadline,
        status='pending',
        quarantined_by=user,
    )


def _release_partial(batches, grn, qty_accepted, user):
    from apps.master.models import Warehouse
    from apps.inventory.models import StockMovement
    wh_map = {'raw_material': 'raw_material', 'packaging': 'packaging', 'consumable': 'consumables'}
    wh_type = wh_map.get(grn.material_category, 'raw_material')
    target_wh = Warehouse.objects.filter(warehouse_type=wh_type, is_active=True).first()
    remaining = qty_accepted
    for batch in batches:
        if remaining <= 0:
            break
        accept_qty = min(batch.remaining_quantity, remaining)
        batch.quantity_received = accept_qty
        batch.remaining_quantity = accept_qty
        batch.warehouse = target_wh
        batch.status = 'available'
        batch.save(update_fields=['quantity_received', 'remaining_quantity', 'warehouse', 'status'])
        remaining -= accept_qty


def _quarantine_partial(batches, grn, inspection, qty_rejected, defect_type, notes, user, sys_settings):
    from apps.receiving.models import Quarantine
    from apps.master.models import Warehouse
    quar_wh = Warehouse.objects.filter(warehouse_type='quarantine', is_active=True).first()
    has_critical = inspection.defects.filter(severity='critical').exists()
    hours = 24 if has_critical else 48
    deadline = timezone.now() + timezone.timedelta(hours=hours)
    from apps.inventory.models import Product
    first_product = None
    try:
        first_product = grn.lines.first().product
    except Exception:
        first_product = Product.objects.filter(is_active=True).first()
    Quarantine.objects.create(
        grn=grn, inspection=inspection,
        product=first_product,
        defect_summary=defect_type or notes,
        quantity=qty_rejected,
        deadline=deadline,
        status='pending',
        quarantined_by=user,
    )


@login_required
def iqc_pdf(request, pk):
    from apps.receiving.models import GRN, IQCInspection
    from apps.master.models import SystemSettings
    grn = get_object_or_404(GRN, pk=pk)
    inspection = get_object_or_404(IQCInspection, grn=grn)
    defects = inspection.defects.all()
    return render(request, 'qc/iqc_pdf.html', {
        'grn': grn, 'inspection': inspection, 'defects': defects,
        'sys': SystemSettings.get_settings(),
    })


@login_required
@role_required('admin', 'qc', 'warehouse', 'factory_manager')
def quarantine_list(request):
    from apps.receiving.models import Quarantine
    items = Quarantine.objects.select_related('grn', 'quarantined_by').order_by('deadline')
    status_filter = request.GET.get('status', 'pending')
    if status_filter:
        items = items.filter(status=status_filter)
    return render(request, 'qc/quarantine_list.html', {
        'items': items, 'status_filter': status_filter,
        'now': timezone.now(), 'page_title': 'Quarantine Bay',
    })


@login_required
@role_required('admin', 'qc', 'factory_manager')
def quarantine_detail(request, pk):
    from apps.receiving.models import Quarantine
    item = get_object_or_404(Quarantine, pk=pk)
    return render(request, 'qc/quarantine_detail.html', {
        'item': item, 'now': timezone.now(), 'page_title': f'Quarantine — {item.grn.grn_number}',
    })


@login_required
@role_required('admin', 'factory_manager')
def quarantine_decide(request, pk):
    from apps.receiving.models import Quarantine
    from apps.inventory.models import StockBatch, StockMovement
    item = get_object_or_404(Quarantine, pk=pk)
    if request.method == 'POST':
        decision = request.POST.get('decision')
        notes = request.POST.get('notes', '').strip()
        item.decision = decision
        item.decision_notes = notes
        item.decided_by = request.user
        item.decided_at = timezone.now()
        item.status = 'resolved'
        item.save()
        batches = StockBatch.objects.filter(grn_number=item.grn.grn_number, status='quarantine')
        if decision in ('accept', 'accept_with_discount'):
            _release_to_inventory(batches, item.grn, request.user)
            messages.success(request, '✓ Accepted — items moved to inventory.')
        elif decision == 'return_supplier':
            batches.update(status='returned')
            messages.info(request, 'Items marked for return to supplier. Inform Procurement.')
        elif decision == 'scrap':
            batches.update(status='scrapped')
            messages.warning(request, 'Items scrapped and written off inventory.')
        return redirect('qc:quarantine_list')
    return render(request, 'qc/quarantine_decide.html', {
        'item': item, 'page_title': 'Quarantine Decision',
    })


@login_required
def quarantine_pdf(request, pk):
    from apps.receiving.models import Quarantine
    from apps.master.models import SystemSettings
    item = get_object_or_404(Quarantine, pk=pk)
    return render(request, 'qc/quarantine_pdf.html', {
        'item': item, 'sys': SystemSettings.get_settings(), 'now': timezone.now(),
    })


@login_required
@role_required('admin', 'qc2', 'factory_manager', 'production')
def sfg_list(request):
    units = SFGUnit.objects.select_related(
        'defect_code', 'current_location', 'sent_by', 'received_by'
    ).order_by('created_at')
    status_filter = request.GET.get('status', 'in_sfg')
    if status_filter:
        units = units.filter(status=status_filter)
    source_filter = request.GET.get('source', '')
    if source_filter:
        units = units.filter(source_stage=source_filter)
    return render(request, 'qc/sfg_list.html', {
        'units': units, 'status_filter': status_filter, 'source_filter': source_filter,
        'now': timezone.now(), 'page_title': 'SFG Warehouse',
        'status_choices': SFGUnit.STATUS_CHOICES,
        'source_choices': SFGUnit.SOURCE_CHOICES,
    })


@login_required
@role_required('admin', 'production', 'qc2', 'factory_manager')
def sfg_create(request):
    defect_codes = SFGDefectCode.objects.filter(is_active=True).order_by('source_stage', 'code')
    from apps.master.models import Bin
    from apps.master.models import Warehouse
    sfg_wh = Warehouse.objects.filter(warehouse_type='sfg').first()
    bins = Bin.objects.filter(zone__room__warehouse=sfg_wh, is_active=True).select_related(
        'zone__room__warehouse'
    ) if sfg_wh else []
    if request.method == 'POST':
        source_stage = request.POST.get('source_stage')
        source_location = request.POST.get('source_location', '').strip()
        defect_pk = request.POST.get('defect_code')
        defect_notes = request.POST.get('defect_notes', '').strip()
        imei = request.POST.get('imei', '').strip() or None
        bin_pk = request.POST.get('current_location')
        sent_by_id = request.POST.get('sent_by')
        try:
            defect = SFGDefectCode.objects.get(pk=defect_pk) if defect_pk else None
            bin_loc = Bin.objects.get(pk=bin_pk) if bin_pk else None
            # Check if this IMEI has been in SFG before — increment entry count
            existing = SFGUnit.objects.filter(imei=imei).order_by('-created_at').first() if imei else None
            unit = SFGUnit.objects.create(
                source_stage=source_stage,
                source_location=source_location,
                defect_code=defect,
                defect_notes=defect_notes,
                imei=imei,
                current_location=bin_loc,
                sent_by=request.user,
                entry_count=existing.entry_count + 1 if existing else 1,
                requires_manager_approval=(existing.entry_count + 1 >= 2) if existing else False,
            )
            SFGMovement.objects.create(
                unit=unit,
                movement_type='entry',
                from_location=f'{source_stage} — {source_location}',
                to_location=bin_loc.full_code if bin_loc else 'SFG',
                notes=defect_notes,
                signed_by=request.user,
            )
            messages.success(request, f'✓ Unit {unit.sfg_code} registered in SFG.')
            return redirect('qc:sfg_detail', pk=unit.pk)
        except Exception as e:
            messages.error(request, f'Error: {e}')
    from apps.accounts.models import User
    supervisors = User.objects.filter(role='production', is_active=True)
    return render(request, 'qc/sfg_create.html', {
        'defect_codes': defect_codes, 'bins': bins,
        'supervisors': supervisors,
        'source_choices': SFGUnit.SOURCE_CHOICES,
        'page_title': 'Register Unit in SFG',
    })


@login_required
@role_required('admin', 'qc2', 'production', 'factory_manager')
def sfg_detail(request, pk):
    unit = get_object_or_404(SFGUnit, pk=pk)
    movements = unit.movements.select_related('signed_by', 'countersigned_by').order_by('created_at')
    return render(request, 'qc/sfg_detail.html', {
        'unit': unit, 'movements': movements,
        'hours_in_sfg': unit.hours_in_sfg,
        'page_title': unit.sfg_code,
    })


@login_required
@role_required('admin', 'qc2', 'factory_manager')
def sfg_move(request, pk):
    unit = get_object_or_404(SFGUnit, pk=pk)
    if unit.entry_count >= 2 and not unit.manager_approved:
        if request.method == 'POST' and request.user.role not in ('admin', 'factory_manager'):
            messages.error(request, '⚠ This unit has been in SFG before. Factory Manager must approve the move.')
            return redirect('qc:sfg_detail', pk=pk)
    if request.method == 'POST':
        destination = request.POST.get('destination')
        notes = request.POST.get('notes', '').strip()
        imei = request.POST.get('imei', '').strip()
        from_loc = unit.current_location.full_code if unit.current_location else 'SFG'
        status_map = {
            'assembly': 'returned_assembly',
            'aging': 'returned_aging',
            'packaging': 'returned_packaging',
            'fg': 'to_fg',
            'scrap': 'scrapped',
        }
        movement_map = {
            'assembly': 'exit_assembly',
            'aging': 'exit_aging',
            'packaging': 'exit_packaging',
            'fg': 'exit_fg',
            'scrap': 'exit_scrap',
        }
        if destination == 'fg' and not (imei or unit.imei):
            messages.error(request, '⚠ IMEI is mandatory when moving to Finished Goods.')
            return redirect('qc:sfg_move', pk=pk)
        if destination == 'scrap' and not unit.manager_approved:
            if request.user.role not in ('admin', 'factory_manager'):
                messages.error(request, '⚠ Scrapping requires Factory Manager approval.')
                return redirect('qc:sfg_detail', pk=pk)
        try:
            if imei:
                unit.imei = imei
            unit.status = status_map.get(destination, 'in_sfg')
            unit.current_location = None
            unit.save(update_fields=['status', 'current_location', 'imei'])
            SFGMovement.objects.create(
                unit=unit,
                movement_type=movement_map.get(destination, 'internal_move'),
                from_location=from_loc,
                to_location=destination,
                notes=notes,
                signed_by=request.user,
            )
            # Auto-create FinishedGood record when moved to FG
            if destination == 'fg':
                try:
                    from apps.production.models import FinishedGood
                    if not FinishedGood.objects.filter(imei=unit.imei).exists():
                        FinishedGood.objects.create(
                            imei=unit.imei,
                            phone_model=unit.defect_code.source_stage if unit.defect_code else 'Unknown',
                            work_order=None,
                            status='oqc_pending',
                            received_by=request.user,
                        )
                        logger.info(f'[sfg_move] FinishedGood auto-created for IMEI {unit.imei}')
                except Exception as fg_err:
                    logger.warning(f'[sfg_move] FG auto-create failed: {fg_err}')
            messages.success(request, f'✓ Unit {unit.sfg_code} moved to {destination}.')
            return redirect('qc:sfg_list')
        except Exception as e:
            messages.error(request, f'Error: {e}')
    return render(request, 'qc/sfg_move.html', {
        'unit': unit, 'page_title': f'Move {unit.sfg_code}',
    })


@login_required
def sfg_pdf(request, pk):
    from apps.master.models import SystemSettings
    unit = get_object_or_404(SFGUnit, pk=pk)
    movements = unit.movements.select_related('signed_by').all()
    return render(request, 'qc/sfg_pdf.html', {
        'unit': unit, 'movements': movements,
        'sys': SystemSettings.get_settings(),
    })
