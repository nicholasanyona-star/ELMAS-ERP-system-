"""
ELMAS QC Migration 0002
- Add severity, is_reworkable, responsible_stage to SFGDefectCode
- Add tuid, assembly_line, entry_reason, current_stage,
  ps_verified_by/at, unfinished_reason, missing_component to SFGUnit
- Expand SFGMovement movement_type choices
"""
from django.db import migrations, models
import django.db.models.deletion
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('qc', '0001_initial'),
        ('master', '0002_new_types_settings_lines'),
        ('inventory', '0004_product_aql_level'),
        ('accounts', '0004_user_assigned_line'),
    ]

    operations = [

        # SFGDefectCode — new fields
        migrations.AddField(
            model_name='sfgdefectcode',
            name='severity',
            field=models.CharField(
                choices=[
                    ('critical', 'Critical — automatic fail'),
                    ('major', 'Major — significant defect'),
                    ('minor', 'Minor — cosmetic/low impact'),
                ],
                default='major', max_length=10,
            ),
        ),
        migrations.AddField(
            model_name='sfgdefectcode',
            name='is_reworkable',
            field=models.BooleanField(default=True),
        ),
        migrations.AddField(
            model_name='sfgdefectcode',
            name='responsible_stage',
            field=models.CharField(
                choices=[
                    ('assembly', 'Assembly'),
                    ('component', 'Component'),
                    ('aging', 'Aging'),
                    ('packaging', 'Packaging'),
                ],
                default='assembly', max_length=12,
            ),
        ),

        # SFGUnit — new fields
        migrations.AddField(
            model_name='sfgunit',
            name='tuid',
            field=models.CharField(blank=True, db_index=True, max_length=50, null=True),
        ),
        migrations.AddField(
            model_name='sfgunit',
            name='entry_reason',
            field=models.CharField(
                choices=[
                    ('defective', 'Defective — awaiting QCII'),
                    ('unfinished', 'Unfinished — temporary hold'),
                    ('good_hold', 'Good — temporary hold'),
                    ('post_repair', 'Post repair'),
                    ('oqc_fail', 'OQC Failed'),
                ],
                default='defective', max_length=15,
            ),
        ),
        migrations.AddField(
            model_name='sfgunit',
            name='unfinished_reason',
            field=models.CharField(blank=True, max_length=25),
        ),
        migrations.AddField(
            model_name='sfgunit',
            name='current_stage',
            field=models.CharField(blank=True, max_length=15),
        ),
        migrations.AddField(
            model_name='sfgunit',
            name='ps_verified_by',
            field=models.ForeignKey(
                blank=True, null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='sfg_ps_verifications',
                to=settings.AUTH_USER_MODEL,
            ),
        ),
        migrations.AddField(
            model_name='sfgunit',
            name='ps_verified_at',
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name='sfgunit',
            name='ps_verification_notes',
            field=models.TextField(blank=True),
        ),
        migrations.AddField(
            model_name='sfgunit',
            name='assembly_line',
            field=models.ForeignKey(
                blank=True, null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                to='master.productionline',
            ),
        ),
        migrations.AddField(
            model_name='sfgunit',
            name='missing_component',
            field=models.ForeignKey(
                blank=True, null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='sfg_missing',
                to='inventory.product',
            ),
        ),

        # Expand SFGMovement choices
        migrations.AlterField(
            model_name='sfgmovement',
            name='movement_type',
            field=models.CharField(
                choices=[
                    ('entry_assembly', 'Entered SFG ← Assembly'),
                    ('entry_aging', 'Entered SFG ← Aging'),
                    ('entry_packaging', 'Entered SFG ← Packaging'),
                    ('entry_qcii', 'Entered SFG ← QCII'),
                    ('entry_repair', 'Entered SFG ← Repair Station'),
                    ('to_qcii', 'Sent to QCII'),
                    ('to_repair', 'Sent to Repair Station'),
                    ('to_assembly', 'Sent to Assembly — pending PS'),
                    ('to_aging', 'Sent to Aging — pending PS'),
                    ('to_packaging', 'Sent to Packaging — pending PS'),
                    ('ps_verified', 'PS Verified Receipt'),
                    ('internal_move', 'Moved within SFG'),
                    ('to_fg', 'Released to FG'),
                    ('scrapped', 'Scrapped'),
                    ('entry', 'Entered SFG'),
                    ('exit_assembly', 'Sent to Assembly'),
                    ('exit_aging', 'Sent to Aging'),
                    ('exit_packaging', 'Sent to Packaging'),
                    ('exit_fg', 'Sent to FG'),
                    ('exit_scrap', 'Scrapped'),
                ],
                max_length=20,
            ),
        ),

        # Expand SFGUnit status choices
        migrations.AlterField(
            model_name='sfgunit',
            name='status',
            field=models.CharField(
                choices=[
                    ('sfg_good_hold', 'SFG — Good unit, temporary hold'),
                    ('sfg_defect_hold', 'SFG — Defective, awaiting QCII'),
                    ('sfg_unfinished', 'SFG — Unfinished'),
                    ('sfg_post_qcii', 'SFG — Post QCII'),
                    ('sfg_post_repair', 'SFG — Post repair'),
                    ('in_qcii', 'With QCII'),
                    ('in_repair', 'At Repair Station'),
                    ('pending_ps_assembly', 'Pending PS verify — Assembly'),
                    ('pending_ps_aging', 'Pending PS verify — Aging'),
                    ('pending_ps_packaging', 'Pending PS verify — Packaging'),
                    ('in_assembly', 'In Assembly — PS verified'),
                    ('in_aging', 'In Aging Room'),
                    ('in_packaging', 'In Packaging — PS verified'),
                    ('ready_for_fg', 'Ready for FG'),
                    ('scrapped', 'Scrapped — FM approved'),
                    ('in_sfg', 'In SFG'),
                    ('returned_assembly', 'Returned to Assembly'),
                    ('returned_aging', 'Returned to Aging'),
                    ('returned_packaging', 'Returned to Packaging'),
                    ('to_fg', 'Moved to FG'),
                ],
                db_index=True, default='in_sfg', max_length=25,
            ),
        ),
    ]
