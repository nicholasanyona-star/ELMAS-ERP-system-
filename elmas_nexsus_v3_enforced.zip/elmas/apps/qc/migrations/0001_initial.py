from django.db import migrations, models
import django.db.models.deletion
from django.conf import settings


class Migration(migrations.Migration):
    initial = True
    dependencies = [
        ('master', '0001_initial'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='AQLTable',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('batch_size_min', models.IntegerField()),
                ('batch_size_max', models.IntegerField()),
                ('sample_size', models.IntegerField()),
                ('accept_critical', models.IntegerField(default=0)),
                ('accept_major', models.IntegerField(default=1)),
                ('accept_minor', models.IntegerField(default=2)),
                ('aql_level', models.CharField(default='2.5', max_length=10)),
            ],
            options={'ordering': ['batch_size_min']},
        ),
        migrations.CreateModel(
            name='DefectCode',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('code', models.CharField(max_length=20, unique=True)),
                ('description', models.CharField(max_length=200)),
                ('severity', models.CharField(choices=[('critical', 'Critical'), ('major', 'Major'), ('minor', 'Minor')], max_length=10)),
                ('is_active', models.BooleanField(default=True)),
            ],
            options={'ordering': ['severity', 'code']},
        ),
        migrations.CreateModel(
            name='SFGDefectCode',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('code', models.CharField(max_length=20, unique=True)),
                ('description', models.CharField(max_length=200)),
                ('source_stage', models.CharField(choices=[('assembly', 'Assembly Line'), ('aging', 'Aging Room'), ('packaging', 'Packaging Line')], max_length=20)),
                ('is_active', models.BooleanField(default=True)),
            ],
            options={'ordering': ['source_stage', 'code']},
        ),
        migrations.CreateModel(
            name='SFGUnit',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('sfg_code', models.CharField(db_index=True, max_length=50, unique=True)),
                ('imei', models.CharField(blank=True, db_index=True, max_length=20, null=True)),
                ('source_stage', models.CharField(choices=[('assembly', 'Assembly Line'), ('aging', 'Aging Room'), ('packaging', 'Packaging Line')], max_length=20)),
                ('source_location', models.CharField(blank=True, max_length=100)),
                ('defect_notes', models.TextField(blank=True)),
                ('status', models.CharField(choices=[('in_sfg', 'In SFG'), ('returned_assembly', 'Returned to Assembly'), ('returned_aging', 'Returned to Aging'), ('returned_packaging', 'Returned to Packaging'), ('to_fg', 'Moved to FG'), ('scrapped', 'Scrapped')], db_index=True, default='in_sfg', max_length=25)),
                ('entry_count', models.IntegerField(default=1)),
                ('requires_manager_approval', models.BooleanField(default=False)),
                ('manager_approved', models.BooleanField(default=False)),
                ('created_at', models.DateTimeField(auto_now_add=True, db_index=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('current_location', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='sfg_units', to='master.bin')),
                ('defect_code', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to='qc.sfgdefectcode')),
                ('manager_approved_by', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='sfg_approvals', to=settings.AUTH_USER_MODEL)),
                ('received_by', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='sfg_received', to=settings.AUTH_USER_MODEL)),
                ('sent_by', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='sfg_sent', to=settings.AUTH_USER_MODEL)),
            ],
            options={'ordering': ['-created_at']},
        ),
        migrations.CreateModel(
            name='SFGMovement',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('movement_type', models.CharField(choices=[('entry', 'Entered SFG'), ('internal_move', 'Moved within SFG'), ('exit_assembly', 'Sent to Assembly'), ('exit_aging', 'Sent to Aging'), ('exit_packaging', 'Sent to Packaging'), ('exit_fg', 'Sent to FG'), ('exit_scrap', 'Scrapped')], max_length=20)),
                ('from_location', models.CharField(blank=True, max_length=200)),
                ('to_location', models.CharField(blank=True, max_length=200)),
                ('notes', models.TextField(blank=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('countersigned_by', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='sfg_movements_countersigned', to=settings.AUTH_USER_MODEL)),
                ('signed_by', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='sfg_movements_signed', to=settings.AUTH_USER_MODEL)),
                ('unit', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='movements', to='qc.sfgunit')),
            ],
            options={'ordering': ['created_at']},
        ),
    ]
