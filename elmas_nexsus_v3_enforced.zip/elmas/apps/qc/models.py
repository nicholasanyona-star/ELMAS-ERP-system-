"""
ELMAS QC Models
IQC and OQC inspections, quarantine, defect tracking
"""
from django.db import models
from django.conf import settings
from django.utils import timezone


class AQLTable(models.Model):
    """AQL reference table for sample sizes"""
    batch_size_min = models.IntegerField()
    batch_size_max = models.IntegerField()
    sample_size = models.IntegerField()
    accept_critical = models.IntegerField(default=0)
    accept_major = models.IntegerField(default=1)
    accept_minor = models.IntegerField(default=2)
    aql_level = models.CharField(max_length=10, default='2.5')

    class Meta:
        ordering = ['batch_size_min']

    def __str__(self):
        return f"AQL {self.aql_level}: {self.batch_size_min}-{self.batch_size_max} → sample {self.sample_size}"

    @classmethod
    def get_sample_size(cls, batch_qty):
        table = cls.objects.filter(
            batch_size_min__lte=batch_qty,
            batch_size_max__gte=batch_qty
        ).first()
        if table:
            return table.sample_size
        if batch_qty > 0:
            return min(int(batch_qty * 0.1), 200)
        return 0

    @classmethod
    def get_acceptance_numbers(cls, batch_qty, aql_level='2.5'):
        """
        Return full AQL acceptance numbers for a given batch size and level.
        Returns dict with sample_size, accept_critical, accept_major,
        accept_minor, rejection_number — or None if not found.
        """
        table = cls.objects.filter(
            batch_size_min__lte=batch_qty,
            batch_size_max__gte=batch_qty,
            aql_level=aql_level
        ).first()
        if not table:
            # Fallback: find closest table entry
            table = cls.objects.filter(
                batch_size_min__lte=batch_qty,
            ).order_by('-batch_size_min').first()
        if table:
            return {
                'sample_size':     table.sample_size,
                'accept_critical': table.accept_critical,
                'accept_major':    table.accept_major,
                'accept_minor':    table.accept_minor,
                'rejection_number': table.accept_major + 1,
            }
        # Hardcoded fallback if no AQL table data loaded yet
        fallback = [
            (2, 2), (8, 3), (15, 5), (25, 8),
            (50, 13), (90, 20), (150, 32), (280, 50),
            (500, 80), (1200, 125), (3200, 200),
            (10000, 315),
        ]
        sample = 32
        for max_b, s in fallback:
            if batch_qty <= max_b:
                sample = s
                break
        return {
            'sample_size':     sample,
            'accept_critical': 0,
            'accept_major':    2,
            'accept_minor':    3,
            'rejection_number': 3,
        }


class DefectCode(models.Model):
    """Pre-defined defect codes for IQC"""
    SEVERITY_CHOICES = (
        ('critical', 'Critical'),
        ('major', 'Major'),
        ('minor', 'Minor'),
    )
    code = models.CharField(max_length=20, unique=True)
    description = models.CharField(max_length=200)
    severity = models.CharField(max_length=10, choices=SEVERITY_CHOICES)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['severity', 'code']

    def __str__(self):
        return f"{self.code} — {self.description}"


class SFGDefectCode(models.Model):
    """Defect codes specific to SFG from production stages"""
    SOURCE_CHOICES = (
        ('assembly', 'Assembly Line'),
        ('aging',    'Aging Room'),
        ('packaging','Packaging Line'),
    )
    SEVERITY_CHOICES = (
        ('critical', 'Critical — automatic fail'),
        ('major',    'Major — significant defect'),
        ('minor',    'Minor — cosmetic/low impact'),
    )
    RESPONSIBLE_STAGE_CHOICES = (
        ('assembly',  'Assembly — defect from assembly process'),
        ('component', 'Component — defective incoming component'),
        ('aging',     'Aging — defect developed during aging'),
        ('packaging', 'Packaging — defect from packaging process'),
    )
    code = models.CharField(max_length=20, unique=True)
    description = models.CharField(max_length=200)
    source_stage = models.CharField(max_length=20, choices=SOURCE_CHOICES)
    severity = models.CharField(
        max_length=10, choices=SEVERITY_CHOICES, default='major'
    )
    is_reworkable = models.BooleanField(
        default=True,
        help_text='Can this defect be repaired, or is it a write-off?'
    )
    responsible_stage = models.CharField(
        max_length=12, choices=RESPONSIBLE_STAGE_CHOICES,
        default='assembly',
        help_text='Which stage is responsible for this defect type'
    )
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['source_stage', 'code']

    def __str__(self):
        return f"{self.code} — {self.description}"


class SFGUnit(models.Model):
    """
    A device in the SFG warehouse
    Tracked from production line through resolution
    """
    STATUS_CHOICES = (
        ('sfg_good_hold',       'SFG — Good unit, temporary hold'),
        ('sfg_defect_hold',     'SFG — Defective, awaiting QCII'),
        ('sfg_unfinished',      'SFG — Unfinished, awaiting component'),
        ('sfg_post_qcii',       'SFG — Post QCII, awaiting move'),
        ('sfg_post_repair',     'SFG — Post repair, awaiting return'),
        ('in_qcii',             'With QCII — under inspection'),
        ('in_repair',           'At Repair Station'),
        ('pending_ps_assembly', 'Pending PS verify — Assembly'),
        ('pending_ps_aging',    'Pending PS verify — Aging'),
        ('pending_ps_packaging','Pending PS verify — Packaging'),
        ('in_assembly',         'In Assembly — PS verified'),
        ('in_aging',            'In Aging Room'),
        ('in_packaging',        'In Packaging — PS verified'),
        ('ready_for_fg',        'Ready for FG — awaiting FG Controller'),
        ('scrapped',            'Scrapped — FM approved'),
        # Legacy
        ('in_sfg',              'In SFG'),
        ('returned_assembly',   'Returned to Assembly'),
        ('returned_aging',      'Returned to Aging'),
        ('returned_packaging',  'Returned to Packaging'),
        ('to_fg',               'Moved to FG'),
    )
    SOURCE_CHOICES = (
        ('assembly',  'Assembly Line'),
        ('aging',     'Aging Room'),
        ('packaging', 'Packaging Line'),
        ('qcii',      'QC II'),
        ('repair',    'Repair Station'),
    )
    ENTRY_REASON_CHOICES = (
        ('defective',    'Defective — awaiting QCII'),
        ('unfinished',   'Unfinished — temporary hold'),
        ('good_hold',    'Good — temporary hold before next stage'),
        ('post_repair',  'Post repair — awaiting return to production'),
        ('oqc_fail',     'OQC Failed — returned from FG'),
    )

    sfg_code = models.CharField(max_length=50, unique=True, db_index=True)
    imei = models.CharField(max_length=20, blank=True, null=True, db_index=True)
    tuid = models.CharField(
        max_length=50, blank=True, null=True, db_index=True,
        help_text='TUID from AssemblyUnit — links this unit to production tracking'
    )
    source_stage = models.CharField(max_length=20, choices=SOURCE_CHOICES)
    source_location = models.CharField(max_length=100, blank=True)
    assembly_line = models.ForeignKey(
        'master.ProductionLine', on_delete=models.SET_NULL,
        null=True, blank=True
    )
    entry_reason = models.CharField(
        max_length=15, choices=ENTRY_REASON_CHOICES,
        default='defective'
    )
    unfinished_reason = models.CharField(
        max_length=25,
        choices=(
            ('missing_component', 'Missing Component'),
            ('awaiting_battery',  'Awaiting Battery'),
            ('awaiting_software', 'Awaiting Software'),
            ('shift_ended',       'Shift Ended'),
            ('quality_hold',      'Quality Hold'),
        ),
        blank=True
    )
    missing_component = models.ForeignKey(
        'inventory.Product', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='sfg_missing'
    )
    defect_code = models.ForeignKey(
        SFGDefectCode, on_delete=models.SET_NULL, null=True, blank=True
    )
    defect_notes = models.TextField(blank=True)
    current_location = models.ForeignKey(
        'master.Bin', on_delete=models.SET_NULL, null=True, blank=True,
        related_name='sfg_units'
    )
    current_stage = models.CharField(
        max_length=15, blank=True,
        help_text='Where unit physically is right now'
    )
    status = models.CharField(
        max_length=25, choices=STATUS_CHOICES, default='in_sfg', db_index=True
    )
    ps_verified_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='sfg_ps_verifications'
    )
    ps_verified_at = models.DateTimeField(null=True, blank=True)
    ps_verification_notes = models.TextField(blank=True)
    entry_count = models.IntegerField(default=1)
    requires_manager_approval = models.BooleanField(default=False)
    manager_approved = models.BooleanField(default=False)
    manager_approved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='sfg_approvals'
    )
    sent_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='sfg_sent'
    )
    received_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='sfg_received'
    )
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.sfg_code

    def save(self, *args, **kwargs):
        if not self.sfg_code:
            today = timezone.now().strftime('%Y%m%d')
            count = SFGUnit.objects.filter(
                sfg_code__startswith=f'SFG-{today}'
            ).count() + 1
            self.sfg_code = f"SFG-{today}-{str(count).zfill(4)}"
        super().save(*args, **kwargs)

    @property
    def hours_in_sfg(self):
        delta = timezone.now() - self.created_at
        return round(delta.total_seconds() / 3600, 1)


class SFGMovement(models.Model):
    """Every movement of a device in/out of SFG — full trail"""
    MOVEMENT_TYPE_CHOICES = (
        ('entry_assembly',    'Entered SFG ← Assembly'),
        ('entry_aging',       'Entered SFG ← Aging'),
        ('entry_packaging',   'Entered SFG ← Packaging'),
        ('entry_qcii',        'Entered SFG ← QCII'),
        ('entry_repair',      'Entered SFG ← Repair Station'),
        ('to_qcii',           'Sent to QCII'),
        ('to_repair',         'Sent to Repair Station'),
        ('to_assembly',       'Sent to Assembly — pending PS'),
        ('to_aging',          'Sent to Aging — pending PS'),
        ('to_packaging',      'Sent to Packaging — pending PS'),
        ('ps_verified',       'PS Verified Receipt'),
        ('internal_move',     'Moved within SFG'),
        ('to_fg',             'Released to FG'),
        ('scrapped',          'Scrapped'),
        # Legacy
        ('entry',             'Entered SFG'),
        ('exit_assembly',     'Sent to Assembly'),
        ('exit_aging',        'Sent to Aging'),
        ('exit_packaging',    'Sent to Packaging'),
        ('exit_fg',           'Sent to FG'),
        ('exit_scrap',        'Scrapped'),
    )
    unit = models.ForeignKey(SFGUnit, on_delete=models.CASCADE, related_name='movements')
    movement_type = models.CharField(max_length=20, choices=MOVEMENT_TYPE_CHOICES)
    from_location = models.CharField(max_length=200, blank=True)
    to_location = models.CharField(max_length=200, blank=True)
    notes = models.TextField(blank=True)
    signed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='sfg_movements_signed'
    )
    countersigned_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='sfg_movements_countersigned'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['created_at']

    def __str__(self):
        return f"{self.unit.sfg_code} — {self.get_movement_type_display()}"
