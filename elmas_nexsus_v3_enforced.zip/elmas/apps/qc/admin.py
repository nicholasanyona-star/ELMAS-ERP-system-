from django.contrib import admin
from .models import AQLTable, DefectCode, SFGDefectCode, SFGUnit, SFGMovement


@admin.register(AQLTable)
class AQLTableAdmin(admin.ModelAdmin):
    list_display = ('batch_size_min', 'batch_size_max', 'sample_size', 'aql_level', 'accept_critical', 'accept_major', 'accept_minor')
    ordering = ('batch_size_min',)


@admin.register(DefectCode)
class DefectCodeAdmin(admin.ModelAdmin):
    list_display = ('code', 'description', 'severity', 'is_active')
    list_filter = ('severity', 'is_active')
    search_fields = ('code', 'description')


@admin.register(SFGDefectCode)
class SFGDefectCodeAdmin(admin.ModelAdmin):
    list_display = ('code', 'description', 'source_stage', 'is_active')
    list_filter = ('source_stage', 'is_active')
    search_fields = ('code', 'description')


@admin.register(SFGUnit)
class SFGUnitAdmin(admin.ModelAdmin):
    list_display = ('sfg_code', 'imei', 'source_stage', 'defect_code', 'status', 'created_at')
    list_filter = ('status', 'source_stage')
    search_fields = ('sfg_code', 'imei')
    ordering = ('-created_at',)


@admin.register(SFGMovement)
class SFGMovementAdmin(admin.ModelAdmin):
    list_display = ('unit', 'movement_type', 'from_location', 'to_location', 'signed_by', 'created_at')
    list_filter = ('movement_type',)
    ordering = ('-created_at',)
