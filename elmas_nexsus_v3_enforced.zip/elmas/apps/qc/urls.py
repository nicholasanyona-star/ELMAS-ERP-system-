from django.urls import path
from . import views
app_name = 'qc'
urlpatterns = [
    path('iqc/', views.iqc_list, name='iqc_list'),
    path('iqc/<int:pk>/', views.iqc_detail, name='iqc_detail'),
    path('iqc/<int:pk>/inspect/', views.iqc_inspect, name='iqc_inspect'),
    path('iqc/<int:pk>/decision/', views.iqc_decision, name='iqc_decision'),
    path('iqc/<int:pk>/pdf/', views.iqc_pdf, name='iqc_pdf'),
    path('quarantine/', views.quarantine_list, name='quarantine_list'),
    path('quarantine/<int:pk>/', views.quarantine_detail, name='quarantine_detail'),
    path('quarantine/<int:pk>/decide/', views.quarantine_decide, name='quarantine_decide'),
    path('quarantine/<int:pk>/pdf/', views.quarantine_pdf, name='quarantine_pdf'),
    path('sfg/', views.sfg_list, name='sfg_list'),
    path('sfg/create/', views.sfg_create, name='sfg_create'),
    path('sfg/<int:pk>/', views.sfg_detail, name='sfg_detail'),
    path('sfg/<int:pk>/move/', views.sfg_move, name='sfg_move'),
    path('sfg/<int:pk>/pdf/', views.sfg_pdf, name='sfg_pdf'),
]
