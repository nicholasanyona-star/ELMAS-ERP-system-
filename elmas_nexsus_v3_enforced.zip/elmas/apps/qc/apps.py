from django.apps import AppConfig

class QcConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.qc'
    verbose_name = 'Qc'
