"""
ELMAS Inventory Models
Products, stock batches, FIFO engine, movements, MMN
"""
from django.db import models
from django.conf import settings
from django.utils import timezone
from django.db.models import Sum, F


class Product(models.Model):
    """
    Product/material — built from real deliveries
    No pre-entry required — system learns as goods arrive
    """
    CATEGORY_CHOICES = (
        ('raw_material', 'Raw Material'),
        ('packaging',    'Packaging Material'),
        ('consumable',   'Consumable'),
        ('sfg',          'Semi-Finished Good'),
        ('fg',           'Finished Good'),
    )

    ITEM_TYPE_CHOICES = (
        ('general',     'General Component'),
        ('battery',     'Battery'),
        ('display',     'Display/LCD'),
        ('pcb',         'PCB/Mainboard'),
        ('camera',      'Camera Module'),
        ('housing',     'Housing/Casing'),
        ('cable',       'Cable/Connector'),
        ('accessory',   'Accessory'),
        ('packaging',   'Packaging Material'),
        ('consumable',  'Consumable'),
        ('other',       'Other'),
    )

    # Identity
    name = models.CharField(max_length=200, db_index=True)
    sku = models.CharField(
        max_length=100, unique=True, db_index=True,
        help_text='Auto-generated if left blank'
    )
    barcode = models.CharField(
        max_length=100, blank=True, null=True,
        db_index=True,
        help_text='Scanned barcode or QR code'
    )
    category = models.CharField(
        max_length=20,
        choices=CATEGORY_CHOICES,
        default='raw_material',
        db_index=True
    )
    item_type = models.CharField(
        max_length=20,
        choices=ITEM_TYPE_CHOICES,
        default='general',
        help_text='Determines routing after IQC (batteries go to Battery Room)'
    )
    uom = models.CharField(
        max_length=20,
        default='EA',
        help_text='Unit of measure: EA, KG, M, L, BOX, ROLL'
    )
    description = models.TextField(blank=True)

    # Pricing
    unit_cost = models.DecimalField(
        max_digits=15, decimal_places=2, default=0
    )

    # Stock levels
    reorder_point = models.DecimalField(
        max_digits=15, decimal_places=2, default=0,
        help_text='Alert when stock falls below this'
    )
    minimum_stock = models.DecimalField(
        max_digits=15, decimal_places=2, default=0
    )
    maximum_stock = models.DecimalField(
        max_digits=15, decimal_places=2, default=0
    )

    # Status
    is_active = models.BooleanField(default=True, db_index=True)
    is_described = models.BooleanField(
        default=True,
        help_text='False if accepted but not yet fully described'
    )

    # AQL level for IQC sampling
    aql_level = models.CharField(
        max_length=5,
        choices=(
            ('1.0', 'AQL 1.0 — Tight (Battery, PCB, Critical)'),
            ('1.5', 'AQL 1.5 — Moderate (Display, LCD)'),
            ('2.5', 'AQL 2.5 — Standard (Raw Materials)'),
            ('4.0', 'AQL 4.0 — Loose (Packaging, Consumables)'),
            ('6.5', 'AQL 6.5 — Very Loose (Low risk only)'),
        ),
        default='2.5',
        help_text='AQL inspection level — set per product based on criticality'
    )

    # Audit
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='created_products'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['name']
        indexes = [
            models.Index(fields=['category', 'is_active']),
            models.Index(fields=['item_type', 'is_active']),
            models.Index(fields=['barcode']),
        ]

    def __str__(self):
        return f"{self.sku} — {self.name}"

    def save(self, *args, **kwargs):
        if not self.sku:
            prefix_map = {
                'raw_material': 'RM',
                'packaging': 'PKG',
                'consumable': 'CONS',
                'sfg': 'SFG',
                'fg': 'FG',
            }
            prefix = prefix_map.get(self.category, 'ITEM')
            count = Product.objects.filter(
                sku__startswith=prefix
            ).count() + 1
            self.sku = f"{prefix}-{str(count).zfill(5)}"
        super().save(*args, **kwargs)

    @property
    def current_stock(self):
        return get_current_stock(self)

    @property
    def is_battery(self):
        return self.item_type == 'battery'

    @property
    def stock_status(self):
        stock = self.current_stock
        if stock == 0:
            return 'OUT'
        elif stock <= float(self.minimum_stock):
            return 'CRITICAL'
        elif stock <= float(self.reorder_point):
            return 'LOW'
        return 'OK'


class Supplier(models.Model):
    """Supplier / vendor"""
    code = models.CharField(max_length=20, unique=True, db_index=True)
    name = models.CharField(max_length=200, db_index=True)
    kra_pin = models.CharField(max_length=20, blank=True)
    phone = models.CharField(max_length=50, blank=True)
    email = models.EmailField(blank=True)
    address = models.TextField(blank=True)
    payment_terms = models.CharField(max_length=100, blank=True)
    contact_person = models.CharField(max_length=100, blank=True)
    is_active = models.BooleanField(default=True)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return f"{self.code} — {self.name}"

    def save(self, *args, **kwargs):
        if not self.code:
            count = Supplier.objects.count() + 1
            self.code = f"SUP-{str(count).zfill(4)}"
        super().save(*args, **kwargs)


class StockBatch(models.Model):
    """
    A batch of stock — the FIFO unit
    Created when IQC passes and stock is released to inventory
    """
    STATUS_CHOICES = (
        ('waiting',     'In Waiting Bay'),
        ('iqc',         'In IQC'),
        ('quarantine',  'In Quarantine'),
        ('available',   'Available — in inventory'),
        ('depleted',    'Depleted'),
        ('reserved',    'Reserved for WO'),
        ('returned',    'Returned to Supplier'),
        ('scrapped',    'Scrapped — written off'),
        ('mretn_hold',  'Returned from Production — pending WC'),
    )

    batch_number = models.CharField(
        max_length=50, unique=True, db_index=True
    )
    product = models.ForeignKey(
        Product,
        on_delete=models.PROTECT,
        related_name='batches',
        db_index=True
    )
    supplier = models.ForeignKey(
        Supplier,
        on_delete=models.SET_NULL,
        null=True, blank=True
    )

    # Quantities
    quantity_received = models.DecimalField(max_digits=15, decimal_places=4)
    remaining_quantity = models.DecimalField(max_digits=15, decimal_places=4)

    # Costing
    unit_cost = models.DecimalField(max_digits=15, decimal_places=2, default=0)

    # Location
    warehouse = models.ForeignKey(
        'master.Warehouse',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        db_index=True
    )
    room = models.ForeignKey(
        'master.Room',
        on_delete=models.SET_NULL,
        null=True, blank=True
    )
    zone = models.ForeignKey(
        'master.Zone',
        on_delete=models.SET_NULL,
        null=True, blank=True
    )
    bin = models.ForeignKey(
        'master.Bin',
        on_delete=models.SET_NULL,
        null=True, blank=True
    )

    # Status and tracking
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='waiting',
        db_index=True
    )
    expiry_date = models.DateField(null=True, blank=True)
    manufacture_date = models.DateField(null=True, blank=True)
    supplier_batch_number = models.CharField(max_length=100, blank=True)

    # GRN reference
    grn_number = models.CharField(max_length=50, blank=True, db_index=True)

    # Dates
    received_at = models.DateTimeField(default=timezone.now, db_index=True)
    released_at = models.DateTimeField(null=True, blank=True)

    # Audit
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True
    )

    class Meta:
        ordering = ['received_at']
        indexes = [
            models.Index(
                fields=['product', 'status'],
                name='idx_batch_product_status'
            ),
            models.Index(
                fields=['status', 'received_at'],
                name='idx_batch_status_date'
            ),
        ]

    def __str__(self):
        return f"{self.batch_number} — {self.product.sku}"

    def save(self, *args, **kwargs):
        if not self.batch_number:
            today = timezone.now().strftime('%Y%m%d')
            count = StockBatch.objects.filter(
                batch_number__startswith=f'BATCH-{today}'
            ).count() + 1
            self.batch_number = f"BATCH-{today}-{str(count).zfill(4)}"
        super().save(*args, **kwargs)

    @property
    def total_value(self):
        return float(self.remaining_quantity) * float(self.unit_cost)

    @property
    def location_display(self):
        parts = []
        if self.warehouse:
            parts.append(self.warehouse.code)
        if self.room:
            parts.append(self.room.code)
        if self.zone:
            parts.append(self.zone.code)
        if self.bin:
            parts.append(self.bin.code)
        return ' / '.join(parts) if parts else 'Not assigned'


def get_current_stock(product, warehouse=None, zone_type=None):
    """
    FIFO engine — get current available stock
    Only counts status='available' batches
    Optionally filter by warehouse or zone type
    """
    qs = StockBatch.objects.filter(
        product=product,
        status='available',
        remaining_quantity__gt=0
    )
    if warehouse:
        qs = qs.filter(warehouse=warehouse)
    if zone_type:
        qs = qs.filter(zone__zone_type=zone_type)
    return qs.aggregate(
        total=Sum('remaining_quantity')
    )['total'] or 0


def consume_stock(product, quantity_needed, user, reference,
                  warehouse=None):
    """
    FIFO deduction engine
    Deducts from oldest batches first
    Returns list of (batch, qty_taken) tuples
    Raises ValueError if insufficient stock
    """
    available = get_current_stock(product, warehouse)
    if float(available) < float(quantity_needed):
        raise ValueError(
            f"Insufficient stock for {product.sku}. "
            f"Need {quantity_needed}, have {available}"
        )

    batches = StockBatch.objects.filter(
        product=product,
        status='available',
        remaining_quantity__gt=0
    ).order_by('received_at')

    if warehouse:
        batches = batches.filter(warehouse=warehouse)

    remaining_to_deduct = float(quantity_needed)
    consumed = []

    for batch in batches:
        if remaining_to_deduct <= 0:
            break
        available_in_batch = float(batch.remaining_quantity)
        take = min(available_in_batch, remaining_to_deduct)
        batch.remaining_quantity = float(
            batch.remaining_quantity
        ) - take
        if batch.remaining_quantity <= 0:
            batch.status = 'depleted'
        batch.save()

        consumed.append((batch, take))
        remaining_to_deduct -= take

        # Record movement
        StockMovement.objects.create(
            product=product,
            batch=batch,
            movement_type='OUT',
            quantity=take,
            reference=reference,
            performed_by=user,
            notes=f'FIFO deduction for {reference}'
        )

    return consumed


class StockMovement(models.Model):
    """
    Complete audit trail of every stock movement
    Created automatically — never manual
    """
    MOVEMENT_TYPE_CHOICES = (
        ('IN',            'Stock In — received'),
        ('OUT',           'Stock Out — issued'),
        ('TRANSFER',      'Transfer — location change'),
        ('ADJUST',        'Adjustment'),
        ('QUARANTINE',    'Moved to Quarantine'),
        ('RELEASE',       'Released from Quarantine'),
        ('SCRAP',         'Scrapped'),
        ('RETURN',        'Returned to Supplier'),
        ('iqc_pass',      'IQC Passed — to Inventory'),
        ('iqc_quarantine','IQC Failed — to Quarantine'),
        ('mrn_issue',     'MRN Issue — to Production'),
        ('adjustment_in', 'Adjustment In'),
        ('adjustment_out','Adjustment Out'),
    )

    product = models.ForeignKey(
        Product,
        on_delete=models.PROTECT,
        related_name='movements',
        db_index=True
    )
    batch = models.ForeignKey(
        StockBatch,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='movements'
    )
    movement_type = models.CharField(
        max_length=20,
        choices=MOVEMENT_TYPE_CHOICES,
        db_index=True
    )
    quantity = models.DecimalField(max_digits=15, decimal_places=4)
    from_location = models.CharField(max_length=200, blank=True)
    to_location = models.CharField(max_length=200, blank=True)
    reference = models.CharField(
        max_length=100, blank=True, db_index=True,
        help_text='GRN number, MRN number, MMN number etc.'
    )
    notes = models.TextField(blank=True)
    performed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True
    )
    performed_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ['-performed_at']
        indexes = [
            models.Index(fields=['product', 'movement_type']),
            models.Index(fields=['reference']),
        ]

    def __str__(self):
        return f"{self.movement_type} — {self.product.sku} × {self.quantity}"


class MaterialMovementNote(models.Model):
    """
    MMN — Material Movement Note
    Generated automatically for every physical movement
    between locations, rooms, departments
    """
    PURPOSE_CHOICES = (
        ('production_issue',  'Production Issuance (MRN)'),
        ('inter_warehouse',   'Inter-Warehouse Transfer'),
        ('iqc_clearance',     'IQC Clearance to Inventory'),
        ('quarantine_in',     'Movement to Quarantine'),
        ('quarantine_out',    'Release from Quarantine'),
        ('sfg_in',            'Movement to SFG'),
        ('sfg_out',           'Movement from SFG'),
        ('receiving',         'Receiving Bay to Waiting Bay'),
        ('waiting_to_iqc',    'Waiting Bay to IQC'),
        ('return_supplier',   'Return to Supplier'),
        ('dispatch',          'Dispatch to Customer'),
        ('other',             'Other'),
    )

    STATUS_CHOICES = (
        ('draft',    'Draft'),
        ('pending',  'Pending Signature'),
        ('complete', 'Complete — Both Signed'),
        ('voided',   'Voided'),
    )

    mmn_number = models.CharField(
        max_length=50, unique=True, db_index=True
    )
    purpose = models.CharField(
        max_length=30,
        choices=PURPOSE_CHOICES,
        default='inter_warehouse'
    )
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='pending'
    )

    # Locations
    from_warehouse = models.ForeignKey(
        'master.Warehouse',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='mmn_from'
    )
    from_room = models.ForeignKey(
        'master.Room',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='mmn_from'
    )
    from_zone = models.ForeignKey(
        'master.Zone',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='mmn_from'
    )
    from_bin = models.ForeignKey(
        'master.Bin',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='mmn_from'
    )
    from_description = models.CharField(
        max_length=200, blank=True,
        help_text='Free text e.g. Assembly Line Station 4'
    )

    to_warehouse = models.ForeignKey(
        'master.Warehouse',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='mmn_to'
    )
    to_room = models.ForeignKey(
        'master.Room',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='mmn_to'
    )
    to_zone = models.ForeignKey(
        'master.Zone',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='mmn_to'
    )
    to_bin = models.ForeignKey(
        'master.Bin',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='mmn_to'
    )
    to_description = models.CharField(
        max_length=200, blank=True,
        help_text='Free text e.g. Aging Room'
    )

    # Reference documents
    reference_type = models.CharField(max_length=20, blank=True)
    reference_number = models.CharField(
        max_length=50, blank=True, db_index=True
    )
    notes = models.TextField(blank=True)

    # Signatures
    issued_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='mmn_issued'
    )
    issued_at = models.DateTimeField(null=True, blank=True)
    received_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='mmn_received'
    )
    received_at = models.DateTimeField(null=True, blank=True)

    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='mmn_created'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Material Movement Note'
        verbose_name_plural = 'Material Movement Notes'

    def __str__(self):
        return f"{self.mmn_number} — {self.get_purpose_display()}"

    def save(self, *args, **kwargs):
        if not self.mmn_number:
            today = timezone.now().strftime('%Y%m%d')
            count = MaterialMovementNote.objects.filter(
                mmn_number__startswith=f'MMN-{today}'
            ).count() + 1
            self.mmn_number = f"MMN-{today}-{str(count).zfill(4)}"
        super().save(*args, **kwargs)

    @property
    def from_display(self):
        parts = []
        if self.from_warehouse:
            parts.append(self.from_warehouse.name)
        if self.from_room:
            parts.append(self.from_room.name)
        if self.from_zone:
            parts.append(self.from_zone.name)
        if self.from_bin:
            parts.append(self.from_bin.code)
        if self.from_description:
            parts.append(self.from_description)
        return ' → '.join(parts) if parts else 'Not specified'

    @property
    def to_display(self):
        parts = []
        if self.to_warehouse:
            parts.append(self.to_warehouse.name)
        if self.to_room:
            parts.append(self.to_room.name)
        if self.to_zone:
            parts.append(self.to_zone.name)
        if self.to_bin:
            parts.append(self.to_bin.code)
        if self.to_description:
            parts.append(self.to_description)
        return ' → '.join(parts) if parts else 'Not specified'


class MMNLine(models.Model):
    """Individual item line on an MMN"""
    mmn = models.ForeignKey(
        MaterialMovementNote,
        on_delete=models.CASCADE,
        related_name='lines'
    )
    product = models.ForeignKey(
        Product,
        on_delete=models.PROTECT
    )
    batch = models.ForeignKey(
        StockBatch,
        on_delete=models.SET_NULL,
        null=True, blank=True
    )
    quantity = models.DecimalField(max_digits=15, decimal_places=4)
    uom = models.CharField(max_length=20, default='EA')
    notes = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return f"{self.product.sku} × {self.quantity}"


class StockAdjustment(models.Model):
    """Manual stock correction — requires reason and FM approval for large amounts"""
    ADJUSTMENT_TYPE = (
        ('increase', 'Increase — found extra stock'),
        ('decrease', 'Decrease — damaged / written off / count short'),
        ('correction', 'Correction — data entry error'),
    )
    STATUS_CHOICES = (
        ('pending', 'Pending FM Approval'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    adjustment_number = models.CharField(max_length=50, unique=True, db_index=True)
    product = models.ForeignKey(Product, on_delete=models.PROTECT, related_name='adjustments')
    adjustment_type = models.CharField(max_length=15, choices=ADJUSTMENT_TYPE)
    quantity = models.DecimalField(max_digits=12, decimal_places=2)
    reason = models.TextField()
    batch = models.ForeignKey(StockBatch, on_delete=models.SET_NULL, null=True, blank=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    requires_approval = models.BooleanField(default=False)
    requested_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
        related_name='adjustments_requested'
    )
    approved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='adjustments_approved'
    )
    approved_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.adjustment_number} — {self.product.name} {self.adjustment_type} {self.quantity}"

    def save(self, *args, **kwargs):
        if not self.adjustment_number:
            from django.utils import timezone
            today = timezone.now().strftime('%Y%m%d')
            count = StockAdjustment.objects.filter(
                adjustment_number__startswith=f'ADJ-{today}'
            ).count() + 1
            self.adjustment_number = f"ADJ-{today}-{str(count).zfill(3)}"
        if float(self.quantity) > 100:
            self.requires_approval = True
        super().save(*args, **kwargs)


class StockTake(models.Model):
    """Physical stock count — Warehouse Controller initiates, generates variance report"""
    STATUS_CHOICES = (
        ('draft', 'Draft — In Progress'),
        ('submitted', 'Submitted — Awaiting FM Approval'),
        ('approved', 'Approved — Adjustments Applied'),
        ('cancelled', 'Cancelled'),
    )
    stocktake_number = models.CharField(max_length=50, unique=True, db_index=True)
    description = models.CharField(max_length=200)
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='draft')
    category_filter = models.CharField(max_length=20, blank=True,
        help_text='Filter by category — blank means all stock')
    initiated_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
        related_name='stocktakes_initiated'
    )
    approved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='stocktakes_approved'
    )
    approved_at = models.DateTimeField(null=True, blank=True)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.stocktake_number} — {self.description}"

    def save(self, *args, **kwargs):
        if not self.stocktake_number:
            from django.utils import timezone
            today = timezone.now().strftime('%Y%m%d')
            count = StockTake.objects.filter(
                stocktake_number__startswith=f'ST-{today}'
            ).count() + 1
            self.stocktake_number = f"ST-{today}-{str(count).zfill(3)}"
        super().save(*args, **kwargs)

    @property
    def total_lines(self):
        return self.lines.count()

    @property
    def variance_lines(self):
        return self.lines.filter(has_variance=True).count()


class StockTakeLine(models.Model):
    """One line per product in a stock take"""
    stocktake = models.ForeignKey(StockTake, on_delete=models.CASCADE, related_name='lines')
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    system_qty = models.DecimalField(max_digits=12, decimal_places=2, help_text='What ELMAS says')
    counted_qty = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True,
        help_text='What was physically counted')
    variance = models.DecimalField(max_digits=12, decimal_places=2, default=0,
        help_text='counted - system')
    has_variance = models.BooleanField(default=False)
    notes = models.CharField(max_length=255, blank=True)
    counted_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True
    )

    class Meta:
        ordering = ['product__name']
        unique_together = ['stocktake', 'product']

    def __str__(self):
        return f"{self.stocktake.stocktake_number} — {self.product.name}"

    def save(self, *args, **kwargs):
        if self.counted_qty is not None:
            self.variance = float(self.counted_qty) - float(self.system_qty)
            self.has_variance = abs(self.variance) > 0.01
        super().save(*args, **kwargs)


class SupplierPerformance(models.Model):
    """Auto-updated each time a GRN is verified for a supplier"""
    supplier = models.OneToOneField(Supplier, on_delete=models.CASCADE, related_name='performance')
    total_deliveries = models.IntegerField(default=0)
    on_time_deliveries = models.IntegerField(default=0)
    short_deliveries = models.IntegerField(default=0)
    rejected_deliveries = models.IntegerField(default=0)
    total_items_received = models.IntegerField(default=0)
    total_items_rejected = models.IntegerField(default=0)
    last_delivery_date = models.DateField(null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Supplier Performance'

    def __str__(self):
        return f"{self.supplier.name} — {self.on_time_pct}% on time"

    @property
    def on_time_pct(self):
        if self.total_deliveries == 0:
            return 0
        return round((self.on_time_deliveries / self.total_deliveries) * 100)

    @property
    def rejection_pct(self):
        if self.total_items_received == 0:
            return 0
        return round((self.total_items_rejected / self.total_items_received) * 100, 1)

    @property
    def rating(self):
        pct = self.on_time_pct
        if pct >= 95:
            return 'Excellent'
        elif pct >= 85:
            return 'Good'
        elif pct >= 70:
            return 'Fair'
        else:
            return 'Poor'


class CostHistory(models.Model):
    """
    Tracks every unit_cost change on a Product.
    Created automatically by signal when Product.unit_cost changes.
    Append-only — no delete, no edit.
    """
    product    = models.ForeignKey(
        Product, on_delete=models.CASCADE, related_name='cost_history'
    )
    old_cost   = models.DecimalField(max_digits=15, decimal_places=4)
    new_cost   = models.DecimalField(max_digits=15, decimal_places=4)
    changed_at = models.DateTimeField(auto_now_add=True)
    changed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='cost_changes'
    )
    notes      = models.TextField(blank=True)

    class Meta:
        ordering = ['-changed_at']

    def __str__(self):
        return f"{self.product.sku}: {self.old_cost} → {self.new_cost} @ {self.changed_at:%Y-%m-%d %H:%M}"
