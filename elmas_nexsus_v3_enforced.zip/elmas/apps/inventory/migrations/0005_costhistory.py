"""
ELMAS-NEXSUS — inventory/0005
Add CostHistory model for tracking unit_cost changes on Product
"""
from django.db import migrations, models
import django.db.models.deletion
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('inventory', '0004_product_aql_level'),
        ('accounts', '0004_user_assigned_line'),
    ]

    operations = [
        migrations.CreateModel(
            name='CostHistory',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True)),
                ('old_cost', models.DecimalField(decimal_places=4, max_digits=15)),
                ('new_cost', models.DecimalField(decimal_places=4, max_digits=15)),
                ('changed_at', models.DateTimeField(auto_now_add=True)),
                ('notes', models.TextField(blank=True)),
                ('product', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='cost_history', to='inventory.product',
                )),
                ('changed_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='cost_changes',
                    to=settings.AUTH_USER_MODEL,
                )),
            ],
            options={'ordering': ['-changed_at']},
        ),
    ]
