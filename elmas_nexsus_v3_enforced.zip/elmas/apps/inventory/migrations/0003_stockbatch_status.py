from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('inventory', '0002_additions'),
    ]

    operations = [
        migrations.AlterField(
            model_name='stockbatch',
            name='status',
            field=models.CharField(
                choices=[
                    ('waiting',    'In Waiting Bay'),
                    ('iqc',        'In IQC'),
                    ('quarantine', 'In Quarantine'),
                    ('available',  'Available — in inventory'),
                    ('depleted',   'Depleted'),
                    ('reserved',   'Reserved for WO'),
                    ('returned',   'Returned to Supplier'),
                    ('scrapped',   'Scrapped — written off'),
                    ('mretn_hold', 'Returned from Production — pending WC'),
                ],
                db_index=True, default='waiting', max_length=15
            ),
        ),
    ]
