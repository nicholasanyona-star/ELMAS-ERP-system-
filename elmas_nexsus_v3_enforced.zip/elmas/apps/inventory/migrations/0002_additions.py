from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone
from django.conf import settings


class Migration(migrations.Migration):
    dependencies = [
        ('inventory', '0001_initial'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]
    operations = [
        # po_reference on StockBatch (expiry_date already in 0001_initial)
        migrations.AddField('StockBatch', 'po_reference',
            models.CharField(blank=True, max_length=50)),
        # StockAdjustment
        migrations.CreateModel('StockAdjustment', fields=[
            ('id', models.BigAutoField(auto_created=True, primary_key=True)),
            ('adjustment_number', models.CharField(db_index=True, max_length=50, unique=True)),
            ('adjustment_type', models.CharField(choices=[
                ('increase','Increase — found extra stock'),
                ('decrease','Decrease — damaged / written off / count short'),
                ('correction','Correction — data entry error'),
            ], max_length=15)),
            ('quantity', models.DecimalField(decimal_places=2, max_digits=12)),
            ('reason', models.TextField()),
            ('status', models.CharField(choices=[
                ('pending','Pending FM Approval'),
                ('approved','Approved'),
                ('rejected','Rejected'),
            ], default='pending', max_length=10)),
            ('requires_approval', models.BooleanField(default=False)),
            ('approved_at', models.DateTimeField(blank=True, null=True)),
            ('created_at', models.DateTimeField(auto_now_add=True)),
            ('approved_by', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='adjustments_approved', to=settings.AUTH_USER_MODEL)),
            ('batch', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to='inventory.stockbatch')),
            ('product', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='adjustments', to='inventory.product')),
            ('requested_by', models.ForeignKey(null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='adjustments_requested', to=settings.AUTH_USER_MODEL)),
        ], options={'ordering': ['-created_at']}),
        # StockTake
        migrations.CreateModel('StockTake', fields=[
            ('id', models.BigAutoField(auto_created=True, primary_key=True)),
            ('stocktake_number', models.CharField(db_index=True, max_length=50, unique=True)),
            ('description', models.CharField(max_length=200)),
            ('status', models.CharField(choices=[
                ('draft','Draft — In Progress'),
                ('submitted','Submitted — Awaiting FM Approval'),
                ('approved','Approved — Adjustments Applied'),
                ('cancelled','Cancelled'),
            ], default='draft', max_length=15)),
            ('category_filter', models.CharField(blank=True, max_length=20)),
            ('notes', models.TextField(blank=True)),
            ('approved_at', models.DateTimeField(blank=True, null=True)),
            ('created_at', models.DateTimeField(auto_now_add=True)),
            ('approved_by', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='stocktakes_approved', to=settings.AUTH_USER_MODEL)),
            ('initiated_by', models.ForeignKey(null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='stocktakes_initiated', to=settings.AUTH_USER_MODEL)),
        ], options={'ordering': ['-created_at']}),
        # StockTakeLine
        migrations.CreateModel('StockTakeLine', fields=[
            ('id', models.BigAutoField(auto_created=True, primary_key=True)),
            ('system_qty', models.DecimalField(decimal_places=2, max_digits=12)),
            ('counted_qty', models.DecimalField(blank=True, decimal_places=2, max_digits=12, null=True)),
            ('variance', models.DecimalField(decimal_places=2, default=0, max_digits=12)),
            ('has_variance', models.BooleanField(default=False)),
            ('notes', models.CharField(blank=True, max_length=255)),
            ('counted_by', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to=settings.AUTH_USER_MODEL)),
            ('product', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, to='inventory.product')),
            ('stocktake', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='lines', to='inventory.stocktake')),
        ], options={'ordering': ['product__name'], 'unique_together': {('stocktake', 'product')}}),
        # SupplierPerformance
        migrations.CreateModel('SupplierPerformance', fields=[
            ('id', models.BigAutoField(auto_created=True, primary_key=True)),
            ('total_deliveries', models.IntegerField(default=0)),
            ('on_time_deliveries', models.IntegerField(default=0)),
            ('short_deliveries', models.IntegerField(default=0)),
            ('rejected_deliveries', models.IntegerField(default=0)),
            ('total_items_received', models.IntegerField(default=0)),
            ('total_items_rejected', models.IntegerField(default=0)),
            ('last_delivery_date', models.DateField(blank=True, null=True)),
            ('updated_at', models.DateTimeField(auto_now=True)),
            ('supplier', models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, related_name='performance', to='inventory.supplier')),
        ], options={'verbose_name': 'Supplier Performance'}),
    ]
