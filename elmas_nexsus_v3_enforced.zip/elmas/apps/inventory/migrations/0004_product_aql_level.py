"""
ELMAS Inventory Migration 0004
- Add aql_level field to Product model
"""
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('inventory', '0003_stockbatch_status'),
    ]

    operations = [
        migrations.AddField(
            model_name='product',
            name='aql_level',
            field=models.CharField(
                choices=[
                    ('1.0', 'AQL 1.0 — Tight (Battery, PCB, Critical)'),
                    ('1.5', 'AQL 1.5 — Moderate (Display, LCD)'),
                    ('2.5', 'AQL 2.5 — Standard (Raw Materials)'),
                    ('4.0', 'AQL 4.0 — Loose (Packaging, Consumables)'),
                    ('6.5', 'AQL 6.5 — Very Loose (Low risk only)'),
                ],
                default='2.5',
                help_text='AQL inspection level — set per product based on criticality',
                max_length=5,
            ),
        ),
    ]
