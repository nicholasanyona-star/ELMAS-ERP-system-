"""ELMAS Inventory Views"""
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q, Sum
from django.db import transaction
from django.utils import timezone
from apps.accounts.decorators import role_required
from .models import Product, Supplier, StockBatch, StockMovement, MaterialMovementNote, MMNLine
import logging
logger = logging.getLogger('elmas')


@login_required
@role_required('admin', 'warehouse', 'factory_manager', 'procurement', 'pmc')
def stock_list(request):
    category = request.GET.get('category', '')
    filter_battery = request.GET.get('battery', '')
    q = request.GET.get('q', '')
    products = Product.objects.filter(is_active=True).order_by('category', 'name')
    if filter_battery:
        products = products.filter(item_type='battery')
    elif category:
        products = products.filter(category=category)
    if q:
        products = products.filter(Q(name__icontains=q) | Q(sku__icontains=q) | Q(barcode__icontains=q))
    # Annotate with current stock
    product_data = []
    for p in products:
        stock = p.current_stock
        product_data.append({
            'product': p,
            'stock': stock,
            'status': 'out' if stock == 0 else 'low' if stock <= float(p.reorder_point) else 'ok',
        })
    return render(request, 'inventory/stock_list.html', {
        'product_data': product_data,
        'category': category,
        'filter_battery': filter_battery,
        'q': q,
        'categories': Product.CATEGORY_CHOICES,
        'page_title': 'Inventory',
        'total_products': products.count(),
    })


@login_required
@role_required('admin', 'warehouse', 'factory_manager', 'procurement', 'pmc')
def stock_detail(request, pk):
    product = get_object_or_404(Product, pk=pk)
    batches = StockBatch.objects.filter(
        product=product, status='available'
    ).select_related('warehouse', 'bin').order_by('received_at')
    movements = StockMovement.objects.filter(
        product=product
    ).order_by('-created_at')[:20]
    return render(request, 'inventory/stock_detail.html', {
        'product': product,
        'batches': batches,
        'movements': movements,
        'current_stock': product.current_stock,
        'page_title': product.name,
    })


@login_required
@role_required('admin', 'warehouse', 'receiving', 'factory_manager')
def product_edit(request, pk):
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        product.name = request.POST.get('name', product.name).strip()
        product.description = request.POST.get('description', '').strip()
        product.uom = request.POST.get('uom', product.uom).strip()
        product.category = request.POST.get('category', product.category)
        product.item_type = request.POST.get('item_type', product.item_type)
        try: product.reorder_point = float(request.POST.get('reorder_point', 0))
        except: pass
        try: product.minimum_stock = float(request.POST.get('minimum_stock', 0))
        except: pass
        try: product.unit_cost = float(request.POST.get('unit_cost', 0))
        except: pass
        product.save()
        messages.success(request, f'Product {product.name} updated.')
        return redirect('inventory:stock_detail', pk=pk)
    return render(request, 'inventory/product_form.html', {
        'product': product,
        'categories': Product.CATEGORY_CHOICES,
        'item_types': Product.ITEM_TYPE_CHOICES,
        'page_title': f'Edit {product.name}',
    })


@login_required
@role_required('admin', 'warehouse', 'factory_manager')
def movement_list(request):
    from django.core.paginator import Paginator
    movements = StockMovement.objects.select_related(
        'product', 'batch', 'performed_by'
    ).order_by('-created_at')
    # Filter by product search
    q = request.GET.get('q', '').strip()
    if q:
        from django.db.models import Q
        movements = movements.filter(
            Q(product__name__icontains=q) | Q(product__sku__icontains=q) |
            Q(reference__icontains=q)
        )
    type_filter = request.GET.get('type', '')
    if type_filter:
        movements = movements.filter(movement_type=type_filter)
    paginator = Paginator(movements, 50)
    page_obj = paginator.get_page(request.GET.get('page', 1))
    return render(request, 'inventory/movement_list.html', {
        'movements': page_obj, 'page_obj': page_obj,
        'q': q, 'type_filter': type_filter,
        'movement_types': StockMovement.MOVEMENT_TYPE_CHOICES,
        'page_title': 'Stock Movements',
    })


@login_required
@role_required('admin', 'warehouse', 'factory_manager', 'pmc', 'production')
def mmn_create(request):
    """
    Any authorised role raises an MMN for every physical movement of materials,
    devices or anything within the factory. Nobody moves anything without this document.
    """
    from apps.master.models import Warehouse as WH, Room as RM, Zone as ZN, Bin as BN
    warehouses = WH.objects.filter(is_active=True).order_by('name')
    rooms = RM.objects.select_related('warehouse').order_by('warehouse__name', 'name')
    zones = ZN.objects.select_related('room__warehouse').order_by('room__name', 'name')
    bins  = BN.objects.filter(is_active=True).select_related('zone__room__warehouse').order_by('code')

    if request.method == 'POST':
        try:
            with transaction.atomic():
                mmn = MaterialMovementNote.objects.create(
                    purpose=request.POST.get('purpose', 'other'),
                    status='pending',
                    from_warehouse=WH.objects.filter(pk=request.POST.get('from_warehouse')).first(),
                    from_room=RM.objects.filter(pk=request.POST.get('from_room')).first(),
                    from_zone=ZN.objects.filter(pk=request.POST.get('from_zone')).first(),
                    from_bin=BN.objects.filter(pk=request.POST.get('from_bin')).first(),
                    from_description=request.POST.get('from_description', '').strip(),
                    to_warehouse=WH.objects.filter(pk=request.POST.get('to_warehouse')).first(),
                    to_room=RM.objects.filter(pk=request.POST.get('to_room')).first(),
                    to_zone=ZN.objects.filter(pk=request.POST.get('to_zone')).first(),
                    to_bin=BN.objects.filter(pk=request.POST.get('to_bin')).first(),
                    to_description=request.POST.get('to_description', '').strip(),
                    reference_type=request.POST.get('reference_type', '').strip(),
                    reference_number=request.POST.get('reference_number', '').strip(),
                    notes=request.POST.get('notes', '').strip(),
                    initiated_by=request.user,
                    issued_by=request.user,
                    issued_at=timezone.now(),
                    created_by=request.user,
                )
                item_names = request.POST.getlist('item_name')
                item_qtys  = request.POST.getlist('item_qty')
                item_uoms  = request.POST.getlist('item_uom')
                item_notes = request.POST.getlist('item_notes')
                lines_added = 0
                for name, qty, uom, note in zip(item_names, item_qtys, item_uoms, item_notes):
                    name = name.strip()
                    if not name:
                        continue
                    try:
                        qty_val = float(qty or 0)
                        if qty_val <= 0:
                            continue
                    except ValueError:
                        continue
                    product = Product.objects.filter(
                        Q(name__iexact=name) | Q(sku__iexact=name)
                    ).first()
                    if not product:
                        product = Product.objects.create(
                            name=name, category='consumable',
                            uom=uom or 'EA', item_type='general'
                        )
                    MMNLine.objects.create(
                        mmn=mmn,
                        product=product,
                        quantity=qty_val,
                        uom=uom or product.uom,
                        notes=note.strip() if note else ''
                    )
                    lines_added += 1

                if lines_added == 0:
                    messages.error(request, 'Please add at least one item to the MMN.')
                    mmn.delete()
                else:
                    messages.success(request, f'✓ {mmn.mmn_number} created with {lines_added} item(s). Print and accompany the goods to the destination.')
                    return redirect('inventory:mmn_detail', pk=mmn.pk)
        except Exception as e:
            logger.error(f'[mmn_create] {e}')
            messages.error(request, f'Error creating MMN: {e}')

    return render(request, 'inventory/mmn_create.html', {
        'page_title': 'New Material Movement Note',
        'warehouses': warehouses, 'rooms': rooms, 'zones': zones, 'bins': bins,
        'purpose_choices': MaterialMovementNote.PURPOSE_CHOICES,
    })


@login_required
@role_required('admin', 'warehouse', 'factory_manager', 'production', 'pmc')
def mmn_sign(request, pk):
    """Receiver countersigns the MMN — confirms physical receipt of all items."""
    mmn = get_object_or_404(MaterialMovementNote, pk=pk)
    if request.method == 'POST':
        if mmn.initiated_by == request.user:
            messages.error(request, '⚠ The receiver must be a different person from who initiated this MMN.')
            return redirect('inventory:mmn_detail', pk=pk)
        if mmn.status == 'complete':
            messages.info(request, 'This MMN is already fully signed.')
            return redirect('inventory:mmn_detail', pk=pk)
        mmn.received_by = request.user
        mmn.received_at = timezone.now()
        mmn.status = 'complete'
        mmn.save(update_fields=['received_by', 'received_at', 'status'])
        messages.success(request, f'✓ {mmn.mmn_number} countersigned by {request.user.get_full_name()}. Movement complete.')
    return redirect('inventory:mmn_detail', pk=pk)


@login_required
def mmn_list(request):
    from django.core.paginator import Paginator
    mmns = MaterialMovementNote.objects.select_related(
        'initiated_by', 'received_by'
    ).order_by('-created_at')
    status_filter = request.GET.get('status', '')
    purpose_filter = request.GET.get('purpose', '')
    if status_filter:
        mmns = mmns.filter(status=status_filter)
    if purpose_filter:
        mmns = mmns.filter(purpose=purpose_filter)
    paginator = Paginator(mmns, 25)
    page_obj = paginator.get_page(request.GET.get('page', 1))
    return render(request, 'inventory/mmn_list.html', {
        'mmns': page_obj, 'page_obj': page_obj,
        'status_filter': status_filter, 'purpose_filter': purpose_filter,
        'page_title': 'Material Movement Notes',
    })


@login_required
def mmn_detail(request, pk):
    from apps.accounts.models import User
    mmn = get_object_or_404(MaterialMovementNote, pk=pk)
    lines = mmn.lines.select_related('product', 'batch').all()
    all_users = User.objects.filter(is_active=True).order_by('role', 'first_name')
    return render(request, 'inventory/mmn_detail.html', {
        'mmn': mmn, 'lines': lines, 'page_title': mmn.mmn_number,
        'all_users': all_users,
    })


@login_required
def mmn_pdf(request, pk):
    mmn = get_object_or_404(MaterialMovementNote, pk=pk)
    lines = mmn.lines.select_related('product', 'batch').all()
    from apps.master.models import SystemSettings
    return render(request, 'inventory/mmn_pdf.html', {
        'mmn': mmn, 'lines': lines,
        'sys': SystemSettings.get_settings(),
    })


@login_required
@role_required('admin', 'warehouse')
def mmn_send(request, pk):
    mmn = get_object_or_404(MaterialMovementNote, pk=pk)
    if request.method == 'POST':
        from apps.messaging.models import Message, MessageRecipient
        recipient_id = request.POST.get('recipient')
        note = request.POST.get('note', '').strip()
        is_urgent = request.POST.get('is_urgent') == 'on'
        try:
            from apps.accounts.models import User
            recipient = User.objects.get(pk=recipient_id)
            msg = Message.objects.create(
                sender=request.user,
                subject=f'MMN: {mmn.mmn_number}',
                body=note or f'Please review MMN {mmn.mmn_number}',
                is_urgent=is_urgent,
                ref_module='mmn',
                ref_number=mmn.mmn_number,
            )
            MessageRecipient.objects.create(message=msg, recipient=recipient)
            messages.success(request, f'MMN sent to {recipient.get_full_name()}.')
        except Exception as e:
            messages.error(request, f'Error sending: {e}')
    return redirect('inventory:mmn_detail', pk=pk)


@login_required
@role_required('admin', 'warehouse', 'procurement', 'factory_manager')
def supplier_list(request):
    suppliers = Supplier.objects.filter(is_active=True).order_by('name')
    return render(request, 'inventory/supplier_list.html', {
        'suppliers': suppliers, 'page_title': 'Suppliers',
    })


@login_required
@role_required('admin', 'warehouse', 'procurement')
def supplier_create(request):
    if request.method == 'POST':
        name = request.POST.get('name', '').strip()
        if not name:
            messages.error(request, 'Supplier name is required.')
        else:
            s = Supplier.objects.create(
                name=name,
                contact_name=request.POST.get('contact_name', '').strip(),
                phone=request.POST.get('phone', '').strip(),
                email=request.POST.get('email', '').strip(),
                address=request.POST.get('address', '').strip(),
                kra_pin=request.POST.get('kra_pin', '').strip(),
                payment_terms=request.POST.get('payment_terms', '').strip(),
                notes=request.POST.get('notes', '').strip(),
            )
            messages.success(request, f'Supplier {s.name} created.')
            return redirect('inventory:supplier_list')
    return render(request, 'inventory/supplier_form.html', {
        'page_title': 'Add Supplier', 'action': 'Create',
    })


@login_required
@role_required('admin', 'warehouse', 'procurement')
def supplier_edit(request, pk):
    supplier = get_object_or_404(Supplier, pk=pk)
    if request.method == 'POST':
        supplier.name = request.POST.get('name', supplier.name).strip()
        supplier.contact_name = request.POST.get('contact_name', '').strip()
        supplier.phone = request.POST.get('phone', '').strip()
        supplier.email = request.POST.get('email', '').strip()
        supplier.address = request.POST.get('address', '').strip()
        supplier.kra_pin = request.POST.get('kra_pin', '').strip()
        supplier.payment_terms = request.POST.get('payment_terms', '').strip()
        supplier.notes = request.POST.get('notes', '').strip()
        supplier.is_active = request.POST.get('is_active') == 'on'
        supplier.save()
        messages.success(request, f'Supplier {supplier.name} updated.')
        return redirect('inventory:supplier_list')
    return render(request, 'inventory/supplier_form.html', {
        'supplier': supplier, 'page_title': f'Edit {supplier.name}', 'action': 'Save Changes',
    })


@login_required
@role_required('admin', 'warehouse', 'receiving')
def label_print(request):
    """Print labels for bin locations, stock items, or FG devices"""
    from apps.master.models import Bin, Warehouse
    from apps.master.models import SystemSettings
    label_type = request.GET.get('type', 'bin')
    pk = request.GET.get('pk')
    sys = SystemSettings.get_settings()
    if label_type == 'bin' and pk:
        items = [Bin.objects.get(pk=pk)]
    elif label_type == 'product' and pk:
        items = [Product.objects.get(pk=pk)]
    elif label_type == 'product':
        items = Product.objects.filter(is_active=True).order_by('name')[:50]
    else:
        # Default: bin labels
        items = Bin.objects.filter(is_active=True).select_related(
            'zone__room__warehouse'
        ).order_by('zone__room__warehouse__code', 'zone__code', 'code')[:50]
    return render(request, 'inventory/label_print.html', {
        'items': items,
        'label_type': label_type,
        'sys': sys,
        'page_title': 'Print Labels',
    })


@login_required
@role_required('admin', 'warehouse', 'factory_manager')
def adjustment_list(request):
    from apps.inventory.models import StockAdjustment
    adjustments = StockAdjustment.objects.select_related(
        'product', 'requested_by', 'approved_by'
    ).order_by('-created_at')
    return render(request, 'inventory/adjustment_list.html', {
        'adjustments': adjustments, 'page_title': 'Stock Adjustments',
    })


@login_required
@role_required('admin', 'warehouse')
def adjustment_create(request):
    from apps.inventory.models import StockAdjustment
    products = Product.objects.filter(is_active=True).order_by('name')
    if request.method == 'POST':
        try:
            product = Product.objects.get(pk=request.POST['product'])
            qty = float(request.POST['quantity'])
            adj_type = request.POST['adjustment_type']
            reason = request.POST.get('reason', '').strip()
            if not reason:
                messages.error(request, 'Reason is mandatory for stock adjustments.')
                return render(request, 'inventory/adjustment_form.html', {'products': products, 'page_title': 'Stock Adjustment'})
            # Adjustments over 100 units require FM approval
            requires_approval = qty > 100
            adj = StockAdjustment.objects.create(
                product=product,
                adjustment_type=adj_type,
                quantity=qty,
                reason=reason,
                requires_approval=requires_approval,
                status='pending' if requires_approval else 'approved',
                requested_by=request.user,
            )
            if not requires_approval:
                # Apply immediately
                _apply_adjustment(adj, request.user)
                messages.success(request, f'✓ Adjustment {adj.adjustment_number} applied immediately.')
            else:
                messages.warning(request, f'✓ Adjustment {adj.adjustment_number} created. Requires Factory Manager approval (qty > 100).')
            return redirect('inventory:adjustment_list')
        except Exception as e:
            messages.error(request, f'Error: {e}')
    return render(request, 'inventory/adjustment_form.html', {
        'products': products, 'page_title': 'New Stock Adjustment',
    })


def _apply_adjustment(adj, user):
    """Apply a stock adjustment to inventory"""
    from django.utils import timezone
    from apps.inventory.models import StockBatch, StockMovement, StockAdjustment
    if adj.adjustment_type == 'increase':
        StockBatch.objects.create(
            product=adj.product,
            quantity=adj.quantity,
            remaining_quantity=adj.quantity,
            status='available',
            grn_reference=adj.adjustment_number,
            unit_cost=adj.product.unit_cost,
        )
        StockMovement.objects.create(
            product=adj.product,
            movement_type='adjustment_in',
            quantity=adj.quantity,
            from_location='Manual Adjustment',
            to_location='Stock',
            performed_by=user,
            reference=adj.adjustment_number,
        )
    else:
        # Decrease — deduct from oldest batches (FIFO)
        remaining = float(adj.quantity)
        batches = StockBatch.objects.filter(
            product=adj.product, status='available'
        ).order_by('received_at')
        for batch in batches:
            if remaining <= 0:
                break
            take = min(float(batch.remaining_quantity), remaining)
            batch.remaining_quantity -= take
            if batch.remaining_quantity <= 0:
                batch.status = 'consumed'
            batch.save(update_fields=['remaining_quantity', 'status'])
            StockMovement.objects.create(
                product=adj.product,
                batch=batch,
                movement_type='adjustment_out',
                quantity=take,
                from_location='Stock',
                to_location=f'Adjustment — {adj.get_adjustment_type_display()}',
                performed_by=user,
                reference=adj.adjustment_number,
            )
            remaining -= take


@login_required
@role_required('admin', 'factory_manager')
def adjustment_approve(request, pk):
    from apps.inventory.models import StockAdjustment
    adj = get_object_or_404(StockAdjustment, pk=pk)
    if request.method == 'POST':
        action = request.POST.get('action')
        from django.utils import timezone
        if action == 'approve':
            adj.status = 'approved'
            adj.approved_by = request.user
            adj.approved_at = timezone.now()
            adj.save(update_fields=['status', 'approved_by', 'approved_at'])
            _apply_adjustment(adj, request.user)
            messages.success(request, f'✓ Adjustment {adj.adjustment_number} approved and applied.')
        else:
            adj.status = 'rejected'
            adj.approved_by = request.user
            adj.approved_at = timezone.now()
            adj.save(update_fields=['status', 'approved_by', 'approved_at'])
            messages.warning(request, f'Adjustment {adj.adjustment_number} rejected.')
    return redirect('inventory:adjustment_list')


@login_required
@role_required('admin', 'warehouse', 'factory_manager')
def stocktake_list(request):
    from apps.inventory.models import StockTake
    takes = StockTake.objects.select_related('initiated_by', 'approved_by').order_by('-created_at')
    return render(request, 'inventory/stocktake_list.html', {
        'takes': takes, 'page_title': 'Stock Takes',
    })


@login_required
@role_required('admin', 'warehouse')
def stocktake_create(request):
    from apps.inventory.models import StockTake, StockTakeLine
    if request.method == 'POST':
        try:
            category = request.POST.get('category_filter', '')
            st = StockTake.objects.create(
                description=request.POST['description'].strip(),
                category_filter=category,
                initiated_by=request.user,
            )
            # Auto-populate lines with current system quantities
            products = Product.objects.filter(is_active=True)
            if category:
                products = products.filter(category=category)
            for product in products:
                StockTakeLine.objects.create(
                    stocktake=st,
                    product=product,
                    system_qty=product.current_stock,
                )
            messages.success(request, f'✓ Stock Take {st.stocktake_number} created with {st.lines.count()} lines. Enter counted quantities.')
            return redirect('inventory:stocktake_detail', pk=st.pk)
        except Exception as e:
            messages.error(request, f'Error: {e}')
    categories = [('raw_material','Raw Materials'),('packaging','Packaging'),('consumable','Consumables')]
    return render(request, 'inventory/stocktake_form.html', {
        'categories': categories, 'page_title': 'New Stock Take',
    })


@login_required
@role_required('admin', 'warehouse', 'factory_manager')
def stocktake_detail(request, pk):
    from apps.inventory.models import StockTake, StockTakeLine
    st = get_object_or_404(StockTake, pk=pk)
    lines = st.lines.select_related('product', 'counted_by').all()
    if request.method == 'POST' and st.status == 'draft':
        # Save counted quantities
        for line in lines:
            counted = request.POST.get(f'qty_{line.pk}', '').strip()
            if counted:
                try:
                    line.counted_qty = float(counted)
                    line.counted_by = request.user
                    line.save()
                except Exception:
                    pass
        messages.success(request, '✓ Quantities saved.')
        return redirect('inventory:stocktake_detail', pk=pk)
    variance_count = lines.filter(has_variance=True).count()
    return render(request, 'inventory/stocktake_detail.html', {
        'st': st, 'lines': lines, 'variance_count': variance_count,
        'page_title': st.stocktake_number,
    })


@login_required
@role_required('admin', 'warehouse')
def stocktake_submit(request, pk):
    from apps.inventory.models import StockTake
    st = get_object_or_404(StockTake, pk=pk)
    if request.method == 'POST' and st.status == 'draft':
        st.status = 'submitted'
        st.save(update_fields=['status'])
        messages.success(request, f'✓ Stock Take {st.stocktake_number} submitted for Factory Manager approval.')
    return redirect('inventory:stocktake_detail', pk=pk)


@login_required
@role_required('admin', 'factory_manager')
def stocktake_approve(request, pk):
    from apps.inventory.models import StockTake, StockAdjustment
    from django.utils import timezone
    st = get_object_or_404(StockTake, pk=pk)
    if request.method == 'POST' and st.status == 'submitted':
        action = request.POST.get('action')
        if action == 'approve':
            # Auto-create adjustments for all variances
            for line in st.lines.filter(has_variance=True).select_related('product'):
                adj_type = 'increase' if line.variance > 0 else 'decrease'
                adj = StockAdjustment.objects.create(
                    product=line.product,
                    adjustment_type=adj_type,
                    quantity=abs(float(line.variance)),
                    reason=f'Stock Take {st.stocktake_number} — variance correction',
                    status='approved',
                    requires_approval=False,
                    requested_by=request.user,
                    approved_by=request.user,
                    approved_at=timezone.now(),
                )
                _apply_adjustment(adj, request.user)
            st.status = 'approved'
            st.approved_by = request.user
            st.approved_at = timezone.now()
            st.save(update_fields=['status', 'approved_by', 'approved_at'])
            messages.success(request, f'✓ Stock Take {st.stocktake_number} approved. {st.lines.filter(has_variance=True).count()} variance(s) corrected.')
        else:
            st.status = 'cancelled'
            st.save(update_fields=['status'])
            messages.warning(request, f'Stock Take {st.stocktake_number} cancelled.')
    return redirect('inventory:stocktake_detail', pk=pk)


@login_required
@role_required('admin', 'warehouse', 'factory_manager')
def reorder_settings(request):
    """Set reorder points and minimum stock levels per product"""
    products = Product.objects.filter(is_active=True).order_by('category', 'name')
    if request.method == 'POST':
        updated = 0
        for product in products:
            rp = request.POST.get(f'rp_{product.pk}', '').strip()
            uc = request.POST.get(f'uc_{product.pk}', '').strip()
            changed = False
            try:
                if rp and float(rp) != float(product.reorder_point):
                    product.reorder_point = float(rp)
                    changed = True
                if uc and float(uc) != float(product.unit_cost):
                    product.unit_cost = float(uc)
                    changed = True
                if changed:
                    product.save(update_fields=['reorder_point', 'unit_cost'])
                    updated += 1
            except Exception:
                pass
        messages.success(request, f'✓ {updated} product(s) updated.')
        return redirect('inventory:reorder_settings')
    return render(request, 'inventory/reorder_settings.html', {
        'products': products, 'page_title': 'Reorder Points & Costs',
    })
