from django.contrib import admin
from .models import (
    Product, Supplier, StockBatch, StockMovement,
    MaterialMovementNote, MMNLine, StockAdjustment,
    StockTake, StockTakeLine, SupplierPerformance
)


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('sku', 'name', 'category', 'item_type', 'uom', 'reorder_point', 'is_active')
    list_filter = ('category', 'item_type', 'is_active')
    search_fields = ('sku', 'name', 'barcode')
    ordering = ('category', 'name')


@admin.register(Supplier)
class SupplierAdmin(admin.ModelAdmin):
    list_display = ('code', 'name', 'contact_person', 'phone', 'email', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('code', 'name', 'contact_person', 'email')
    ordering = ('name',)


@admin.register(StockBatch)
class StockBatchAdmin(admin.ModelAdmin):
    list_display = ('batch_number', 'product', 'supplier', 'remaining_quantity', 'status', 'received_at')
    list_filter = ('status', 'product__category')
    search_fields = ('batch_number', 'product__name', 'supplier__name')
    ordering = ('-received_at',)


@admin.register(StockMovement)
class StockMovementAdmin(admin.ModelAdmin):
    list_display = ('reference', 'product', 'movement_type', 'quantity', 'performed_by', 'performed_at')
    list_filter = ('movement_type',)
    search_fields = ('reference', 'product__name')
    ordering = ('-performed_at',)


@admin.register(MaterialMovementNote)
class MMNAdmin(admin.ModelAdmin):
    list_display = ('mmn_number', 'purpose', 'status', 'created_by', 'created_at')
    list_filter = ('status',)
    search_fields = ('mmn_number',)
    ordering = ('-created_at',)


@admin.register(StockAdjustment)
class StockAdjustmentAdmin(admin.ModelAdmin):
    list_display = ('adjustment_number', 'product', 'adjustment_type', 'quantity', 'status', 'requested_by', 'created_at')
    list_filter = ('adjustment_type', 'status')
    search_fields = ('adjustment_number', 'product__name')
    ordering = ('-created_at',)


@admin.register(StockTake)
class StockTakeAdmin(admin.ModelAdmin):
    list_display = ('stocktake_number', 'description', 'status', 'initiated_by', 'created_at')
    list_filter = ('status',)
    search_fields = ('stocktake_number', 'description')
    ordering = ('-created_at',)


@admin.register(SupplierPerformance)
class SupplierPerformanceAdmin(admin.ModelAdmin):
    list_display = ('supplier', 'total_deliveries', 'on_time_deliveries', 'rejected_deliveries', 'updated_at')
    search_fields = ('supplier__name',)
