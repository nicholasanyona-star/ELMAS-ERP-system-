from django.urls import path
from . import views
app_name = 'inventory'
urlpatterns = [
    path('', views.stock_list, name='stock_list'),
    path('product/<int:pk>/', views.stock_detail, name='stock_detail'),
    path('product/<int:pk>/edit/', views.product_edit, name='product_edit'),
    path('movements/', views.movement_list, name='movement_list'),
    path('mmn/', views.mmn_list, name='mmn_list'),
    path('mmn/create/', views.mmn_create, name='mmn_create'),
    path('mmn/<int:pk>/', views.mmn_detail, name='mmn_detail'),
    path('mmn/<int:pk>/pdf/', views.mmn_pdf, name='mmn_pdf'),
    path('mmn/<int:pk>/send/', views.mmn_send, name='mmn_send'),
    path('mmn/<int:pk>/sign/', views.mmn_sign, name='mmn_sign'),
    path('suppliers/', views.supplier_list, name='supplier_list'),
    path('suppliers/create/', views.supplier_create, name='supplier_create'),
    path('suppliers/<int:pk>/edit/', views.supplier_edit, name='supplier_edit'),
    path('labels/', views.label_print, name='label_print'),
    path('adjustments/', views.adjustment_list, name='adjustment_list'),
    path('adjustments/create/', views.adjustment_create, name='adjustment_create'),
    path('adjustments/<int:pk>/approve/', views.adjustment_approve, name='adjustment_approve'),
    path('stocktake/', views.stocktake_list, name='stocktake_list'),
    path('stocktake/create/', views.stocktake_create, name='stocktake_create'),
    path('stocktake/<int:pk>/', views.stocktake_detail, name='stocktake_detail'),
    path('stocktake/<int:pk>/submit/', views.stocktake_submit, name='stocktake_submit'),
    path('stocktake/<int:pk>/approve/', views.stocktake_approve, name='stocktake_approve'),
    path('reorder/', views.reorder_settings, name='reorder_settings'),
]

