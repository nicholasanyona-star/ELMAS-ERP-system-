"""ELMAS Procurement Models — Purchase Orders, Shortage Alerts"""
from django.db import models
from django.conf import settings
from django.utils import timezone


class PurchaseOrder(models.Model):
    STATUS_CHOICES = (
        ('draft',               'Draft'),
        ('pending_approval',    'Pending FM Approval'),
        ('approved',            'FM Approved'),
        ('sent',                'Sent to Supplier'),
        ('acknowledged',        'Acknowledged by Supplier'),
        ('delivery_confirmed',  'Delivery Date Confirmed'),
        ('partial',             'Partially Received'),
        ('completed',           'Completed'),
        ('overdue',             'Overdue — supplier late'),
        ('cancelled',           'Cancelled'),
    )
    APPROVAL_TIER_CHOICES = (
        ('auto', 'Auto-approved — consumable below threshold'),
        ('fm',   'FM Approval Required'),
    )

    po_number = models.CharField(max_length=50, unique=True, db_index=True)
    supplier = models.ForeignKey(
        'inventory.Supplier', on_delete=models.PROTECT, related_name='purchase_orders'
    )
    material_category = models.CharField(
        max_length=20,
        choices=(
            ('raw_material', 'Raw Materials'),
            ('packaging',    'Packaging'),
            ('consumable',   'Consumables'),
            ('battery',      'Battery'),
            ('mixed',        'Mixed'),
        ),
        default='raw_material'
    )
    status = models.CharField(
        max_length=20, choices=STATUS_CHOICES, default='draft'
    )
    approval_tier = models.CharField(
        max_length=5, choices=APPROVAL_TIER_CHOICES, default='fm'
    )
    order_date = models.DateField(default=timezone.now)
    expected_date = models.DateField(null=True, blank=True)
    supplier_confirmed_date = models.DateField(
        null=True, blank=True,
        help_text='Date supplier confirmed they will deliver'
    )
    is_emergency = models.BooleanField(default=False)
    emergency_reason = models.TextField(blank=True)
    is_new_supplier = models.BooleanField(
        default=False,
        help_text='Auto-set if this is the first PO for this supplier'
    )
    linked_work_order = models.ForeignKey(
        'pmc.WorkOrder', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='purchase_orders'
    )
    battery_controller_notified = models.BooleanField(default=False)
    delivery_overdue_alert_sent = models.BooleanField(default=False)
    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, related_name='pos_created'
    )
    approved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='pos_approved'
    )
    approved_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.po_number} — {self.supplier.name}"

    def clean(self):
        from django.core.exceptions import ValidationError
        if self.expected_date and self.order_date and self.expected_date < self.order_date:
            raise ValidationError({'expected_date': 'Expected delivery date cannot be before order date.'})
        if self.is_emergency and not self.emergency_reason:
            raise ValidationError({'emergency_reason': 'Emergency reason is required for emergency POs.'})

    def save(self, *args, **kwargs):
        if not self.po_number:
            today = timezone.now().strftime('%Y%m%d')
            count = PurchaseOrder.objects.filter(
                po_number__startswith=f'PO-{today}'
            ).count() + 1
            self.po_number = f"PO-{today}-{str(count).zfill(3)}"
        # Auto-set new supplier flag
        if not self.pk:
            existing = PurchaseOrder.objects.filter(
                supplier=self.supplier
            ).exists()
            self.is_new_supplier = not existing
        super().save(*args, **kwargs)

    @property
    def total_value(self):
        return sum(line.line_total for line in self.lines.all())


class POLine(models.Model):
    po = models.ForeignKey(PurchaseOrder, on_delete=models.CASCADE, related_name='lines')
    product = models.ForeignKey('inventory.Product', on_delete=models.PROTECT)
    qty_ordered = models.DecimalField(max_digits=12, decimal_places=2)
    qty_received = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    unit_price = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    uom = models.CharField(max_length=20, default='EA')
    notes = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return f"{self.product.name} × {self.qty_ordered}"

    @property
    def line_total(self):
        return float(self.qty_ordered) * float(self.unit_price)

    @property
    def qty_outstanding(self):
        return self.qty_ordered - self.qty_received


class ShortageAlert(models.Model):
    """Auto-generated when stock falls below reorder point OR proactively from WO"""
    STATUS_CHOICES = (
        ('open',      'Open'),
        ('po_raised', 'PO Raised'),
        ('resolved',  'Resolved'),
        ('dismissed', 'Dismissed'),
    )
    ALERT_TYPE_CHOICES = (
        ('reactive',   'Reactive — stock fell below reorder point'),
        ('proactive',  'Proactive — WO/PP triggered before shortage'),
    )

    product = models.ForeignKey(
        'inventory.Product', on_delete=models.CASCADE, related_name='shortage_alerts'
    )
    alert_type = models.CharField(
        max_length=10, choices=ALERT_TYPE_CHOICES, default='reactive'
    )
    current_stock = models.DecimalField(max_digits=12, decimal_places=2)
    reorder_point = models.DecimalField(max_digits=12, decimal_places=2)
    suggested_order_qty = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='open')
    purchase_order = models.ForeignKey(
        PurchaseOrder, on_delete=models.SET_NULL, null=True, blank=True
    )
    # Proactive fields
    linked_work_order = models.ForeignKey(
        'pmc.WorkOrder', on_delete=models.SET_NULL,
        null=True, blank=True,
        help_text='WO that triggered this proactive alert'
    )
    required_by_date = models.DateField(
        null=True, blank=True,
        help_text='When WO needs the material'
    )
    qty_required_for_wo = models.DecimalField(
        max_digits=12, decimal_places=2, null=True, blank=True
    )
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    resolved_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"SHORTAGE: {self.product.name} — {self.current_stock} remaining"
