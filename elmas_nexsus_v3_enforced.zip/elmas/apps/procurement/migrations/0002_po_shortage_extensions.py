"""
ELMAS Procurement Migration 0002
- Extend PurchaseOrder with status, category, approval_tier, emergency, etc.
- Extend ShortageAlert with alert_type, linked_work_order, required_by_date
"""
from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('procurement', '0001_initial'),
        ('pmc', '0006_siv_battery_fmqueue'),
        ('accounts', '0004_user_assigned_line'),
    ]

    operations = [

        # PurchaseOrder extensions
        migrations.AddField(
            model_name='purchaseorder',
            name='material_category',
            field=models.CharField(
                choices=[
                    ('raw_material', 'Raw Materials'), ('packaging', 'Packaging'),
                    ('consumable', 'Consumables'), ('battery', 'Battery'), ('mixed', 'Mixed'),
                ],
                default='raw_material', max_length=20,
            ),
        ),
        migrations.AlterField(
            model_name='purchaseorder',
            name='status',
            field=models.CharField(
                choices=[
                    ('draft', 'Draft'), ('pending_approval', 'Pending FM Approval'),
                    ('approved', 'FM Approved'), ('sent', 'Sent to Supplier'),
                    ('acknowledged', 'Acknowledged'), ('delivery_confirmed', 'Delivery Confirmed'),
                    ('partial', 'Partially Received'), ('completed', 'Completed'),
                    ('overdue', 'Overdue'), ('cancelled', 'Cancelled'),
                ],
                default='draft', max_length=20,
            ),
        ),
        migrations.AddField(
            model_name='purchaseorder',
            name='approval_tier',
            field=models.CharField(
                choices=[('auto', 'Auto-approved'), ('fm', 'FM Required')],
                default='fm', max_length=5,
            ),
        ),
        migrations.AddField(
            model_name='purchaseorder',
            name='supplier_confirmed_date',
            field=models.DateField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name='purchaseorder',
            name='is_emergency',
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name='purchaseorder',
            name='emergency_reason',
            field=models.TextField(blank=True),
        ),
        migrations.AddField(
            model_name='purchaseorder',
            name='is_new_supplier',
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name='purchaseorder',
            name='battery_controller_notified',
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name='purchaseorder',
            name='delivery_overdue_alert_sent',
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name='purchaseorder',
            name='linked_work_order',
            field=models.ForeignKey(
                blank=True, null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='purchase_orders',
                to='pmc.workorder',
            ),
        ),

        # ShortageAlert extensions
        migrations.AddField(
            model_name='shortagealert',
            name='alert_type',
            field=models.CharField(
                choices=[('reactive', 'Reactive'), ('proactive', 'Proactive')],
                default='reactive', max_length=10,
            ),
        ),
        migrations.AddField(
            model_name='shortagealert',
            name='linked_work_order',
            field=models.ForeignKey(
                blank=True, null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                to='pmc.workorder',
            ),
        ),
        migrations.AddField(
            model_name='shortagealert',
            name='required_by_date',
            field=models.DateField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name='shortagealert',
            name='qty_required_for_wo',
            field=models.DecimalField(blank=True, decimal_places=2, max_digits=12, null=True),
        ),
        migrations.AddField(
            model_name='shortagealert',
            name='notes',
            field=models.TextField(blank=True),
        ),
    ]
