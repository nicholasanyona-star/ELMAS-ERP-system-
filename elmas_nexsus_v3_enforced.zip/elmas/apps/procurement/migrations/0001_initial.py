from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone
from django.conf import settings


class Migration(migrations.Migration):
    initial = True
    dependencies = [
        ('inventory', '0001_initial'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]
    operations = [
        migrations.CreateModel('PurchaseOrder', fields=[
            ('id', models.BigAutoField(auto_created=True, primary_key=True)),
            ('po_number', models.CharField(db_index=True, max_length=50, unique=True)),
            ('status', models.CharField(choices=[('draft','Draft'),('sent','Sent to Supplier'),('acknowledged','Acknowledged'),('partial','Partially Received'),('completed','Completed'),('cancelled','Cancelled')], default='draft', max_length=15)),
            ('order_date', models.DateField(default=django.utils.timezone.now)),
            ('expected_date', models.DateField(blank=True, null=True)),
            ('notes', models.TextField(blank=True)),
            ('approved_at', models.DateTimeField(blank=True, null=True)),
            ('created_at', models.DateTimeField(auto_now_add=True)),
            ('approved_by', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='pos_approved', to=settings.AUTH_USER_MODEL)),
            ('created_by', models.ForeignKey(null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='pos_created', to=settings.AUTH_USER_MODEL)),
            ('supplier', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='purchase_orders', to='inventory.supplier')),
        ], options={'ordering': ['-created_at']}),
        migrations.CreateModel('POLine', fields=[
            ('id', models.BigAutoField(auto_created=True, primary_key=True)),
            ('qty_ordered', models.DecimalField(decimal_places=2, max_digits=12)),
            ('qty_received', models.DecimalField(decimal_places=2, default=0, max_digits=12)),
            ('unit_price', models.DecimalField(decimal_places=2, default=0, max_digits=12)),
            ('uom', models.CharField(default='EA', max_length=20)),
            ('notes', models.CharField(blank=True, max_length=255)),
            ('po', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='lines', to='procurement.purchaseorder')),
            ('product', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, to='inventory.product')),
        ]),
        migrations.CreateModel('ShortageAlert', fields=[
            ('id', models.BigAutoField(auto_created=True, primary_key=True)),
            ('current_stock', models.DecimalField(decimal_places=2, max_digits=12)),
            ('reorder_point', models.DecimalField(decimal_places=2, max_digits=12)),
            ('suggested_order_qty', models.DecimalField(decimal_places=2, default=0, max_digits=12)),
            ('status', models.CharField(choices=[('open','Open'),('po_raised','PO Raised'),('resolved','Resolved'),('dismissed','Dismissed')], default='open', max_length=15)),
            ('notes', models.TextField(blank=True)),
            ('created_at', models.DateTimeField(auto_now_add=True)),
            ('resolved_at', models.DateTimeField(blank=True, null=True)),
            ('product', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='shortage_alerts', to='inventory.product')),
            ('purchase_order', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to='procurement.purchaseorder')),
        ], options={'ordering': ['-created_at']}),
    ]
