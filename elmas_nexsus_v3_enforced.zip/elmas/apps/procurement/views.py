"""ELMAS Procurement Views"""
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from django.db import transaction
from apps.accounts.decorators import role_required
from .models import PurchaseOrder, POLine, ShortageAlert
from apps.inventory.models import Supplier, Product
import logging
logger = logging.getLogger('elmas')


@login_required
@role_required('admin', 'procurement', 'factory_manager', 'warehouse')
def po_list(request):
    pos = PurchaseOrder.objects.select_related('supplier', 'created_by').order_by('-created_at')
    status_filter = request.GET.get('status', '')
    if status_filter:
        pos = pos.filter(status=status_filter)
    return render(request, 'procurement/po_list.html', {
        'pos': pos, 'status_filter': status_filter,
        'status_choices': PurchaseOrder.STATUS_CHOICES,
        'page_title': 'Purchase Orders',
    })


@login_required
@role_required('admin', 'procurement')
def po_create(request):
    suppliers = Supplier.objects.filter(is_active=True).order_by('name')
    if request.method == 'POST':
        try:
            po = PurchaseOrder.objects.create(
                supplier_id=request.POST['supplier'],
                order_date=request.POST.get('order_date') or timezone.now().date(),
                expected_date=request.POST.get('expected_date') or None,
                notes=request.POST.get('notes', '').strip(),
                created_by=request.user,
            )
            messages.success(request, f'✓ Purchase Order {po.po_number} created. Add items below.')
            return redirect('procurement:po_detail', pk=po.pk)
        except Exception as e:
            messages.error(request, f'Error: {e}')
    return render(request, 'procurement/po_form.html', {
        'suppliers': suppliers, 'page_title': 'New Purchase Order',
    })


@login_required
@role_required('admin', 'procurement', 'factory_manager', 'warehouse')
def po_detail(request, pk):
    po = get_object_or_404(PurchaseOrder, pk=pk)
    lines = po.lines.select_related('product').all()
    all_products = Product.objects.filter(is_active=True).order_by('name')
    from apps.receiving.models import GRN
    linked_grns = GRN.objects.filter(purchase_order_ref=po.po_number).select_related('received_by').order_by('-created_at')
    return render(request, 'procurement/po_detail.html', {
        'po': po, 'lines': lines, 'all_products': all_products,
        'linked_grns': linked_grns,
        'page_title': po.po_number,
    })


@login_required
@role_required('admin', 'factory_manager')
def po_approve(request, pk):
    po = get_object_or_404(PurchaseOrder, pk=pk)
    if request.method == 'POST':
        if po.created_by == request.user:
            messages.error(request, '⚠ You cannot approve a PO you created. A different Factory Manager must approve it.')
            return redirect('procurement:po_detail', pk=pk)
        if not po.lines.exists():
            messages.error(request, '⚠ Cannot approve an empty PO. Add at least one item first.')
            return redirect('procurement:po_detail', pk=pk)
        try:
            with transaction.atomic():
                po.status = 'approved'
                po.approved_by = request.user
                po.approved_at = timezone.now()
                # Determine approval tier
                try:
                    from apps.master.models import SystemSettings
                    s = SystemSettings.get_settings()
                    auto_thresh = float(s.po_auto_approve_threshold)
                except Exception:
                    auto_thresh = 5000
                total = float(po.total_value)
                if total < auto_thresh and po.material_category == 'consumable':
                    po.approval_tier = 'auto'
                else:
                    po.approval_tier = 'fm'
                po.save(update_fields=['status', 'approved_by', 'approved_at', 'approval_tier'])
                # Notify procurement + receiving
                try:
                    from apps.messaging.views import send_system_message
                    send_system_message(
                        subject=f'PO Approved: {po.po_number}',
                        body=f'PO {po.po_number} for {po.supplier.name} approved. '
                             f'Items: {po.lines.count()} lines. Expected: {po.expected_date or "TBD"}.',
                        role='procurement', is_urgent=False,
                        ref_type='po', ref_num=po.po_number,
                    )
                    send_system_message(
                        subject=f'Expect Delivery: {po.po_number}',
                        body=f'PO {po.po_number} approved. Expect delivery from {po.supplier.name}. '
                             f'Category: {po.get_material_category_display()}. '
                             f'Expected: {po.expected_date or "TBD"}.',
                        role='receiving', is_urgent=False,
                        ref_type='po', ref_num=po.po_number,
                    )
                    if po.material_category == 'battery':
                        send_system_message(
                            subject=f'Battery PO Approved: {po.po_number}',
                            body=f'Battery delivery expected from {po.supplier.name}. '
                                 f'Expected: {po.expected_date or "TBD"}.',
                            role='battery_controller', is_urgent=False,
                        )
                except Exception:
                    pass
                # Portal — notify supplier
                try:
                    from apps.portal.models import SupplierPortalAccess, PortalNotification
                    sp = SupplierPortalAccess.objects.filter(
                        supplier=po.supplier, status='active'
                    ).first()
                    if sp:
                        PortalNotification.objects.create(
                            recipient_type='supplier',
                            supplier_portal=sp,
                            event='po_sent',
                            subject=f'Purchase Order {po.po_number}',
                            body=f'PO {po.po_number} has been approved. Please confirm delivery date.',
                            document_ref=po.po_number,
                            created_by=request.user,
                        )
                except Exception:
                    pass
                messages.success(request, f'✓ {po.po_number} approved. Receiving, Procurement and Supplier notified.')
        except Exception as e:
            messages.error(request, f'Error: {e}')
    return redirect('procurement:po_detail', pk=pk)


@login_required
@role_required('admin', 'procurement')
def po_add_line(request, pk):
    po = get_object_or_404(PurchaseOrder, pk=pk)
    if request.method == 'POST':
        try:
            product = Product.objects.get(pk=request.POST['product'])
            POLine.objects.create(
                po=po,
                product=product,
                qty_ordered=float(request.POST['qty_ordered']),
                unit_price=float(request.POST.get('unit_price', 0) or 0),
                uom=request.POST.get('uom', product.uom),
                notes=request.POST.get('notes', '').strip(),
            )
            messages.success(request, f'✓ {product.name} added to PO.')
        except Exception as e:
            messages.error(request, f'Error: {e}')
    return redirect('procurement:po_detail', pk=pk)


@login_required
def po_pdf(request, pk):
    from apps.master.models import SystemSettings
    po = get_object_or_404(PurchaseOrder, pk=pk)
    lines = po.lines.select_related('product').all()
    return render(request, 'procurement/po_pdf.html', {
        'po': po, 'lines': lines, 'sys': SystemSettings.get_settings(),
    })


@login_required
@role_required('admin', 'procurement', 'factory_manager', 'warehouse')
def shortage_list(request):
    alerts = ShortageAlert.objects.filter(status='open').select_related('product').order_by('-created_at')
    resolved = ShortageAlert.objects.filter(status__in=['resolved', 'po_raised']).order_by('-created_at')[:10]
    return render(request, 'procurement/shortage_list.html', {
        'alerts': alerts, 'resolved': resolved, 'page_title': 'Shortage Alerts',
    })


@login_required
@role_required('admin', 'procurement', 'factory_manager')
def shortage_resolve(request, pk):
    alert = get_object_or_404(ShortageAlert, pk=pk)
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'raise_po':
            alert.status = 'po_raised'
        else:
            alert.status = 'dismissed'
        alert.resolved_at = timezone.now()
        alert.save(update_fields=['status', 'resolved_at'])
        messages.success(request, f'Shortage alert for {alert.product.name} updated.')
    return redirect('procurement:shortage_list')


@login_required
@role_required('admin', 'procurement', 'warehouse', 'factory_manager')
def po_receiving_status(request, pk):
    """Show which GRNs have been received against this PO"""
    po = get_object_or_404(PurchaseOrder, pk=pk)
    from apps.receiving.models import GRN
    linked_grns = GRN.objects.filter(purchase_order_ref=po.po_number).select_related('received_by')
    return render(request, 'procurement/po_receiving_status.html', {
        'po': po, 'linked_grns': linked_grns,
        'page_title': f'{po.po_number} — Receiving Status',
    })

@login_required
@role_required('admin', 'procurement')
def po_delete_line(request, pk, line_pk):
    po = get_object_or_404(PurchaseOrder, pk=pk)
    if po.status == 'draft' and request.method == 'POST':
        POLine.objects.filter(pk=line_pk, po=po).delete()
        messages.success(request, 'Line removed.')
    return redirect('procurement:po_detail', pk=pk)


@login_required
@role_required('admin', 'procurement', 'factory_manager')
def po_cancel(request, pk):
    po = get_object_or_404(PurchaseOrder, pk=pk)
    if po.status in ('draft', 'sent', 'acknowledged'):
        if request.method == 'POST':
            reason = request.POST.get('reason', '').strip()
            if not reason:
                messages.error(request, 'A reason is required to cancel a PO.')
                return redirect('procurement:po_detail', pk=pk)
            po.status = 'cancelled'
            po.notes = (po.notes + f'\n\nCANCELLED by {request.user.get_full_name()} — {reason}').strip()
            po.save(update_fields=['status', 'notes'])
            messages.success(request, f'PO {po.po_number} cancelled.')
        return redirect('procurement:po_detail', pk=pk)
    else:
        messages.error(request, f'PO cannot be cancelled at status: {po.get_status_display()}.')
        return redirect('procurement:po_detail', pk=pk)


@login_required
@role_required('admin', 'procurement', 'factory_manager', 'warehouse')
def shortage_check(request):
    """Scan all products and generate shortage alerts for any below reorder point"""
    from apps.inventory.models import Product
    new_alerts = 0
    for product in Product.objects.filter(is_active=True, reorder_point__gt=0):
        stock = product.current_stock
        if stock <= float(product.reorder_point):
            # Only create if no open alert already exists
            if not ShortageAlert.objects.filter(product=product, status='open').exists():
                ShortageAlert.objects.create(
                    product=product,
                    current_stock=stock,
                    reorder_point=product.reorder_point,
                    suggested_order_qty=max(
                        float(product.reorder_point) * 2 - float(stock), 0
                    ),
                )
                new_alerts += 1
    if new_alerts:
        messages.warning(request, f'⚠ {new_alerts} new shortage alert(s) generated.')
    else:
        messages.success(request, '✓ Stock check complete. No new shortages.')
    return redirect('procurement:shortage_list')
