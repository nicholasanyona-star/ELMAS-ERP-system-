from django.urls import path
from . import views
app_name = 'procurement'
urlpatterns = [
    path('orders/', views.po_list, name='po_list'),
    path('orders/create/', views.po_create, name='po_create'),
    path('orders/<int:pk>/', views.po_detail, name='po_detail'),
    path('orders/<int:pk>/approve/', views.po_approve, name='po_approve'),
    path('orders/<int:pk>/pdf/', views.po_pdf, name='po_pdf'),
    path('orders/<int:pk>/line/add/', views.po_add_line, name='po_add_line'),
    path('shortages/', views.shortage_list, name='shortage_list'),
    path('shortages/<int:pk>/resolve/', views.shortage_resolve, name='shortage_resolve'),
    path('orders/<int:pk>/receiving/', views.po_receiving_status, name='po_receiving_status'),
    path('orders/<int:pk>/cancel/', views.po_cancel, name='po_cancel'),
    path('orders/<int:pk>/line/<int:line_pk>/delete/', views.po_delete_line, name='po_delete_line'),
    path('shortages/check/', views.shortage_check, name='shortage_check'),
]
