from django.contrib import admin
from .models import PurchaseOrder, POLine, ShortageAlert


class POLineInline(admin.TabularInline):
    model = POLine
    extra = 1


@admin.register(PurchaseOrder)
class PurchaseOrderAdmin(admin.ModelAdmin):
    list_display = ('po_number', 'supplier', 'status', 'order_date', 'expected_date', 'created_by')
    list_filter = ('status',)
    search_fields = ('po_number', 'supplier__name')
    inlines = [POLineInline]
    ordering = ('-order_date',)


@admin.register(ShortageAlert)
class ShortageAlertAdmin(admin.ModelAdmin):
    list_display = ('product', 'current_stock', 'reorder_point', 'status', 'created_at')
    list_filter = ('status',)
    search_fields = ('product__name',)
    ordering = ('-created_at',)
