"""
ELMAS-NEXSUS ERP — General Ledger
Double-entry bookkeeping auto-posted from all transactional events.
Append-only — no edit, no delete after posting.
"""
from django.db import models
from django.conf import settings
from django.utils import timezone
from decimal import Decimal


class Account(models.Model):
    """Chart of Accounts — each account is a GL node"""
    TYPE_CHOICES = (
        ('asset',     'Asset'),
        ('liability', 'Liability'),
        ('equity',    'Equity'),
        ('revenue',   'Revenue'),
        ('expense',   'Expense'),
        ('cogs',      'Cost of Goods Sold'),
    )
    SUBTYPE_CHOICES = (
        # Assets
        ('cash',             'Cash & Bank'),
        ('receivable',       'Accounts Receivable'),
        ('inventory',        'Inventory'),
        ('wip',              'Work In Progress'),
        ('fixed_asset',      'Fixed Asset'),
        ('other_asset',      'Other Asset'),
        # Liabilities
        ('payable',          'Accounts Payable'),
        ('tax_payable',      'Tax Payable'),
        ('other_liability',  'Other Liability'),
        # Equity
        ('retained',         'Retained Earnings'),
        ('capital',          'Share Capital'),
        # Revenue
        ('sales',            'Sales Revenue'),
        ('other_income',     'Other Income'),
        # Expense / COGS
        ('material_cost',    'Direct Material Cost'),
        ('labour_cost',      'Direct Labour Cost'),
        ('overhead',         'Manufacturing Overhead'),
        ('write_off',        'Write-off / Scrap'),
        ('operating',        'Operating Expense'),
    )

    code        = models.CharField(max_length=20, unique=True, db_index=True)
    name        = models.CharField(max_length=200)
    account_type = models.CharField(max_length=15, choices=TYPE_CHOICES, db_index=True)
    subtype     = models.CharField(max_length=20, choices=SUBTYPE_CHOICES)
    parent      = models.ForeignKey(
        'self', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='children'
    )
    is_system   = models.BooleanField(default=False)
    is_active   = models.BooleanField(default=True)
    description = models.TextField(blank=True)
    created_at  = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['code']

    def __str__(self):
        return f"{self.code} — {self.name}"

    @property
    def balance(self):
        """Current balance: sum of all debit lines minus credit lines"""
        from django.db.models import Sum
        lines = self.journal_lines.aggregate(
            total_debit=Sum('debit_amount'),
            total_credit=Sum('credit_amount'),
        )
        debit  = lines['total_debit']  or Decimal('0')
        credit = lines['total_credit'] or Decimal('0')
        # Asset/Expense: debit-normal. Liability/Equity/Revenue: credit-normal
        if self.account_type in ('asset', 'expense', 'cogs'):
            return debit - credit
        return credit - debit


class CostCentre(models.Model):
    """Maps GL costs to production lines, departments, or projects"""
    CENTRE_TYPE_CHOICES = (
        ('production_line', 'Production Line'),
        ('department',      'Department'),
        ('project',         'Project'),
        ('overhead',        'Overhead Pool'),
    )
    code         = models.CharField(max_length=20, unique=True)
    name         = models.CharField(max_length=100)
    centre_type  = models.CharField(max_length=20, choices=CENTRE_TYPE_CHOICES)
    production_line = models.ForeignKey(
        'master.ProductionLine', on_delete=models.SET_NULL,
        null=True, blank=True
    )
    is_active    = models.BooleanField(default=True)

    class Meta:
        ordering = ['code']

    def __str__(self):
        return f"{self.code} — {self.name}"


class JournalEntry(models.Model):
    """
    A balanced journal entry — total debits must equal total credits.
    Append-only: once posted, cannot be edited or deleted.
    Reversal creates a new entry with opposite signs.
    """
    SOURCE_CHOICES = (
        ('manual',          'Manual Journal'),
        ('stock_movement',  'Stock Movement'),
        ('mrn_issue',       'MRN Material Issue'),
        ('brn_acceptance',  'BRN Battery Issue'),
        ('bcr_writeoff',    'BCR Write-off'),
        ('dn_dispatch',     'Delivery Note Dispatch'),
        ('po_receipt',      'PO Goods Receipt'),
        ('iqc_pass',        'IQC Pass — Stock to Inventory'),
        ('labour_posting',  'Labour Cost Posting'),
        ('payroll_run',     'Payroll Run'),
        ('adjustment',      'Stock Adjustment'),
        ('reversal',        'Reversal Entry'),
    )

    entry_number = models.CharField(max_length=50, unique=True, db_index=True)
    entry_date   = models.DateField(default=timezone.now)
    source       = models.CharField(max_length=20, choices=SOURCE_CHOICES, db_index=True)
    description  = models.TextField()
    reference    = models.CharField(max_length=100, blank=True, db_index=True)
    # Link back to originating document
    source_app   = models.CharField(max_length=30, blank=True)
    source_model = models.CharField(max_length=50, blank=True)
    source_id    = models.IntegerField(null=True, blank=True)
    # Status
    is_posted    = models.BooleanField(default=True)
    is_reversed  = models.BooleanField(default=False)
    reversal_of  = models.ForeignKey(
        'self', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='reversed_by'
    )
    cost_centre  = models.ForeignKey(
        CostCentre, on_delete=models.SET_NULL,
        null=True, blank=True
    )
    posted_by    = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='journal_entries'
    )
    created_at   = models.DateTimeField(auto_now_add=True)
    notes        = models.TextField(blank=True)

    class Meta:
        ordering = ['-entry_date', '-created_at']
        verbose_name = 'Journal Entry'
        verbose_name_plural = 'Journal Entries'

    def __str__(self):
        return f"{self.entry_number} — {self.description[:50]}"

    def save(self, *args, **kwargs):
        if not self.entry_number:
            today = timezone.now().strftime('%Y%m%d')
            count = JournalEntry.objects.filter(
                entry_number__startswith=f'JE-{today}'
            ).count() + 1
            self.entry_number = f"JE-{today}-{str(count).zfill(4)}"
        super().save(*args, **kwargs)

    @property
    def total_debit(self):
        from django.db.models import Sum
        return self.lines.aggregate(t=Sum('debit_amount'))['t'] or Decimal('0')

    @property
    def total_credit(self):
        from django.db.models import Sum
        return self.lines.aggregate(t=Sum('credit_amount'))['t'] or Decimal('0')

    @property
    def is_balanced(self):
        return self.total_debit == self.total_credit


class JournalLine(models.Model):
    """Each line in a journal entry — debit XOR credit, never both"""
    journal_entry = models.ForeignKey(
        JournalEntry, on_delete=models.CASCADE, related_name='lines'
    )
    account       = models.ForeignKey(
        Account, on_delete=models.PROTECT, related_name='journal_lines'
    )
    description   = models.CharField(max_length=200, blank=True)
    debit_amount  = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    credit_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    cost_centre   = models.ForeignKey(
        CostCentre, on_delete=models.SET_NULL, null=True, blank=True
    )

    class Meta:
        ordering = ['id']

    def __str__(self):
        if self.debit_amount:
            return f"DR {self.account.code} {self.debit_amount}"
        return f"CR {self.account.code} {self.credit_amount}"


# ── AUTO-POSTING HELPERS ──────────────────────────────────────────────────────

def get_system_account(subtype):
    """Fetch the system GL account for a given subtype. Returns None if not found."""
    return Account.objects.filter(subtype=subtype, is_active=True).first()


def post_journal(description, source, lines, reference='', source_app='',
                 source_model='', source_id=None, cost_centre=None, posted_by=None):
    """
    Create a balanced journal entry.
    lines: list of (account, debit, credit, description)
    Raises ValueError if not balanced.
    """
    from django.db import transaction as db_transaction
    total_debit  = sum(Decimal(str(l[1])) for l in lines)
    total_credit = sum(Decimal(str(l[2])) for l in lines)
    if total_debit != total_credit:
        raise ValueError(
            f"Journal not balanced: DR {total_debit} ≠ CR {total_credit}"
        )
    with db_transaction.atomic():
        je = JournalEntry.objects.create(
            description=description,
            source=source,
            reference=reference,
            source_app=source_app,
            source_model=source_model,
            source_id=source_id,
            cost_centre=cost_centre,
            posted_by=posted_by,
        )
        for account, debit, credit, line_desc in lines:
            JournalLine.objects.create(
                journal_entry=je,
                account=account,
                debit_amount=Decimal(str(debit)),
                credit_amount=Decimal(str(credit)),
                description=line_desc,
                cost_centre=cost_centre,
            )
    return je


def post_stock_receipt(product, qty, unit_cost, grn_number, user=None):
    """
    GRN receipt: DR Inventory / CR Accounts Payable
    Called after IQC pass when stock enters inventory.
    """
    try:
        value = Decimal(str(qty)) * Decimal(str(unit_cost))
        if value <= 0:
            return
        inv_account = get_system_account('inventory')
        pay_account = get_system_account('payable')
        if not inv_account or not pay_account:
            return
        post_journal(
            description=f'Stock receipt: {product.name} × {qty} units',
            source='iqc_pass',
            reference=grn_number,
            source_app='receiving',
            source_model='GRN',
            posted_by=user,
            lines=[
                (inv_account, value, 0, f'{product.name} — {qty} {product.uom}'),
                (pay_account, 0, value, f'Payable: {grn_number}'),
            ]
        )
    except Exception as e:
        import logging
        logging.getLogger('elmas').error(f'[GL] post_stock_receipt: {e}')


def post_material_issue(product, qty, unit_cost, wo_number, mrn_number, user=None):
    """
    MRN issue: DR WIP / CR Inventory
    Called when WH Controller issues SIV.
    """
    try:
        value = Decimal(str(qty)) * Decimal(str(unit_cost))
        if value <= 0:
            return
        wip_account = get_system_account('wip')
        inv_account = get_system_account('inventory')
        if not wip_account or not inv_account:
            return
        post_journal(
            description=f'Material issue: {product.name} × {qty} for {wo_number}',
            source='mrn_issue',
            reference=mrn_number,
            source_app='pmc',
            source_model='MRN',
            posted_by=user,
            lines=[
                (wip_account, value, 0, f'WIP: {wo_number} — {product.name}'),
                (inv_account, 0, value, f'Issued: {mrn_number}'),
            ]
        )
    except Exception as e:
        import logging
        logging.getLogger('elmas').error(f'[GL] post_material_issue: {e}')


def post_bcr_writeoff(product, qty, unit_cost, bcr_number, user=None):
    """
    BCR write-off: DR Write-off Expense / CR Inventory
    Called when BCR physical removal confirmed.
    """
    try:
        value = Decimal(str(qty)) * Decimal(str(unit_cost))
        if value <= 0:
            return
        writeoff_account = get_system_account('write_off')
        inv_account = get_system_account('inventory')
        if not writeoff_account or not inv_account:
            return
        post_journal(
            description=f'BCR write-off: {product.name} × {qty} units ({bcr_number})',
            source='bcr_writeoff',
            reference=bcr_number,
            source_app='bettery',
            source_model='BatteryConditionReport',
            posted_by=user,
            lines=[
                (writeoff_account, value, 0, f'Write-off: {bcr_number}'),
                (inv_account, 0, value, f'Inventory reduction: {product.name}'),
            ]
        )
    except Exception as e:
        import logging
        logging.getLogger('elmas').error(f'[GL] post_bcr_writeoff: {e}')


def post_dispatch(sales_order_number, dn_number, total_value, cogs_value, user=None):
    """
    DN dispatch: DR COGS / CR WIP, DR Receivable / CR Revenue
    Called when DN status → dispatched.
    """
    try:
        if total_value <= 0:
            return
        cogs_account = get_system_account('cogs') or get_system_account('material_cost')
        wip_account  = get_system_account('wip')
        recv_account = get_system_account('receivable')
        rev_account  = get_system_account('sales')
        if not all([cogs_account, wip_account, recv_account, rev_account]):
            return
        tv = Decimal(str(total_value))
        cv = Decimal(str(cogs_value))
        post_journal(
            description=f'Dispatch: {dn_number} — {sales_order_number}',
            source='dn_dispatch',
            reference=dn_number,
            source_app='dispatch',
            source_model='DeliveryNote',
            posted_by=user,
            lines=[
                (cogs_account, cv, 0,  f'COGS: {dn_number}'),
                (wip_account,  0,  cv, f'WIP clearance: {dn_number}'),
                (recv_account, tv, 0,  f'Receivable: {sales_order_number}'),
                (rev_account,  0,  tv, f'Revenue: {dn_number}'),
            ]
        )
    except Exception as e:
        import logging
        logging.getLogger('elmas').error(f'[GL] post_dispatch: {e}')


def post_labour_cost(wo_number, employee_name, hours, rate, cost_centre=None, user=None):
    """
    Labour posting: DR WIP Labour / CR Labour Payable
    Called from HR shift completion.
    """
    try:
        value = Decimal(str(hours)) * Decimal(str(rate))
        if value <= 0:
            return
        labour_account = get_system_account('labour_cost')
        payable_account = get_system_account('payable')
        if not labour_account or not payable_account:
            return
        post_journal(
            description=f'Labour: {employee_name} — {hours}hrs @ {rate}/hr for {wo_number}',
            source='labour_posting',
            reference=wo_number,
            source_app='hr',
            source_model='ShiftRecord',
            cost_centre=cost_centre,
            posted_by=user,
            lines=[
                (labour_account,  value, 0,     f'Labour: {employee_name} {hours}hrs'),
                (payable_account, 0,     value,  f'Payable: {employee_name}'),
            ]
        )
    except Exception as e:
        import logging
        logging.getLogger('elmas').error(f'[GL] post_labour_cost: {e}')
