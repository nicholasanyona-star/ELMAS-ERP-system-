from django.contrib import admin
from .models import Account, CostCentre, JournalEntry, JournalLine


class JournalLineInline(admin.TabularInline):
    model = JournalLine
    extra = 0
    readonly_fields = ('debit_amount', 'credit_amount', 'account', 'description')
    can_delete = False


@admin.register(Account)
class AccountAdmin(admin.ModelAdmin):
    list_display = ('code', 'name', 'account_type', 'subtype', 'is_active')
    list_filter = ('account_type', 'subtype', 'is_active')
    search_fields = ('code', 'name')
    ordering = ('code',)


@admin.register(CostCentre)
class CostCentreAdmin(admin.ModelAdmin):
    list_display = ('code', 'name', 'centre_type', 'is_active')
    list_filter = ('centre_type', 'is_active')


@admin.register(JournalEntry)
class JournalEntryAdmin(admin.ModelAdmin):
    list_display = ('entry_number', 'entry_date', 'source', 'description', 'reference', 'is_posted')
    list_filter = ('source', 'is_posted', 'is_reversed')
    search_fields = ('entry_number', 'reference', 'description')
    readonly_fields = ('entry_number', 'created_at', 'total_debit', 'total_credit', 'is_balanced')
    inlines = [JournalLineInline]

    def has_delete_permission(self, request, obj=None):
        return False  # Journal entries are append-only

    def has_change_permission(self, request, obj=None):
        return False  # Journal entries are immutable
