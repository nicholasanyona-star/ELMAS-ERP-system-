"""ELMAS-NEXSUS ERP — GL Views (FM and Admin only)"""
from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.db.models import Sum
from apps.accounts.decorators import role_required
from .models import Account, JournalEntry, CostCentre
from decimal import Decimal


@login_required
@role_required('admin', 'factory_manager')
def gl_dashboard(request):
    """GL summary dashboard — FM sees P&L summary, cash position, cost centres"""
    # Account balances by type
    accounts = Account.objects.filter(is_active=True).prefetch_related('journal_lines')
    summary = {
        'total_assets':      Decimal('0'),
        'total_liabilities': Decimal('0'),
        'total_revenue':     Decimal('0'),
        'total_cogs':        Decimal('0'),
        'total_expenses':    Decimal('0'),
    }
    for acc in accounts:
        b = acc.balance
        if acc.account_type == 'asset':
            summary['total_assets'] += b
        elif acc.account_type == 'liability':
            summary['total_liabilities'] += b
        elif acc.account_type == 'revenue':
            summary['total_revenue'] += b
        elif acc.account_type == 'cogs':
            summary['total_cogs'] += b
        elif acc.account_type == 'expense':
            summary['total_expenses'] += b

    summary['gross_profit'] = summary['total_revenue'] - summary['total_cogs']
    summary['net_profit']   = summary['gross_profit'] - summary['total_expenses']

    # Recent journal entries
    recent = JournalEntry.objects.order_by('-created_at')[:15]

    return render(request, 'gl/dashboard.html', {
        'summary': summary,
        'recent_entries': recent,
        'page_title': 'General Ledger',
    })


@login_required
@role_required('admin', 'factory_manager')
def account_list(request):
    accounts = Account.objects.filter(is_active=True).order_by('code')
    return render(request, 'gl/account_list.html', {
        'accounts': accounts,
        'page_title': 'Chart of Accounts',
    })


@login_required
@role_required('admin', 'factory_manager')
def journal_list(request):
    entries = JournalEntry.objects.order_by('-entry_date', '-created_at')
    source_filter = request.GET.get('source', '')
    if source_filter:
        entries = entries.filter(source=source_filter)
    return render(request, 'gl/journal_list.html', {
        'entries': entries[:100],
        'source_filter': source_filter,
        'source_choices': JournalEntry.SOURCE_CHOICES,
        'page_title': 'Journal Entries',
    })


@login_required
@role_required('admin', 'factory_manager')
def journal_detail(request, pk):
    entry = get_object_or_404(JournalEntry, pk=pk)
    lines = entry.lines.select_related('account', 'cost_centre').all()
    return render(request, 'gl/journal_detail.html', {
        'entry': entry, 'lines': lines,
        'page_title': entry.entry_number,
    })


@login_required
@role_required('admin', 'factory_manager')
def profit_loss(request):
    """Simple P&L report"""
    revenue_accounts  = Account.objects.filter(account_type='revenue', is_active=True)
    cogs_accounts     = Account.objects.filter(account_type='cogs', is_active=True)
    expense_accounts  = Account.objects.filter(account_type='expense', is_active=True)

    total_revenue  = sum(a.balance for a in revenue_accounts)
    total_cogs     = sum(a.balance for a in cogs_accounts)
    total_expenses = sum(a.balance for a in expense_accounts)
    gross_profit   = total_revenue - total_cogs
    net_profit     = gross_profit - total_expenses

    return render(request, 'gl/profit_loss.html', {
        'revenue_accounts':  revenue_accounts,
        'cogs_accounts':     cogs_accounts,
        'expense_accounts':  expense_accounts,
        'total_revenue':     total_revenue,
        'total_cogs':        total_cogs,
        'gross_profit':      gross_profit,
        'total_expenses':    total_expenses,
        'net_profit':        net_profit,
        'page_title':        'Profit & Loss Statement',
    })


@login_required
@role_required('admin', 'factory_manager')
def trial_balance(request):
    """Trial balance — all accounts with debit/credit totals"""
    accounts = Account.objects.filter(is_active=True).order_by('code')
    rows = []
    total_dr = Decimal('0')
    total_cr = Decimal('0')
    for acc in accounts:
        from django.db.models import Sum
        agg = acc.journal_lines.aggregate(
            dr=Sum('debit_amount'), cr=Sum('credit_amount')
        )
        dr = agg['dr'] or Decimal('0')
        cr = agg['cr'] or Decimal('0')
        if dr or cr:
            rows.append({'account': acc, 'debit': dr, 'credit': cr})
            total_dr += dr
            total_cr += cr
    return render(request, 'gl/trial_balance.html', {
        'rows': rows,
        'total_dr': total_dr,
        'total_cr': total_cr,
        'balanced': total_dr == total_cr,
        'page_title': 'Trial Balance',
    })
