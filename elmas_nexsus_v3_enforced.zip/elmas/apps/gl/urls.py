from django.urls import path
from . import views
app_name = 'gl'
urlpatterns = [
    path('',                    views.gl_dashboard,    name='dashboard'),
    path('accounts/',           views.account_list,    name='account_list'),
    path('journal/',            views.journal_list,    name='journal_list'),
    path('journal/<int:pk>/',   views.journal_detail,  name='journal_detail'),
    path('pl/',                 views.profit_loss,     name='profit_loss'),
    path('trial-balance/',      views.trial_balance,   name='trial_balance'),
]
