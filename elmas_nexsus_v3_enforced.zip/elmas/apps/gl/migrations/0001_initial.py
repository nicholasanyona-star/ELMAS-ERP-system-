"""
ELMAS-NEXSUS ERP — GL Migration 0001
Initial: Account, CostCentre, JournalEntry, JournalLine
"""
from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone
from django.conf import settings


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ('master', '0002_new_types_settings_lines'),
        ('accounts', '0004_user_assigned_line'),
    ]

    operations = [

        migrations.CreateModel(
            name='Account',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True)),
                ('code', models.CharField(db_index=True, max_length=20, unique=True)),
                ('name', models.CharField(max_length=200)),
                ('account_type', models.CharField(
                    choices=[
                        ('asset', 'Asset'), ('liability', 'Liability'),
                        ('equity', 'Equity'), ('revenue', 'Revenue'),
                        ('expense', 'Expense'), ('cogs', 'Cost of Goods Sold'),
                    ],
                    db_index=True, max_length=15,
                )),
                ('subtype', models.CharField(
                    choices=[
                        ('cash', 'Cash & Bank'), ('receivable', 'Accounts Receivable'),
                        ('inventory', 'Inventory'), ('wip', 'Work In Progress'),
                        ('fixed_asset', 'Fixed Asset'), ('other_asset', 'Other Asset'),
                        ('payable', 'Accounts Payable'), ('tax_payable', 'Tax Payable'),
                        ('other_liability', 'Other Liability'), ('retained', 'Retained Earnings'),
                        ('capital', 'Share Capital'), ('sales', 'Sales Revenue'),
                        ('other_income', 'Other Income'), ('material_cost', 'Direct Material Cost'),
                        ('labour_cost', 'Direct Labour Cost'), ('overhead', 'Manufacturing Overhead'),
                        ('write_off', 'Write-off / Scrap'), ('operating', 'Operating Expense'),
                    ],
                    max_length=20,
                )),
                ('is_system', models.BooleanField(default=False)),
                ('is_active', models.BooleanField(default=True)),
                ('description', models.TextField(blank=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('parent', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='children', to='gl.account',
                )),
            ],
            options={'ordering': ['code']},
        ),

        migrations.CreateModel(
            name='CostCentre',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True)),
                ('code', models.CharField(max_length=20, unique=True)),
                ('name', models.CharField(max_length=100)),
                ('centre_type', models.CharField(
                    choices=[
                        ('production_line', 'Production Line'),
                        ('department', 'Department'),
                        ('project', 'Project'),
                        ('overhead', 'Overhead Pool'),
                    ],
                    max_length=20,
                )),
                ('is_active', models.BooleanField(default=True)),
                ('production_line', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    to='master.productionline',
                )),
            ],
            options={'ordering': ['code']},
        ),

        migrations.CreateModel(
            name='JournalEntry',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True)),
                ('entry_number', models.CharField(db_index=True, max_length=50, unique=True)),
                ('entry_date', models.DateField(default=django.utils.timezone.now)),
                ('source', models.CharField(
                    choices=[
                        ('manual', 'Manual Journal'), ('stock_movement', 'Stock Movement'),
                        ('mrn_issue', 'MRN Material Issue'), ('brn_acceptance', 'BRN Battery Issue'),
                        ('bcr_writeoff', 'BCR Write-off'), ('dn_dispatch', 'Delivery Note Dispatch'),
                        ('po_receipt', 'PO Goods Receipt'), ('iqc_pass', 'IQC Pass'),
                        ('labour_posting', 'Labour Cost Posting'), ('payroll_run', 'Payroll Run'),
                        ('adjustment', 'Stock Adjustment'), ('reversal', 'Reversal Entry'),
                    ],
                    db_index=True, max_length=20,
                )),
                ('description', models.TextField()),
                ('reference', models.CharField(blank=True, db_index=True, max_length=100)),
                ('source_app', models.CharField(blank=True, max_length=30)),
                ('source_model', models.CharField(blank=True, max_length=50)),
                ('source_id', models.IntegerField(blank=True, null=True)),
                ('is_posted', models.BooleanField(default=True)),
                ('is_reversed', models.BooleanField(default=False)),
                ('notes', models.TextField(blank=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('cost_centre', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    to='gl.costcentre',
                )),
                ('posted_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='journal_entries',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('reversal_of', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='reversed_by', to='gl.journalentry',
                )),
            ],
            options={
                'verbose_name': 'Journal Entry',
                'verbose_name_plural': 'Journal Entries',
                'ordering': ['-entry_date', '-created_at'],
            },
        ),

        migrations.CreateModel(
            name='JournalLine',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True)),
                ('description', models.CharField(blank=True, max_length=200)),
                ('debit_amount', models.DecimalField(decimal_places=2, default=0, max_digits=15)),
                ('credit_amount', models.DecimalField(decimal_places=2, default=0, max_digits=15)),
                ('journal_entry', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='lines', to='gl.journalentry',
                )),
                ('account', models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    related_name='journal_lines', to='gl.account',
                )),
                ('cost_centre', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    to='gl.costcentre',
                )),
            ],
            options={'ordering': ['id']},
        ),
    ]
