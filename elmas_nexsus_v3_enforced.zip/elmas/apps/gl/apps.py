from django.apps import AppConfig


class GLConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.gl'
    verbose_name = 'General Ledger'
