from django.urls import path
from . import views
app_name = 'reports'
urlpatterns = [
    path('', views.reports_home, name='home'),
    path('stock/', views.stock_report, name='stock'),
    path('receiving/', views.receiving_report, name='receiving'),
    path('iqc/', views.iqc_report, name='iqc'),
    path('quarantine/', views.quarantine_report, name='quarantine'),
    path('movements/', views.movement_report, name='movements'),
    path('stock/excel/', views.stock_report_excel, name='stock_excel'),
    path('receiving/excel/', views.receiving_report_excel, name='receiving_excel'),
    path('production/', views.production_report, name='production_report'),
    path('suppliers/', views.supplier_performance_report, name='supplier_performance'),
    path('expiry/', views.expiry_report, name='expiry_report'),
]

