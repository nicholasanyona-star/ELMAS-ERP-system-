"""ELMAS Reports Views"""
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from apps.accounts.decorators import role_required
import logging
logger = logging.getLogger('elmas')


def _safe(fn, default=None):
    try: return fn()
    except Exception as e:
        logger.warning(f'[reports] {e}')
        return default


@login_required
def reports_home(request):
    return render(request, 'reports/home.html', {'page_title': 'Reports'})


@login_required
@role_required('admin', 'factory_manager', 'warehouse')
def stock_report(request):
    from apps.inventory.models import Product, StockBatch
    from django.db.models import Sum, F
    category = request.GET.get('category', '')
    products = Product.objects.filter(is_active=True)
    if category:
        products = products.filter(category=category)
    data = []
    total_value = 0
    for p in products.order_by('category', 'name'):
        stock = p.current_stock
        value = float(stock) * float(p.unit_cost)
        total_value += value
        data.append({'product': p, 'stock': stock, 'value': value,
                     'status': 'out' if stock == 0 else 'low' if stock <= float(p.reorder_point) else 'ok'})
    from apps.master.models import SystemSettings
    return render(request, 'reports/stock_report.html', {
        'data': data, 'total_value': total_value, 'category': category,
        'categories': Product.CATEGORY_CHOICES,
        'generated_at': timezone.now(),
        'sys': SystemSettings.get_settings(),
        'page_title': 'Stock Valuation Report',
    })


@login_required
@role_required('admin', 'factory_manager', 'warehouse', 'receiving')
def receiving_report(request):
    from apps.receiving.models import GRN
    from_date = request.GET.get('from_date', str((timezone.now() - timezone.timedelta(days=30)).date()))
    to_date = request.GET.get('to_date', str(timezone.now().date()))
    grns = GRN.objects.filter(
        created_at__date__gte=from_date,
        created_at__date__lte=to_date,
    ).select_related('received_by', 'verified_by').order_by('-created_at')
    from apps.master.models import SystemSettings
    return render(request, 'reports/receiving_report.html', {
        'grns': grns, 'from_date': from_date, 'to_date': to_date,
        'total': grns.count(),
        'generated_at': timezone.now(),
        'sys': SystemSettings.get_settings(),
        'page_title': 'Receiving Report',
    })


@login_required
@role_required('admin', 'factory_manager', 'qc')
def iqc_report(request):
    from apps.receiving.models import IQCInspection
    from_date = request.GET.get('from_date', str((timezone.now() - timezone.timedelta(days=30)).date()))
    to_date = request.GET.get('to_date', str(timezone.now().date()))
    inspections = IQCInspection.objects.filter(
        inspected_at__date__gte=from_date,
        inspected_at__date__lte=to_date,
    ).select_related('inspected_by', 'grn').order_by('-inspected_at')
    passed = inspections.filter(decision='pass').count()
    failed = inspections.filter(decision='fail').count()
    partial = inspections.filter(decision='partial').count()
    from apps.master.models import SystemSettings
    return render(request, 'reports/iqc_report.html', {
        'inspections': inspections, 'from_date': from_date, 'to_date': to_date,
        'passed': passed, 'failed': failed, 'partial': partial,
        'generated_at': timezone.now(),
        'sys': SystemSettings.get_settings(),
        'page_title': 'IQC Report',
    })


@login_required
@role_required('admin', 'factory_manager', 'qc')
def quarantine_report(request):
    from apps.receiving.models import Quarantine
    items = Quarantine.objects.select_related('grn', 'decided_by').order_by('-created_at')[:100]
    open_count = Quarantine.objects.filter(status='pending').count()
    overdue = Quarantine.objects.filter(status='pending', deadline__lt=timezone.now()).count()
    from apps.master.models import SystemSettings
    return render(request, 'reports/quarantine_report.html', {
        'items': items, 'open_count': open_count, 'overdue': overdue,
        'now': timezone.now(),
        'generated_at': timezone.now(),
        'sys': SystemSettings.get_settings(),
        'page_title': 'Quarantine Report',
    })


@login_required
@role_required('admin', 'factory_manager', 'warehouse')
def movement_report(request):
    from apps.inventory.models import StockMovement
    from_date = request.GET.get('from_date', str((timezone.now() - timezone.timedelta(days=7)).date()))
    to_date = request.GET.get('to_date', str(timezone.now().date()))
    movements = StockMovement.objects.filter(
        created_at__date__gte=from_date,
        created_at__date__lte=to_date,
    ).select_related('product', 'performed_by').order_by('-created_at')
    from apps.master.models import SystemSettings
    return render(request, 'reports/movement_report.html', {
        'movements': movements, 'from_date': from_date, 'to_date': to_date,
        'generated_at': timezone.now(),
        'sys': SystemSettings.get_settings(),
        'page_title': 'Stock Movement Report',
    })


@login_required
@role_required('admin', 'factory_manager', 'warehouse')
def stock_report_excel(request):
    """Export stock report to Excel"""
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment
    from django.http import HttpResponse
    from apps.inventory.models import Product
    from apps.master.models import SystemSettings
    sys = SystemSettings.get_settings()
    category = request.GET.get('category', '')
    products = Product.objects.filter(is_active=True)
    if category:
        products = products.filter(category=category)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = 'Stock Report'
    # Header
    ws.merge_cells('A1:H1')
    ws['A1'] = f'{sys.company_name} — Stock Valuation Report'
    ws['A1'].font = Font(bold=True, size=14)
    ws['A1'].alignment = Alignment(horizontal='center')
    ws['A2'] = f'Generated: {timezone.now().strftime("%d %B %Y %H:%M")}'
    ws['A2'].alignment = Alignment(horizontal='center')
    ws.merge_cells('A2:H2')
    # Column headers
    headers = ['SKU', 'Item Name', 'Category', 'UOM', 'In Stock', 'Unit Cost (Kshs)', 'Stock Value (Kshs)', 'Status']
    header_row = 4
    header_fill = PatternFill(start_color='1A1A2E', end_color='1A1A2E', fill_type='solid')
    header_font = Font(color='FFFFFF', bold=True)
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=header_row, column=col, value=header)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center')
    # Data
    total_value = 0
    for row_num, product in enumerate(products.order_by('category', 'name'), header_row + 1):
        stock = product.current_stock
        value = float(stock) * float(product.unit_cost)
        total_value += value
        status = 'Out of Stock' if stock == 0 else 'Low' if stock <= float(product.reorder_point) else 'OK'
        ws.cell(row=row_num, column=1, value=product.sku)
        ws.cell(row=row_num, column=2, value=product.name)
        ws.cell(row=row_num, column=3, value=product.get_category_display())
        ws.cell(row=row_num, column=4, value=product.uom)
        ws.cell(row=row_num, column=5, value=float(stock))
        ws.cell(row=row_num, column=6, value=float(product.unit_cost))
        ws.cell(row=row_num, column=7, value=round(value, 2))
        ws.cell(row=row_num, column=8, value=status)
        if stock == 0:
            for col in range(1, 9):
                ws.cell(row=row_num, column=col).fill = PatternFill(start_color='FFE0E0', end_color='FFE0E0', fill_type='solid')
    # Total row
    last_row = header_row + products.count() + 1
    ws.cell(row=last_row, column=1, value='TOTAL').font = Font(bold=True)
    ws.cell(row=last_row, column=7, value=round(total_value, 2)).font = Font(bold=True)
    # Column widths
    for col, width in [(1,15),(2,35),(3,18),(4,8),(5,12),(6,18),(7,18),(8,12)]:
        ws.column_dimensions[openpyxl.utils.get_column_letter(col)].width = width
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=ELMAS_Stock_Report.xlsx'
    wb.save(response)
    return response


@login_required
@role_required('admin', 'factory_manager', 'warehouse', 'receiving')
def receiving_report_excel(request):
    """Export receiving report to Excel"""
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment
    from django.http import HttpResponse
    from apps.receiving.models import GRN
    from apps.master.models import SystemSettings
    sys = SystemSettings.get_settings()
    from_date = request.GET.get('from_date', str((timezone.now() - timezone.timedelta(days=30)).date()))
    to_date = request.GET.get('to_date', str(timezone.now().date()))
    grns = GRN.objects.filter(
        created_at__date__gte=from_date,
        created_at__date__lte=to_date,
    ).select_related('received_by', 'verified_by').order_by('-created_at')
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = 'Receiving Report'
    ws.merge_cells('A1:G1')
    ws['A1'] = f'{sys.company_name} — Receiving Report ({from_date} to {to_date})'
    ws['A1'].font = Font(bold=True, size=13)
    headers = ['GRN Number', 'Category', 'Supplier', 'Items', 'Status', 'Received By', 'Date']
    header_fill = PatternFill(start_color='1A1A2E', end_color='1A1A2E', fill_type='solid')
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=3, column=col, value=header)
        cell.fill = header_fill
        cell.font = Font(color='FFFFFF', bold=True)
    for row_num, grn in enumerate(grns, 4):
        ws.cell(row=row_num, column=1, value=grn.grn_number)
        ws.cell(row=row_num, column=2, value=grn.get_material_category_display())
        ws.cell(row=row_num, column=3, value=grn.supplier_name_manual)
        ws.cell(row=row_num, column=4, value=grn.lines.count())
        ws.cell(row=row_num, column=5, value=grn.get_status_display())
        ws.cell(row=row_num, column=6, value=grn.received_by.get_full_name() if grn.received_by else '')
        ws.cell(row=row_num, column=7, value=grn.created_at.strftime('%d %b %Y'))
    for col, width in [(1,22),(2,20),(3,30),(4,8),(5,18),(6,22),(7,14)]:
        ws.column_dimensions[openpyxl.utils.get_column_letter(col)].width = width
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=ELMAS_Receiving_Report.xlsx'
    wb.save(response)
    return response


@login_required
@role_required('admin', 'factory_manager', 'pmc', 'production')
def production_report(request):
    from apps.pmc.models import WorkOrder
    from apps.production.models import ProductionOutput, StageHandover
    from django.db.models import Sum, Count
    from django.utils import timezone
    from_date = request.GET.get('from_date', str((timezone.now() - timezone.timedelta(days=30)).date()))
    to_date = request.GET.get('to_date', str(timezone.now().date()))
    outputs = ProductionOutput.objects.filter(
        output_date__gte=from_date, output_date__lte=to_date
    ).select_related('work_order__bom', 'logged_by').order_by('-output_date')
    # Summaries
    total_produced = outputs.aggregate(total=Sum('qty_produced'))['total'] or 0
    total_defective = outputs.aggregate(total=Sum('qty_defective'))['total'] or 0
    total_good = total_produced - total_defective
    defect_rate = round((total_defective / total_produced * 100), 1) if total_produced > 0 else 0
    # Per WO summary
    by_wo = outputs.values(
        'work_order__wo_number', 'work_order__bom__phone_model'
    ).annotate(
        produced=Sum('qty_produced'),
        defective=Sum('qty_defective'),
        good=Sum('qty_produced') - Sum('qty_defective'),
    ).order_by('-produced')
    return render(request, 'reports/production_report.html', {
        'outputs': outputs[:50],
        'total_produced': total_produced,
        'total_defective': total_defective,
        'total_good': total_good,
        'defect_rate': defect_rate,
        'by_wo': by_wo,
        'from_date': from_date,
        'to_date': to_date,
        'page_title': 'Production Report',
    })


@login_required
@role_required('admin', 'factory_manager', 'procurement', 'warehouse')
def supplier_performance_report(request):
    from apps.inventory.models import Supplier, SupplierPerformance
    suppliers = Supplier.objects.filter(is_active=True).select_related('performance').order_by('name')
    return render(request, 'reports/supplier_performance.html', {
        'suppliers': suppliers, 'page_title': 'Supplier Performance',
    })


@login_required
@role_required('admin', 'factory_manager', 'warehouse')
def expiry_report(request):
    from apps.inventory.models import StockBatch
    from django.utils import timezone
    import datetime
    today = timezone.now().date()
    warning_date = today + datetime.timedelta(days=90)
    expiring = StockBatch.objects.filter(
        expiry_date__isnull=False,
        expiry_date__lte=warning_date,
        status='available',
    ).select_related('product').order_by('expiry_date')
    expired = expiring.filter(expiry_date__lt=today)
    expiring_soon = expiring.filter(expiry_date__gte=today)
    return render(request, 'reports/expiry_report.html', {
        'expired': expired,
        'expiring_soon': expiring_soon,
        'today': today,
        'page_title': 'Expiry Report',
    })
