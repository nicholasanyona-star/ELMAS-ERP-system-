from django.contrib import admin
from .models import Message, MessageRecipient, MessageReply


class MessageRecipientInline(admin.TabularInline):
    model = MessageRecipient
    extra = 0
    readonly_fields = ('recipient', 'read_at', 'is_read')


@admin.register(Message)
class MessageAdmin(admin.ModelAdmin):
    list_display = ('subject', 'sender', 'priority', 'is_urgent', 'created_at')
    list_filter = ('priority', 'is_urgent')
    search_fields = ('subject', 'sender__username', 'body')
    inlines = [MessageRecipientInline]
    ordering = ('-created_at',)


@admin.register(MessageReply)
class MessageReplyAdmin(admin.ModelAdmin):
    list_display = ('message', 'sender', 'created_at')
    search_fields = ('message__subject', 'sender__username')
    ordering = ('-created_at',)
