"""
ELMAS Messaging Models
Urgent + Normal + Inbox — all three working
"""
from django.db import models
from django.conf import settings
from django.utils import timezone


class Message(models.Model):
    """
    Internal message between staff members
    Can be sent to individual or entire role
    Can have document attached
    """
    PRIORITY_CHOICES = (
        ('urgent', '🔴 Urgent — full screen popup'),
        ('normal', '📩 Normal — inbox notification'),
    )
    MESSAGE_CATEGORY_CHOICES = (
        ('system_alert',    '🔔 System Alert'),
        ('approval_request','✅ Approval Request'),
        ('fyi',             'ℹ️ For Your Information'),
        ('manual',          '✉️ Manual Message'),
        ('daily_summary',   '📊 Daily Summary'),
    )

    subject = models.CharField(max_length=200, blank=True)
    body = models.TextField()
    priority = models.CharField(
        max_length=10,
        choices=PRIORITY_CHOICES,
        default='normal',
        db_index=True
    )

    # Sender
    sender = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        related_name='sent_messages'
    )

    # Broadcast to role
    broadcast_role = models.CharField(
        max_length=20, blank=True,
        help_text='If set, sent to all users with this role'
    )

    # Document attachment
    ref_module = models.CharField(max_length=30, blank=True)
    ref_number = models.CharField(max_length=50, blank=True)
    ref_display = models.CharField(max_length=100, blank=True)

    sent_at = models.DateTimeField(auto_now_add=True, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True, null=True)

    # Convenience fields
    is_urgent = models.BooleanField(default=False, db_index=True)
    reference_type = models.CharField(max_length=30, blank=True)
    reference_number = models.CharField(max_length=50, blank=True)

    # Category
    category = models.CharField(
        max_length=20,
        choices=MESSAGE_CATEGORY_CHOICES,
        default='manual',
        db_index=True
    )

    # Action button — for approval requests
    action_url = models.CharField(
        max_length=200, blank=True,
        help_text='Direct URL to action e.g. /pmc/mrn/42/approve/'
    )
    action_label = models.CharField(
        max_length=50, blank=True,
        help_text='Button label e.g. Approve MRN'
    )
    action_role = models.CharField(
        max_length=20, blank=True,
        help_text='Only show action button to this role'
    )

    # Expiry — system alerts auto-expire
    expires_at = models.DateTimeField(
        null=True, blank=True,
        help_text='Message hidden from inbox after this time'
    )

    class Meta:
        ordering = ['-sent_at']

    def __str__(self):
        return f"{self.get_priority_display()} from {self.sender} — {self.subject or self.body[:50]}"


class MessageRecipient(models.Model):
    """
    Links a message to each recipient
    Tracks read status individually
    """
    message = models.ForeignKey(
        Message,
        on_delete=models.CASCADE,
        related_name='recipients'
    )
    recipient = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='received_messages'
    )
    is_read = models.BooleanField(default=False, db_index=True)
    is_dismissed = models.BooleanField(default=False)
    read_at = models.DateTimeField(null=True, blank=True)
    popup_shown = models.BooleanField(default=False)

    class Meta:
        unique_together = ['message', 'recipient']

    def mark_read(self):
        if not self.is_read:
            self.is_read = True
            self.read_at = timezone.now()
            self.save(update_fields=['is_read', 'read_at'])

    def __str__(self):
        return f"To: {self.recipient.username} — {'Read' if self.is_read else 'Unread'}"


class MessageReply(models.Model):
    """Reply to a message — threaded conversation"""
    message = models.ForeignKey(
        Message,
        on_delete=models.CASCADE,
        related_name='replies'
    )
    sender = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True
    )
    body = models.TextField()
    sent_at = models.DateTimeField(auto_now_add=True)
    created_at = models.DateTimeField(auto_now_add=True, null=True)

    class Meta:
        ordering = ['sent_at']

    def __str__(self):
        return f"Reply to {self.message} by {self.sender}"


def send_message(sender, recipients_or_role, subject, body,
                 priority='normal', ref_module='', ref_number='',
                 ref_display=''):
    """
    Helper function to send a message
    recipients_or_role can be:
      - A User object (single recipient)
      - A list of User objects
      - A string role name (broadcasts to all with that role)
      - 'all' (broadcasts to everyone)
    """
    from django.contrib.auth import get_user_model
    User = get_user_model()

    msg = Message.objects.create(
        sender=sender,
        subject=subject,
        body=body,
        priority=priority,
        ref_module=ref_module,
        ref_number=ref_number,
        ref_display=ref_display,
    )

    # Determine recipients
    if isinstance(recipients_or_role, str):
        if recipients_or_role == 'all':
            users = User.objects.filter(is_active=True)
        else:
            users = User.objects.filter(
                role=recipients_or_role, is_active=True
            )
            msg.broadcast_role = recipients_or_role
            msg.save(update_fields=['broadcast_role'])
    elif hasattr(recipients_or_role, '__iter__'):
        users = recipients_or_role
    else:
        users = [recipients_or_role]

    for user in users:
        if sender and user.pk == sender.pk:
            continue
        MessageRecipient.objects.create(
            message=msg,
            recipient=user
        )

    return msg
