from django.urls import path
from . import views
app_name = 'messaging'
urlpatterns = [
    path('', views.inbox, name='inbox'),
    path('compose/', views.compose, name='compose'),
    path('<int:pk>/', views.message_detail, name='message_detail'),
    path('sent/', views.sent, name='sent'),
    path('api/unread/', views.api_unread, name='api_unread'),
    path('api/pending/', views.api_pending_urgent, name='api_pending_urgent'),
    path('mark-all-read/', views.mark_all_read, name='mark_all_read'),
    path('<int:pk>/dismiss/', views.dismiss_message, name='dismiss_message'),
]
