"""ELMAS Messaging Views"""
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.contrib import messages
from django.utils import timezone
from .models import Message, MessageRecipient, MessageReply
from apps.accounts.models import User
import logging
logger = logging.getLogger('elmas')


@login_required
def inbox(request):
    from django.core.paginator import Paginator
    received_qs = MessageRecipient.objects.filter(
        recipient=request.user, is_dismissed=False
    ).select_related('message__sender').order_by('-message__sent_at')
    unread_count = received_qs.filter(is_read=False).count()
    paginator = Paginator(received_qs, 25)
    page_obj = paginator.get_page(request.GET.get('page', 1))
    return render(request, 'messaging/inbox.html', {
        'received': page_obj, 'page_obj': page_obj,
        'page_title': 'Inbox',
        'unread_count': unread_count,
    })


@login_required
def compose(request):
    users = User.objects.filter(is_active=True).exclude(pk=request.user.pk).order_by('last_name')
    if request.method == 'POST':
        subject = request.POST.get('subject', '').strip()
        body = request.POST.get('body', '').strip()
        is_urgent = request.POST.get('is_urgent') == 'on'
        ref_type = request.POST.get('reference_type', '').strip()
        ref_num = request.POST.get('reference_number', '').strip()
        recipient_ids = request.POST.getlist('recipients')
        role_broadcast = request.POST.get('role_broadcast', '')
        if not body:
            messages.error(request, 'Message body is required.')
            return render(request, 'messaging/compose.html', {
                'users': users, 'roles': User.ROLE_CHOICES, 'page_title': 'Compose Message',
            })
        msg = Message.objects.create(
            sender=request.user,
            subject=subject or '(No subject)',
            body=body,
            is_urgent=is_urgent,
            priority='urgent' if is_urgent else 'normal',
            ref_module=ref_type,
            ref_number=ref_num,
            reference_type=ref_type,
            reference_number=ref_num,
        )
        # Individual recipients
        for rid in recipient_ids:
            try:
                r = User.objects.get(pk=int(rid))
                MessageRecipient.objects.create(message=msg, recipient=r)
            except Exception:
                pass
        # Role broadcast
        if role_broadcast:
            for u in User.objects.filter(role=role_broadcast, is_active=True).exclude(pk=request.user.pk):
                MessageRecipient.objects.get_or_create(message=msg, recipient=u)
        messages.success(request, f'✓ Message sent.')
        return redirect('messaging:sent')
    return render(request, 'messaging/compose.html', {
        'users': users, 'roles': User.ROLE_CHOICES, 'page_title': 'Compose Message',
    })


@login_required
def message_detail(request, pk):
    recipient_entry = get_object_or_404(MessageRecipient, message_id=pk, recipient=request.user)
    msg = recipient_entry.message
    if not recipient_entry.is_read:
        recipient_entry.is_read = True
        recipient_entry.read_at = timezone.now()
        recipient_entry.save(update_fields=['is_read', 'read_at'])
    replies = msg.replies.select_related('sender').order_by('sent_at')
    if request.method == 'POST':
        reply_body = request.POST.get('reply', '').strip()
        if reply_body:
            MessageReply.objects.create(message=msg, sender=request.user, body=reply_body)
            messages.success(request, 'Reply sent.')
            return redirect('messaging:message_detail', pk=pk)
    return render(request, 'messaging/message_detail.html', {
        'msg': msg, 'replies': replies, 'page_title': msg.subject,
    })


@login_required
def sent(request):
    from django.core.paginator import Paginator
    sent_qs = Message.objects.filter(sender=request.user).prefetch_related('recipients__recipient').order_by('-sent_at')
    paginator = Paginator(sent_qs, 25)
    page_obj = paginator.get_page(request.GET.get('page', 1))
    return render(request, 'messaging/sent.html', {
        'sent_msgs': page_obj, 'page_obj': page_obj, 'page_title': 'Sent Messages',
    })


@login_required
def api_unread(request):
    count = MessageRecipient.objects.filter(recipient=request.user, is_read=False).count()
    return JsonResponse({'unread': count})


@login_required
def api_pending_urgent(request):
    """Return unread urgent messages for popup display"""
    urgent = MessageRecipient.objects.filter(
        recipient=request.user, is_read=False, message__is_urgent=True
    ).select_related('message__sender').order_by('message__created_at')[:3]
    data = [{
        'id': r.message.pk,
        'subject': r.message.subject,
        'sender': r.message.sender.get_full_name(),
        'body': r.message.body[:200],
        'ref_type': r.message.reference_type,
        'ref_num': r.message.reference_number,
    } for r in urgent]
    return JsonResponse({'urgent': data})


def send_system_message(subject, body, role=None, user=None, is_urgent=False, ref_type='', ref_num=''):
    """Helper to send system-generated messages"""
    try:
        from apps.accounts.models import User as U
        system_user = U.objects.filter(role='admin').first()
        if not system_user:
            return
        msg = Message.objects.create(
            sender=system_user, subject=subject, body=body,
            is_urgent=is_urgent,
            ref_module=ref_type, ref_number=ref_num,
            reference_type=ref_type, reference_number=ref_num,
        )
        if user:
            MessageRecipient.objects.create(message=msg, recipient=user)
        elif role:
            for u in U.objects.filter(role=role, is_active=True):
                MessageRecipient.objects.create(message=msg, recipient=u)
    except Exception as e:
        logger.error(f'[send_system_message] {e}')

@login_required
def mark_all_read(request):
    if request.method == 'POST':
        MessageRecipient.objects.filter(
            recipient=request.user, is_read=False
        ).update(is_read=True, read_at=timezone.now())
        messages.success(request, '✓ All messages marked as read.')
    return redirect('messaging:inbox')


@login_required
def dismiss_message(request, pk):
    if request.method == 'POST':
        MessageRecipient.objects.filter(
            message_id=pk, recipient=request.user
        ).update(is_dismissed=True, is_read=True)
    return redirect('messaging:inbox')
