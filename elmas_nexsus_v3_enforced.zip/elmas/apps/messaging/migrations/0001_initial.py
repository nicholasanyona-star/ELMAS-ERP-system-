from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    initial = True
    dependencies = [("accounts", "0001_initial")]
    operations = [
        migrations.CreateModel("Message", fields=[
            ("id", models.BigAutoField(auto_created=True, primary_key=True)),
            ("subject", models.CharField(blank=True, max_length=200)),
            ("body", models.TextField()),
            ("priority", models.CharField(choices=[
                ("urgent","Urgent"),("normal","Normal"),
            ], db_index=True, default="normal", max_length=10)),
            ("broadcast_role", models.CharField(blank=True, max_length=20)),
            ("ref_module", models.CharField(blank=True, max_length=30)),
            ("ref_number", models.CharField(blank=True, max_length=50)),
            ("ref_display", models.CharField(blank=True, max_length=100)),
            ("sent_at", models.DateTimeField(auto_now_add=True, db_index=True)),
            ("sender", models.ForeignKey(blank=True, null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="sent_messages", to="accounts.user")),
        ], options={"ordering": ["-sent_at"]}),
        migrations.CreateModel("MessageRecipient", fields=[
            ("id", models.BigAutoField(auto_created=True, primary_key=True)),
            ("is_read", models.BooleanField(db_index=True, default=False)),
            ("is_dismissed", models.BooleanField(default=False)),
            ("read_at", models.DateTimeField(blank=True, null=True)),
            ("popup_shown", models.BooleanField(default=False)),
            ("message", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,
                related_name="recipients", to="messaging.message")),
            ("recipient", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,
                related_name="received_messages", to="accounts.user")),
        ], options={"unique_together": {("message", "recipient")}}),
        migrations.CreateModel("MessageReply", fields=[
            ("id", models.BigAutoField(auto_created=True, primary_key=True)),
            ("body", models.TextField()),
            ("sent_at", models.DateTimeField(auto_now_add=True)),
            ("message", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,
                related_name="replies", to="messaging.message")),
            ("sender", models.ForeignKey(blank=True, null=True,
                on_delete=django.db.models.deletion.SET_NULL, to="accounts.user")),
        ], options={"ordering": ["sent_at"]}),
    ]
