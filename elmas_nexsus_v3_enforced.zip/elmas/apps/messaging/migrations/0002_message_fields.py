from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('messaging', '0001_initial'),
    ]
    operations = [
        migrations.AddField(
            model_name='message',
            name='is_urgent',
            field=models.BooleanField(default=False, db_index=True),
        ),
        migrations.AddField(
            model_name='message',
            name='reference_type',
            field=models.CharField(blank=True, max_length=30),
        ),
        migrations.AddField(
            model_name='message',
            name='reference_number',
            field=models.CharField(blank=True, max_length=50),
        ),
        migrations.AddField(
            model_name='message',
            name='created_at',
            field=models.DateTimeField(auto_now_add=True, null=True),
        ),
    ]
