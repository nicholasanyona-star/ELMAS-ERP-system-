"""
ELMAS Messaging Migration 0003
- Add category, action_url, action_label, action_role, expires_at to Message
"""
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('messaging', '0002_message_fields'),
    ]

    operations = [
        migrations.AddField(
            model_name='message',
            name='category',
            field=models.CharField(
                choices=[
                    ('system_alert', '🔔 System Alert'),
                    ('approval_request', '✅ Approval Request'),
                    ('fyi', 'ℹ️ For Your Information'),
                    ('manual', '✉️ Manual Message'),
                    ('daily_summary', '📊 Daily Summary'),
                ],
                db_index=True, default='manual', max_length=20,
            ),
        ),
        migrations.AddField(
            model_name='message',
            name='action_url',
            field=models.CharField(blank=True, max_length=200),
        ),
        migrations.AddField(
            model_name='message',
            name='action_label',
            field=models.CharField(blank=True, max_length=50),
        ),
        migrations.AddField(
            model_name='message',
            name='action_role',
            field=models.CharField(blank=True, max_length=20),
        ),
        migrations.AddField(
            model_name='message',
            name='expires_at',
            field=models.DateTimeField(blank=True, null=True),
        ),
    ]
