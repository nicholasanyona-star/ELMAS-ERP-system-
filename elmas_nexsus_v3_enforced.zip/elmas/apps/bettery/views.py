"""
ELMAS Bettery Views
Battery store management — BRN generation, BCR reporting, dashboard
"""
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from django.db import transaction
from apps.accounts.decorators import role_required
from .models import BatteryReleaseNote, BRNLine, BatteryConditionReport
import logging
logger = logging.getLogger('elmas')


@login_required
@role_required('admin', 'warehouse', 'factory_manager', 'battery_controller')
def bettery_dashboard(request):
    """
    Bettery Dashboard — battery stock overview, pending picks, BRNs, BCRs.
    Batteries are item_type='battery' in Product.
    Main inventory is the single source — this is a filtered lens.
    """
    from apps.inventory.models import Product, StockBatch, StockMovement
    from apps.receiving.models import GRN
    from datetime import timedelta

    # Battery products
    battery_products = Product.objects.filter(
        is_active=True, item_type='battery'
    ).order_by('name')

    product_data = []
    total_units = 0
    total_value = 0
    out_of_stock = 0
    low_stock = 0

    for p in battery_products:
        stock = p.current_stock
        value = float(stock) * float(p.unit_cost)
        status = 'out' if stock == 0 else 'low' if stock <= float(p.reorder_point) else 'ok'
        product_data.append({
            'product': p, 'stock': stock,
            'value': value, 'status': status,
        })
        total_units += float(stock)
        total_value += value
        if stock == 0:
            out_of_stock += 1
        elif status == 'low':
            low_stock += 1

    # Pending SIV picks — SIVs with battery lines awaiting BRN
    from apps.pmc.models import SIV
    pending_picks = SIV.objects.filter(
        has_battery_lines=True,
        status__in=['wh_pick_complete', 'battery_pending']
    ).select_related('mrn', 'work_order').order_by('created_at')

    # BRNs in progress
    brns_active = BatteryReleaseNote.objects.filter(
        status__in=['generated', 'printed', 'submitted']
    ).select_related('siv', 'work_order').order_by('-generated_at')[:10]

    # Recent completed BRNs
    recent_brns = BatteryReleaseNote.objects.filter(
        status='accepted'
    ).select_related('siv', 'accepted_by').order_by('-accepted_at')[:10]

    # Open BCRs
    open_bcrs = BatteryConditionReport.objects.filter(
        status__in=['reported', 'isolated', 'wh_inspected', 'fm_decided', 'wh_confirmed', 'removal_pending']
    ).select_related('product').order_by('-created_at')

    # Battery stock condition counts
    from apps.inventory.models import StockBatch
    from datetime import date
    today = date.today()
    thirty_days = today + timedelta(days=30)

    good_stock = StockBatch.objects.filter(
        product__item_type='battery', status='available',
        remaining_quantity__gt=0
    ).count()
    expiring_soon = StockBatch.objects.filter(
        product__item_type='battery', status='available',
        expiry_date__lte=thirty_days, expiry_date__gte=today
    ).count()
    expired = StockBatch.objects.filter(
        product__item_type='battery', status='available',
        expiry_date__lt=today
    ).count()

    # Recent GRNs
    recent_grns = GRN.objects.filter(
        material_category='battery'
    ).order_by('-created_at')[:5]

    # Recent movements
    recent_movements = StockMovement.objects.filter(
        product__item_type='battery'
    ).select_related('product', 'performed_by').order_by('-performed_at')[:15]

    return render(request, 'bettery/dashboard.html', {
        'page_title': '🔋 Bettery Dashboard',
        'product_data':    product_data,
        'total_products':  len(product_data),
        'total_units':     total_units,
        'total_value':     total_value,
        'out_of_stock':    out_of_stock,
        'low_stock':       low_stock,
        'pending_picks':   pending_picks,
        'brns_active':     brns_active,
        'recent_brns':     recent_brns,
        'open_bcrs':       open_bcrs,
        'good_stock':      good_stock,
        'expiring_soon':   expiring_soon,
        'expired':         expired,
        'recent_grns':     recent_grns,
        'recent_movements': recent_movements,
    })


@login_required
@role_required('admin', 'battery_controller')
def brn_generate(request, siv_pk):
    """Generate a Battery Release Note for battery lines on a SIV"""
    from apps.pmc.models import SIV, SIVLine
    from apps.inventory.models import consume_stock, StockBatch
    siv = get_object_or_404(SIV, pk=siv_pk)

    if hasattr(siv, 'brn'):
        messages.warning(request, f'BRN already exists for {siv.siv_number}.')
        return redirect('bettery:brn_detail', pk=siv.brn.pk)

    battery_lines = siv.lines.filter(is_battery_line=True)
    if not battery_lines.exists():
        messages.error(request, 'No battery lines found on this SIV.')
        return redirect('bettery:dashboard')

    if request.method == 'POST':
        try:
            with transaction.atomic():
                brn = BatteryReleaseNote.objects.create(
                    siv=siv,
                    work_order=siv.work_order,
                    generated_by=request.user,
                    status='generated',
                )
                # Create BRN lines from FIFO — lock batches
                for siv_line in battery_lines:
                    # FIFO — get oldest available batch
                    batches = StockBatch.objects.filter(
                        product=siv_line.product,
                        status='available',
                        remaining_quantity__gt=0,
                    ).order_by('received_at')

                    remaining = float(siv_line.qty_issued)
                    for batch in batches:
                        if remaining <= 0:
                            break
                        take = min(float(batch.remaining_quantity), remaining)
                        BRNLine.objects.create(
                            brn=brn,
                            product=siv_line.product,
                            batch=batch,
                            qty_issued=take,
                            uom=siv_line.uom,
                            batch_number_ref=batch.batch_number,
                            expiry_date_ref=batch.expiry_date,
                            from_location_ref=batch.location_display,
                        )
                        # Reserve batch
                        batch.status = 'reserved'
                        batch.save(update_fields=['status'])
                        remaining -= take

                # Update SIV status
                siv.status = 'battery_pending'
                siv.save(update_fields=['status'])

                messages.success(
                    request,
                    f'✓ {brn.brn_number} generated with {brn.lines.count()} line(s). Print and take to WH Controller.'
                )
                return redirect('bettery:brn_detail', pk=brn.pk)
        except Exception as e:
            logger.error(f'[brn_generate] {e}')
            messages.error(request, f'Error generating BRN: {e}')

    # Preview — show what will be on BRN
    preview_lines = []
    for siv_line in battery_lines:
        batches = StockBatch.objects.filter(
            product=siv_line.product,
            status='available',
            remaining_quantity__gt=0,
        ).order_by('received_at')
        preview_lines.append({
            'product': siv_line.product,
            'qty_needed': siv_line.qty_issued,
            'fifo_batch': batches.first(),
            'available': sum(float(b.remaining_quantity) for b in batches),
        })

    return render(request, 'bettery/brn_generate.html', {
        'siv': siv,
        'preview_lines': preview_lines,
        'page_title': f'Generate BRN — {siv.siv_number}',
    })


@login_required
@role_required('admin', 'warehouse', 'factory_manager', 'battery_controller')
def brn_detail(request, pk):
    brn = get_object_or_404(BatteryReleaseNote, pk=pk)
    lines = brn.lines.select_related('product', 'batch').all()
    return render(request, 'bettery/brn_detail.html', {
        'brn': brn, 'lines': lines,
        'page_title': brn.brn_number,
    })


@login_required
@role_required('admin', 'battery_controller')
def brn_submit(request, pk):
    """Battery Controller submits BRN — physically walking to WH Controller"""
    brn = get_object_or_404(BatteryReleaseNote, pk=pk)
    if request.method == 'POST':
        if brn.status not in ('generated', 'printed'):
            messages.error(request, 'BRN cannot be submitted at this stage.')
            return redirect('bettery:brn_detail', pk=pk)
        brn.status = 'submitted'
        brn.submitted_at = timezone.now()
        brn.save(update_fields=['status', 'submitted_at'])
        # Notify WH Controller
        try:
            from apps.messaging.views import send_system_message
            send_system_message(
                subject=f'BRN Submitted: {brn.brn_number}',
                body=f'Battery Controller has submitted {brn.brn_number} for {brn.siv.siv_number}. Please accept to complete SIV.',
                role='warehouse',
                is_urgent=True,
                ref_type='brn',
                ref_num=brn.brn_number,
            )
        except Exception:
            pass
        # Update SIV
        brn.siv.status = 'battery_picked'
        brn.siv.save(update_fields=['status'])
        messages.success(request, f'✓ {brn.brn_number} submitted. WH Controller notified.')
    return redirect('bettery:brn_detail', pk=pk)


@login_required
@role_required('admin', 'warehouse', 'factory_manager')
def brn_accept(request, pk):
    """WH Controller accepts BRN — deduction fires"""
    from apps.inventory.models import consume_stock, StockMovement, StockBatch
    brn = get_object_or_404(BatteryReleaseNote, pk=pk)
    if request.method == 'POST':
        if brn.status != 'submitted':
            messages.error(request, 'BRN must be in submitted status to accept.')
            return redirect('bettery:brn_detail', pk=pk)
        if brn.generated_by == request.user:
            messages.error(request, '⚠ WH Controller must be different from Battery Controller who generated.')
            return redirect('bettery:brn_detail', pk=pk)
        if brn.deduction_fired:
            messages.warning(request, 'Deduction already fired for this BRN.')
            return redirect('bettery:brn_detail', pk=pk)
        try:
            with transaction.atomic():
                # Lock BRN row to prevent concurrent acceptance
                brn = BatteryReleaseNote.objects.select_for_update().get(pk=pk)
                if brn.deduction_fired:
                    messages.warning(request, 'Deduction already fired (concurrent request blocked).')
                    return redirect('bettery:brn_detail', pk=pk)
                physical_confirmed = request.POST.get('physical_copy_confirmed') == 'on'
                # Fire FIFO deduction for each line
                for line in brn.lines.select_related('product', 'batch').all():
                    batch = line.batch
                    take = float(line.qty_issued)
                    batch.remaining_quantity = float(batch.remaining_quantity) - take
                    if float(batch.remaining_quantity) <= 0:
                        batch.status = 'depleted'
                        batch.remaining_quantity = 0
                    else:
                        batch.status = 'available'
                    batch.save(update_fields=['remaining_quantity', 'status'])
                    StockMovement.objects.create(
                        product=line.product,
                        batch=batch,
                        movement_type='mrn_issue',
                        quantity=take,
                        from_location=line.from_location_ref or 'Bettery Store',
                        to_location=f'Production — {brn.work_order.wo_number if brn.work_order else "WO"}',
                        performed_by=request.user,
                        reference=f'{brn.brn_number} / {brn.siv.siv_number}',
                        notes=f'BRN acceptance — WH Controller: {request.user.get_full_name()}'
                    )
                # Update BRN
                brn.accepted_by = request.user
                brn.accepted_at = timezone.now()
                brn.physical_copy_confirmed = physical_confirmed
                brn.status = 'accepted'
                brn.deduction_fired = True
                brn.save(update_fields=[
                    'accepted_by', 'accepted_at',
                    'physical_copy_confirmed', 'status', 'deduction_fired'
                ])
                # Complete SIV
                brn.siv.status = 'complete'
                brn.siv.battery_completed_at = timezone.now()
                brn.siv.save(update_fields=['status', 'battery_completed_at'])
                # AuditLog
                try:
                    from apps.accounts.models import AuditLog
                    AuditLog.log(
                        action_type='fm_financial_action',
                        performed_by=request.user,
                        request=request,
                        document_type='BRN',
                        document_ref=brn.brn_number,
                        document_id=brn.pk,
                        notes=f'BRN accepted — deduction fired for SIV {brn.siv.siv_number}',
                    )
                except Exception:
                    pass
                messages.success(
                    request,
                    f'✓ {brn.brn_number} accepted. Batteries deducted from inventory. SIV complete.'
                )
                return redirect('bettery:brn_detail', pk=pk)
        except Exception as e:
            logger.error(f'[brn_accept] {e}')
            messages.error(request, f'Error accepting BRN: {e}')
    return redirect('bettery:brn_detail', pk=pk)


@login_required
def brn_print(request, pk):
    """Print-ready BRN document"""
    from apps.master.models import SystemSettings
    brn = get_object_or_404(BatteryReleaseNote, pk=pk)
    lines = brn.lines.select_related('product', 'batch').all()
    # Mark as printed
    if brn.status == 'generated' and request.method == 'POST':
        brn.status = 'printed'
        brn.printed_at = timezone.now()
        brn.printed_by = request.user
        brn.save(update_fields=['status', 'printed_at', 'printed_by'])
    return render(request, 'bettery/brn_print.html', {
        'brn': brn, 'lines': lines,
        'sys': SystemSettings.get_settings(),
    })


@login_required
@role_required('admin', 'battery_controller')
def bcr_list(request):
    """Battery Condition Reports list"""
    bcrs = BatteryConditionReport.objects.select_related(
        'product', 'discovered_by'
    ).order_by('-created_at')
    status_filter = request.GET.get('status', '')
    if status_filter:
        bcrs = bcrs.filter(status=status_filter)
    return render(request, 'bettery/bcr_list.html', {
        'bcrs': bcrs, 'status_filter': status_filter,
        'status_choices': BatteryConditionReport.STATUS_CHOICES,
        'page_title': 'Battery Condition Reports',
    })


@login_required
@role_required('admin', 'battery_controller')
def bcr_create(request):
    """Battery Controller raises a BCR"""
    from apps.inventory.models import Product, StockBatch
    battery_products = Product.objects.filter(
        is_active=True, item_type='battery'
    ).order_by('name')
    if request.method == 'POST':
        try:
            product = Product.objects.get(pk=request.POST['product'])
            batch = StockBatch.objects.get(pk=request.POST['batch'])
            condition_type = request.POST['condition_type']
            safety_risk = request.POST.get('safety_risk', 'medium')
            qty = float(request.POST['quantity_affected'])
            description = request.POST.get('description', '').strip()

            bcr = BatteryConditionReport.objects.create(
                product=product,
                batch=batch,
                quantity_affected=qty,
                condition_type=condition_type,
                safety_risk=safety_risk,
                description=description,
                location_found=request.POST.get('location_found', '').strip(),
                discovered_by=request.user,
                status='reported',
            )
            # Move batch to quarantine
            batch.status = 'quarantine'
            batch.save(update_fields=['status'])

            # Alert FM — immediate for swollen/critical
            is_critical = condition_type == 'swollen' or safety_risk == 'critical'
            try:
                from apps.messaging.views import send_system_message
                from apps.core.sms import alert_factory_manager
                msg = f'{"⚠ CRITICAL: " if is_critical else ""}BCR {bcr.bcr_number} raised — {product.name} — {bcr.get_condition_type_display()}. {qty} units isolated.'
                send_system_message(
                    subject=f'BCR Raised: {bcr.bcr_number}',
                    body=msg,
                    role='factory_manager',
                    is_urgent=is_critical,
                )
                send_system_message(
                    subject=f'BCR Raised: {bcr.bcr_number}',
                    body=msg,
                    role='warehouse',
                    is_urgent=is_critical,
                )
                if is_critical:
                    alert_factory_manager(msg, subject=f'🔴 CRITICAL BCR: {bcr.bcr_number}')
            except Exception:
                pass

            # Add to FM approval queue
            try:
                from apps.core.models import FMApprovalQueue
                FMApprovalQueue.objects.create(
                    document_type='bcr',
                    document_ref=bcr.bcr_number,
                    document_id=bcr.pk,
                    raised_by=request.user,
                    urgency='critical' if is_critical else 'urgent',
                    description=f'BCR raised for {product.name} — {bcr.get_condition_type_display()}. Qty: {qty}. Please review and decide.',
                )
            except Exception:
                pass

            messages.success(request, f'✓ {bcr.bcr_number} created. FM and WH Controller notified.')
            return redirect('bettery:bcr_detail', pk=bcr.pk)
        except Exception as e:
            logger.error(f'[bcr_create] {e}')
            messages.error(request, f'Error: {e}')

    return render(request, 'bettery/bcr_create.html', {
        'battery_products': battery_products,
        'condition_choices': BatteryConditionReport.CONDITION_CHOICES,
        'safety_choices': BatteryConditionReport.SAFETY_RISK_CHOICES,
        'page_title': 'Raise Battery Condition Report',
    })


@login_required
@role_required('admin', 'warehouse', 'factory_manager', 'battery_controller')
def bcr_detail(request, pk):
    bcr = get_object_or_404(BatteryConditionReport, pk=pk)
    return render(request, 'bettery/bcr_detail.html', {
        'bcr': bcr, 'page_title': bcr.bcr_number,
    })


@login_required
@role_required('admin', 'warehouse')
def bcr_wh_inspect(request, pk):
    """WH Controller physically inspects isolated batteries"""
    bcr = get_object_or_404(BatteryConditionReport, pk=pk)
    if request.method == 'POST':
        if bcr.status != 'isolated':
            messages.error(request, 'BCR must be isolated before WH inspection.')
            return redirect('bettery:bcr_detail', pk=pk)
        bcr.wh_inspected_by = request.user
        bcr.wh_inspected_at = timezone.now()
        bcr.wh_inspection_notes = request.POST.get('notes', '').strip()
        bcr.status = 'wh_inspected'
        bcr.save(update_fields=['wh_inspected_by', 'wh_inspected_at', 'wh_inspection_notes', 'status'])
        # Notify FM
        try:
            from apps.messaging.views import send_system_message
            send_system_message(
                subject=f'BCR Ready for Decision: {bcr.bcr_number}',
                body=f'WH Controller has inspected {bcr.bcr_number}. Please make a decision.',
                role='factory_manager',
                is_urgent=True,
            )
        except Exception:
            pass
        messages.success(request, f'✓ WH inspection confirmed for {bcr.bcr_number}. FM notified.')
    return redirect('bettery:bcr_detail', pk=pk)


@login_required
@role_required('admin', 'factory_manager')
def bcr_fm_decide(request, pk):
    """FM makes disposal decision on BCR"""
    bcr = get_object_or_404(BatteryConditionReport, pk=pk)
    if request.method == 'POST':
        if bcr.status != 'wh_inspected':
            messages.error(request, 'BCR must be WH inspected before FM decision.')
            return redirect('bettery:bcr_detail', pk=pk)
        decision = request.POST.get('fm_decision')
        notes = request.POST.get('notes', '').strip()
        write_off = float(request.POST.get('write_off_value', 0) or 0)
        bcr.fm_decision = decision
        bcr.fm_decision_notes = notes
        bcr.fm_decision_by = request.user
        bcr.fm_decision_at = timezone.now()
        bcr.write_off_value = write_off
        bcr.status = 'fm_decided'
        bcr.save(update_fields=[
            'fm_decision', 'fm_decision_notes', 'fm_decision_by',
            'fm_decision_at', 'write_off_value', 'status'
        ])
        # Notify WH Controller
        try:
            from apps.messaging.views import send_system_message
            send_system_message(
                subject=f'BCR Decision Made: {bcr.bcr_number}',
                body=f'FM decision for {bcr.bcr_number}: {bcr.get_fm_decision_display()}. Please confirm removal authority.',
                role='warehouse',
                is_urgent=True,
            )
        except Exception:
            pass
        # AuditLog
        try:
            from apps.accounts.models import AuditLog
            AuditLog.log(
                action_type='bcr_decided',
                performed_by=request.user,
                request=request,
                document_type='BCR',
                document_ref=bcr.bcr_number,
                document_id=bcr.pk,
                new_value=decision,
                notes=f'Write-off value: Kshs {write_off}',
            )
        except Exception:
            pass
        messages.success(request, f'✓ Decision recorded for {bcr.bcr_number}. WH Controller notified.')
    return redirect('bettery:bcr_detail', pk=pk)


@login_required
@role_required('admin', 'warehouse')
def bcr_wh_confirm(request, pk):
    """WH Controller confirms removal authority"""
    bcr = get_object_or_404(BatteryConditionReport, pk=pk)
    if request.method == 'POST':
        if bcr.status != 'fm_decided':
            messages.error(request, 'BCR must have FM decision before WH confirmation.')
            return redirect('bettery:bcr_detail', pk=pk)
        bcr.wh_confirmed_by = request.user
        bcr.wh_confirmed_at = timezone.now()
        bcr.wh_confirmation_notes = request.POST.get('notes', '').strip()
        bcr.status = 'wh_confirmed'
        bcr.save(update_fields=['wh_confirmed_by', 'wh_confirmed_at', 'wh_confirmation_notes', 'status'])
        # Notify Battery Controller
        try:
            from apps.messaging.views import send_system_message
            send_system_message(
                subject=f'BCR Removal Authorised: {bcr.bcr_number}',
                body=f'WH Controller has authorised removal for {bcr.bcr_number}. Please physically remove the batteries.',
                role='battery_controller',
                is_urgent=True,
            )
        except Exception:
            pass
        bcr.status = 'removal_pending'
        bcr.save(update_fields=['status'])
        messages.success(request, f'✓ Removal authority confirmed. Battery Controller notified to remove.')
    return redirect('bettery:bcr_detail', pk=pk)


@login_required
@role_required('admin', 'battery_controller')
def bcr_removed(request, pk):
    """Battery Controller confirms physical removal — deduction fires"""
    from apps.inventory.models import StockBatch, StockMovement
    bcr = get_object_or_404(BatteryConditionReport, pk=pk)
    if request.method == 'POST':
        if bcr.status != 'removal_pending':
            messages.error(request, 'BCR must be in removal_pending status.')
            return redirect('bettery:bcr_detail', pk=pk)
        if not bcr.wh_confirmed_by:
            messages.error(request, 'WH Controller must confirm before removal.')
            return redirect('bettery:bcr_detail', pk=pk)
        if bcr.deduction_fired:
            messages.warning(request, 'Deduction already fired.')
            return redirect('bettery:bcr_detail', pk=pk)
        try:
            with transaction.atomic():
                # Fire deduction
                batch = bcr.batch
                qty = float(bcr.quantity_affected)
                batch.remaining_quantity = max(0, float(batch.remaining_quantity) - qty)
                if float(batch.remaining_quantity) <= 0:
                    batch.status = 'scrapped'
                batch.save(update_fields=['remaining_quantity', 'status'])
                movement = StockMovement.objects.create(
                    product=bcr.product,
                    batch=batch,
                    movement_type='SCRAP',
                    quantity=qty,
                    from_location='Bettery Store — Defective Zone',
                    to_location=f'Disposal — {bcr.get_fm_decision_display()}',
                    performed_by=request.user,
                    reference=bcr.bcr_number,
                    notes=f'BCR removal confirmed. FM: {bcr.fm_decision}. Write-off: Kshs {bcr.write_off_value}',
                )
                bcr.removed_by = request.user
                bcr.removed_at = timezone.now()
                bcr.removal_notes = request.POST.get('notes', '').strip()
                bcr.disposal_method = request.POST.get('disposal_method', '')
                bcr.disposal_reference = request.POST.get('disposal_reference', '').strip()
                bcr.stock_movement = movement
                bcr.deduction_fired = True
                bcr.status = 'disposed'
                bcr.save()
                # GL: DR Write-off / CR Inventory
                try:
                    from apps.gl.models import post_bcr_writeoff
                    post_bcr_writeoff(
                        product=bcr.product,
                        qty=qty,
                        unit_cost=float(bcr.product.unit_cost),
                        bcr_number=bcr.bcr_number,
                        user=request.user,
                    )
                except Exception as e:
                    logger.warning(f'[GL] BCR write-off post: {e}')
                # AuditLog
                try:
                    from apps.accounts.models import AuditLog
                    AuditLog.log(
                        action_type='scrap_approved',
                        performed_by=request.user,
                        request=request,
                        document_type='BCR',
                        document_ref=bcr.bcr_number,
                        document_id=bcr.pk,
                        notes=f'Physical removal confirmed. Deduction fired. Qty: {qty}',
                    )
                except Exception:
                    pass
                messages.success(
                    request,
                    f'✓ {bcr.bcr_number} complete. {qty} units removed. Inventory updated.'
                )
        except Exception as e:
            logger.error(f'[bcr_removed] {e}')
            messages.error(request, f'Error: {e}')
    return redirect('bettery:bcr_detail', pk=pk)
