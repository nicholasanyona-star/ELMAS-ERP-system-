from django.apps import AppConfig


class BetteryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.bettery'
    verbose_name = 'Bettery — Battery Store'
