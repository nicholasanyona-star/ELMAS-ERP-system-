from django.urls import path
from . import views

app_name = 'bettery'

urlpatterns = [
    path('',                          views.bettery_dashboard, name='dashboard'),
    path('brn/<int:siv_pk>/generate/',views.brn_generate,     name='brn_generate'),
    path('brn/<int:pk>/',             views.brn_detail,        name='brn_detail'),
    path('brn/<int:pk>/submit/',      views.brn_submit,        name='brn_submit'),
    path('brn/<int:pk>/accept/',      views.brn_accept,        name='brn_accept'),
    path('brn/<int:pk>/print/',       views.brn_print,         name='brn_print'),
    path('bcr/',                      views.bcr_list,          name='bcr_list'),
    path('bcr/create/',               views.bcr_create,        name='bcr_create'),
    path('bcr/<int:pk>/',             views.bcr_detail,        name='bcr_detail'),
    path('bcr/<int:pk>/wh-inspect/',  views.bcr_wh_inspect,   name='bcr_wh_inspect'),
    path('bcr/<int:pk>/fm-decide/',   views.bcr_fm_decide,     name='bcr_fm_decide'),
    path('bcr/<int:pk>/wh-confirm/',  views.bcr_wh_confirm,    name='bcr_wh_confirm'),
    path('bcr/<int:pk>/removed/',     views.bcr_removed,       name='bcr_removed'),
]
