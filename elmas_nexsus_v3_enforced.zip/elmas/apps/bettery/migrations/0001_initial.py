"""
ELMAS Bettery Migration 0001
Initial migration — BatteryReleaseNote, BRNLine, BatteryConditionReport
"""
from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone
from django.conf import settings


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ('inventory', '0004_product_aql_level'),
        ('pmc', '0006_siv_battery_fmqueue'),
        ('master', '0002_new_types_settings_lines'),
        ('accounts', '0004_user_assigned_line'),
        ('core', '0002_fmapprovalqueue'),
    ]

    operations = [
        migrations.CreateModel(
            name='BatteryReleaseNote',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True)),
                ('brn_number', models.CharField(db_index=True, max_length=50, unique=True)),
                ('status', models.CharField(
                    choices=[
                        ('generated', 'Generated — awaiting print'),
                        ('printed', 'Printed — Battery Controller walking to WH'),
                        ('submitted', 'Submitted — awaiting WH Controller acceptance'),
                        ('accepted', 'Accepted — deduction fired'),
                        ('cancelled', 'Cancelled — voided'),
                    ],
                    db_index=True, default='generated', max_length=15,
                )),
                ('generated_at', models.DateTimeField(auto_now_add=True)),
                ('printed_at', models.DateTimeField(blank=True, null=True)),
                ('submitted_at', models.DateTimeField(blank=True, null=True)),
                ('accepted_at', models.DateTimeField(blank=True, null=True)),
                ('physical_copy_confirmed', models.BooleanField(default=False)),
                ('cancelled_at', models.DateTimeField(blank=True, null=True)),
                ('cancellation_reason', models.TextField(blank=True)),
                ('deduction_fired', models.BooleanField(default=False)),
                ('notes', models.TextField(blank=True)),
                ('siv', models.OneToOneField(
                    on_delete=django.db.models.deletion.PROTECT,
                    related_name='brn', to='pmc.siv',
                )),
                ('work_order', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='brns', to='pmc.workorder',
                )),
                ('generated_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='brns_generated',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('printed_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='brns_printed',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('accepted_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='brns_accepted',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('cancelled_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='brns_cancelled',
                    to=settings.AUTH_USER_MODEL,
                )),
            ],
            options={'ordering': ['-generated_at'],
                     'verbose_name': 'Battery Release Note',
                     'verbose_name_plural': 'Battery Release Notes'},
        ),
        migrations.CreateModel(
            name='BRNLine',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True)),
                ('qty_issued', models.DecimalField(decimal_places=2, max_digits=12)),
                ('uom', models.CharField(default='EA', max_length=20)),
                ('batch_number_ref', models.CharField(blank=True, max_length=50)),
                ('expiry_date_ref', models.DateField(blank=True, null=True)),
                ('from_location_ref', models.CharField(blank=True, max_length=200)),
                ('brn', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='lines', to='bettery.batteryreleasenote',
                )),
                ('product', models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    to='inventory.product',
                )),
                ('batch', models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    to='inventory.stockbatch',
                )),
            ],
            options={'ordering': ['id']},
        ),
        migrations.CreateModel(
            name='BatteryConditionReport',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True)),
                ('bcr_number', models.CharField(db_index=True, max_length=50, unique=True)),
                ('quantity_affected', models.DecimalField(decimal_places=2, max_digits=12)),
                ('condition_type', models.CharField(
                    choices=[
                        ('damaged', 'Damaged — physical damage'),
                        ('swollen', 'Swollen — safety hazard ⚠'),
                        ('broken', 'Broken — non-functional'),
                        ('aging', 'Aging — approaching expiry'),
                        ('under_test', 'Under Test — being evaluated'),
                    ],
                    max_length=15,
                )),
                ('safety_risk', models.CharField(
                    choices=[
                        ('low', 'Low'), ('medium', 'Medium'),
                        ('high', 'High'),
                        ('critical', 'Critical — immediate action required'),
                    ],
                    default='medium', max_length=10,
                )),
                ('status', models.CharField(
                    choices=[
                        ('reported', 'Reported'),
                        ('isolated', 'Isolated — Battery Controller confirmed'),
                        ('wh_inspected', 'WH Inspected — WH Controller verified'),
                        ('fm_decided', 'FM Decision Made'),
                        ('wh_confirmed', 'WH Confirmed removal authority'),
                        ('removal_pending', 'Pending Physical Removal'),
                        ('removed', 'Physically Removed'),
                        ('disposed', 'Disposed — record complete'),
                    ],
                    db_index=True, default='reported', max_length=20,
                )),
                ('description', models.TextField()),
                ('photo_evidence', models.ImageField(blank=True, null=True, upload_to='bcr_photos/')),
                ('discovery_date', models.DateField(default=django.utils.timezone.now)),
                ('location_found', models.CharField(blank=True, max_length=200)),
                ('fm_decision', models.CharField(
                    choices=[
                        ('scrap', 'Scrap — dispose of'),
                        ('return_supplier', 'Return to Supplier'),
                        ('retest', 'Retest — back to under_test'),
                        ('accept_discounted', 'Accept with Discount'),
                        ('pending', 'Pending'),
                    ],
                    default='pending', max_length=20,
                )),
                ('fm_decision_notes', models.TextField(blank=True)),
                ('write_off_value', models.DecimalField(decimal_places=2, default=0, max_digits=12)),
                ('wh_confirmation_notes', models.TextField(blank=True)),
                ('wh_inspection_notes', models.TextField(blank=True)),
                ('removal_notes', models.TextField(blank=True)),
                ('deduction_fired', models.BooleanField(default=False)),
                ('disposal_method', models.CharField(
                    blank=True,
                    choices=[
                        ('recycling', 'Certified Recycler'),
                        ('destruction', 'Physical Destruction'),
                        ('return_supplier', 'Return to Supplier'),
                    ],
                    max_length=20,
                )),
                ('disposal_reference', models.CharField(blank=True, max_length=100)),
                ('sms_sent_swollen', models.BooleanField(default=False)),
                ('fm_notified_at', models.DateTimeField(blank=True, null=True)),
                ('isolation_confirmed_at', models.DateTimeField(blank=True, null=True)),
                ('wh_inspected_at', models.DateTimeField(blank=True, null=True)),
                ('fm_decision_at', models.DateTimeField(blank=True, null=True)),
                ('wh_confirmed_at', models.DateTimeField(blank=True, null=True)),
                ('removed_at', models.DateTimeField(blank=True, null=True)),
                ('disposal_completed_at', models.DateTimeField(blank=True, null=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('notes', models.TextField(blank=True)),
                ('product', models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    related_name='bcrs', to='inventory.product',
                )),
                ('batch', models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    related_name='bcrs', to='inventory.stockbatch',
                )),
                ('discovered_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='bcrs_discovered',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('isolation_confirmed_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='bcrs_isolated',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('isolation_location', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='bcr_isolation_bins',
                    to='master.bin',
                )),
                ('wh_inspected_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='bcrs_wh_inspected',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('fm_decision_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='bcrs_fm_decided',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('wh_confirmed_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='bcrs_wh_confirmed',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('removed_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='bcrs_removed',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('stock_movement', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='bcr_deductions',
                    to='inventory.stockmovement',
                )),
                ('disposal_completed_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='bcrs_disposed',
                    to=settings.AUTH_USER_MODEL,
                )),
            ],
            options={'ordering': ['-created_at'],
                     'verbose_name': 'Battery Condition Report',
                     'verbose_name_plural': 'Battery Condition Reports'},
        ),
    ]
