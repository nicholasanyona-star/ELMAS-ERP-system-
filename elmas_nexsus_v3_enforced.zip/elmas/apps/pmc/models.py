"""
ELMAS PMC Models
Production Plan, Work Orders, BOM, MRN
"""
from django.db import models
from django.conf import settings
from django.utils import timezone


class ProductionPlan(models.Model):
    STATUS_CHOICES = (
        ('draft', 'Draft'),
        ('approved', 'Approved'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    )
    plan_number = models.CharField(max_length=50, unique=True, db_index=True)
    title = models.CharField(max_length=200)
    plan_date = models.DateField()
    target_qty = models.IntegerField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')
    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name='plans_created')
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='plans_approved')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-plan_date']

    def __str__(self):
        return f"{self.plan_number} — {self.title}"

    def save(self, *args, **kwargs):
        if not self.plan_number:
            today = timezone.now().strftime('%Y%m%d')
            count = ProductionPlan.objects.filter(plan_number__startswith=f'PP-{today}').count() + 1
            self.plan_number = f"PP-{today}-{str(count).zfill(3)}"
        super().save(*args, **kwargs)


class BOM(models.Model):
    """Bill of Materials — Assembly or Packing"""
    BOM_TYPE_CHOICES = (
        ('assembly', 'Assembly BOM'),
        ('packing', 'Packing BOM'),
    )
    STATUS_CHOICES = (
        ('draft', 'Draft'),
        ('approved', 'Approved'),
        ('superseded', 'Superseded'),
    )
    bom_number = models.CharField(max_length=50, unique=True, db_index=True)
    phone_model = models.CharField(max_length=100, db_index=True)
    bom_type = models.CharField(max_length=10, choices=BOM_TYPE_CHOICES)
    version = models.CharField(max_length=10, default='v1')
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='draft')
    effective_date = models.DateField(default=timezone.now)
    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name='boms_created')
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='boms_approved')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['phone_model', 'bom_type', 'version']
        unique_together = ['phone_model', 'bom_type', 'version']

    def __str__(self):
        return f"{self.bom_number} — {self.phone_model} {self.get_bom_type_display()} {self.version}"

    def clean(self):
        from django.core.exceptions import ValidationError
        if self.status == 'approved' and not self.lines.exists():
            raise ValidationError('Cannot approve an empty BOM. Add components first.')
        if self.phone_model and len(self.phone_model.strip()) < 2:
            raise ValidationError({'phone_model': 'Phone model name must be at least 2 characters.'})

    def save(self, *args, **kwargs):
        if not self.bom_number:
            prefix = 'ASM' if self.bom_type == 'assembly' else 'PKG'
            count = BOM.objects.filter(bom_number__startswith=f'BOM-{prefix}').count() + 1
            self.bom_number = f"BOM-{prefix}-{str(count).zfill(4)}"
        super().save(*args, **kwargs)

    def total_lines(self):
        return self.lines.count()


class BOMLine(models.Model):
    bom = models.ForeignKey(BOM, on_delete=models.CASCADE, related_name='lines')
    component = models.ForeignKey('inventory.Product', on_delete=models.PROTECT, related_name='bom_lines')
    quantity_per_unit = models.DecimalField(max_digits=12, decimal_places=4)
    uom = models.CharField(max_length=20, default='EA')
    scrap_allowance = models.DecimalField(max_digits=5, decimal_places=2, default=0, help_text='Scrap % e.g. 2.5')
    sequence = models.IntegerField(default=10)
    notes = models.CharField(max_length=255, blank=True)

    class Meta:
        ordering = ['sequence']

    def __str__(self):
        return f"{self.component.name} × {self.quantity_per_unit}"

    @property
    def effective_qty(self):
        """Quantity per unit including scrap allowance"""
        return self.quantity_per_unit * (1 + self.scrap_allowance / 100)

    def required_for(self, production_qty):
        """Total quantity required for a given production run"""
        return self.effective_qty * production_qty


class WorkOrder(models.Model):
    WO_TYPE_CHOICES = (
        ('assembly', 'Assembly'),
        ('packing', 'Packing'),
    )
    STATUS_CHOICES = (
        ('draft',        'Draft'),
        ('released',     'Released'),
        ('in_progress',  'In Progress'),
        ('quality_hold', 'Quality Hold — FM Investigation'),
        ('completed',    'Completed'),
        ('cancelled',    'Cancelled'),
    )
    wo_number = models.CharField(max_length=50, unique=True, db_index=True)
    production_plan = models.ForeignKey(ProductionPlan, on_delete=models.SET_NULL, null=True, blank=True, related_name='work_orders')
    bom = models.ForeignKey(BOM, on_delete=models.PROTECT, related_name='work_orders')
    wo_type = models.CharField(max_length=10, choices=WO_TYPE_CHOICES)
    planned_qty = models.IntegerField()
    completed_qty = models.IntegerField(default=0)
    planned_date = models.DateField()
    # Line assignment — set when WO is released
    assembly_line = models.ForeignKey(
        'master.ProductionLine', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='assembly_work_orders',
        help_text='Assembly line assigned for this WO'
    )
    packaging_line = models.ForeignKey(
        'master.ProductionLine', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='packaging_work_orders',
        help_text='Packaging line assigned for this WO'
    )
    # Quality hold
    quality_hold = models.BooleanField(default=False)
    quality_hold_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='wos_quality_held'
    )
    quality_hold_at = models.DateTimeField(null=True, blank=True)
    quality_hold_notes = models.TextField(blank=True)
    total_labour_cost = models.DecimalField(
        max_digits=12, decimal_places=2, default=0,
        help_text='Cumulative labour cost posted from shift records (GL auto-updated)'
    )
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='draft')
    notes = models.TextField(blank=True)
    cancellation_reason = models.TextField(blank=True)
    cancelled_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='wos_cancelled')
    cancelled_at = models.DateTimeField(null=True, blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name='wo_created')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.wo_number} — {self.bom.phone_model} × {self.planned_qty}"

    def clean(self):
        from django.core.exceptions import ValidationError
        if self.planned_qty is not None and self.planned_qty <= 0:
            raise ValidationError({'planned_qty': 'Planned quantity must be greater than zero.'})
        if self.completed_qty is not None and self.planned_qty and self.completed_qty > self.planned_qty * 1.1:
            raise ValidationError({'completed_qty': 'Completed qty cannot exceed planned qty by more than 10%.'})
        if self.bom_id and self.bom.status != 'approved':
            raise ValidationError('Cannot create Work Order on an unapproved BOM.')

    def save(self, *args, **kwargs):
        if not self.wo_number:
            today = timezone.now().strftime('%Y%m%d')
            prefix = 'ASM' if self.wo_type == 'assembly' else 'PKG'
            count = WorkOrder.objects.filter(wo_number__startswith=f'WO-{prefix}-{today}').count() + 1
            self.wo_number = f"WO-{prefix}-{today}-{str(count).zfill(3)}"
        super().save(*args, **kwargs)

    @property
    def completion_pct(self):
        if self.planned_qty > 0:
            return round((self.completed_qty / self.planned_qty) * 100)
        return 0

    def calculate_materials(self):
        """Returns list of {component, required_qty, current_stock, unit_cost, line_cost} from BOM × planned_qty"""
        result = []
        for line in self.bom.lines.select_related('component').all():
            required_qty = float(line.required_for(self.planned_qty))
            try:
                current_stock = float(line.component.current_stock)
            except Exception:
                current_stock = 0
            unit_cost = float(line.component.unit_cost)
            result.append({
                'component':    line.component,
                'bom_line':     line,
                'required_qty': required_qty,
                'current_stock': current_stock,
                'sufficient':   current_stock >= required_qty,
                'shortfall':    max(0, required_qty - current_stock),
                'uom':          line.uom,
                'unit_cost':    unit_cost,
                'line_cost':    required_qty * unit_cost,
            })
        return result


class MRN(models.Model):
    """Material Request Note"""
    STATUS_CHOICES = (
        ('draft', 'Draft'),
        ('submitted', 'Submitted'),
        ('approved', 'Approved — Issued'),
        ('partial', 'Partially Issued'),
        ('rejected', 'Rejected'),
    )
    mrn_number = models.CharField(max_length=50, unique=True, db_index=True)
    work_order = models.ForeignKey(WorkOrder, on_delete=models.CASCADE, related_name='mrns')
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='draft')
    notes = models.TextField(blank=True)
    requested_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name='mrns_requested')
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='mrns_approved')
    approved_at = models.DateTimeField(null=True, blank=True)
    submitted_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.mrn_number} — {self.work_order.wo_number}"

    def save(self, *args, **kwargs):
        if not self.mrn_number:
            today = timezone.now().strftime('%Y%m%d')
            count = MRN.objects.filter(mrn_number__startswith=f'MRN-{today}').count() + 1
            self.mrn_number = f"MRN-{today}-{str(count).zfill(3)}"
        super().save(*args, **kwargs)


class MRNLine(models.Model):
    mrn = models.ForeignKey(MRN, on_delete=models.CASCADE, related_name='lines')
    product = models.ForeignKey('inventory.Product', on_delete=models.PROTECT)
    qty_requested = models.DecimalField(max_digits=12, decimal_places=2)
    qty_issued = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    uom = models.CharField(max_length=20, default='EA')
    # BOM intelligence fields
    bom_calculated_qty = models.DecimalField(
        max_digits=12, decimal_places=2, default=0,
        help_text='System-calculated qty from BOM × WO planned_qty'
    )
    available_at_request = models.DecimalField(
        max_digits=12, decimal_places=2, default=0,
        help_text='Stock available when MRN was generated'
    )
    has_shortfall = models.BooleanField(default=False)
    shortfall_qty = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    # Deviation tracking (FM sees if PMC changed from BOM calc)
    deviation_reason = models.TextField(
        blank=True,
        help_text='Mandatory if qty_requested differs from bom_calculated_qty'
    )
    deviation_approved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='mrn_deviations_approved'
    )
    notes = models.CharField(max_length=255, blank=True)

    def clean(self):
        from django.core.exceptions import ValidationError
        if self.qty_requested is not None and self.qty_requested <= 0:
            raise ValidationError({'qty_requested': 'Requested quantity must be greater than zero.'})
        if (self.bom_calculated_qty and self.qty_requested and
                float(self.qty_requested) > float(self.bom_calculated_qty) * 1.2):
            if not self.deviation_reason:
                raise ValidationError({'deviation_reason': 'Reason required when requesting more than 120% of BOM-calculated quantity.'})

    def __str__(self):
        return self.qty_issued >= self.qty_requested

    @property
    def deviation(self):
        return float(self.qty_requested) - float(self.bom_calculated_qty)


class SIV(models.Model):
    """
    Store Issue Voucher
    Auto-generated when Warehouse Controller approves an MRN.
    If contains battery lines — splits into parallel tracks:
    WH picks non-battery immediately, Battery Controller handles battery via BRN.
    """
    STATUS_CHOICES = (
        ('generated',        'Generated'),
        ('wh_picking',       'WH Picking — non-battery items'),
        ('wh_pick_complete', 'WH Pick Complete — awaiting batteries'),
        ('battery_pending',  'Battery Pick Pending — BRN not yet generated'),
        ('battery_picked',   'Battery Picked — BRN submitted, awaiting WH accept'),
        ('complete',         'Complete — all items issued'),
    )

    siv_number = models.CharField(max_length=50, unique=True, db_index=True)
    mrn = models.OneToOneField(MRN, on_delete=models.CASCADE, related_name='siv')
    work_order = models.ForeignKey(
        WorkOrder, on_delete=models.SET_NULL, null=True, blank=True, related_name='sivs'
    )
    status = models.CharField(
        max_length=20, choices=STATUS_CHOICES, default='generated', db_index=True
    )
    # Battery line tracking
    has_battery_lines = models.BooleanField(
        default=False,
        help_text='Auto-set at generation if any SIVLine is battery type'
    )
    wh_pick_completed_at = models.DateTimeField(null=True, blank=True)
    battery_completed_at = models.DateTimeField(null=True, blank=True)
    # Signatures
    issued_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
        related_name='sivs_issued', help_text='Warehouse Controller'
    )
    received_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='sivs_received', help_text='Production Supervisor'
    )
    received_at = models.DateTimeField(null=True, blank=True)
    is_signed = models.BooleanField(default=False)
    notes = models.TextField(blank=True)
    issued_at = models.DateTimeField(default=timezone.now)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Store Issue Voucher'
        verbose_name_plural = 'Store Issue Vouchers'

    def __str__(self):
        return f"{self.siv_number} — {self.mrn.mrn_number}"

    def save(self, *args, **kwargs):
        if not self.siv_number:
            today = timezone.now().strftime('%Y%m%d')
            count = SIV.objects.filter(siv_number__startswith=f'SIV-{today}').count() + 1
            self.siv_number = f"SIV-{today}-{str(count).zfill(3)}"
        super().save(*args, **kwargs)


class SIVLine(models.Model):
    """Each material line on the SIV — what was issued, from which batch and location"""
    siv = models.ForeignKey(SIV, on_delete=models.CASCADE, related_name='lines')
    product = models.ForeignKey('inventory.Product', on_delete=models.PROTECT)
    batch_reference = models.CharField(max_length=100, blank=True)
    from_location = models.CharField(max_length=200, blank=True)
    qty_issued = models.DecimalField(max_digits=12, decimal_places=2)
    uom = models.CharField(max_length=20, default='EA')
    unit_cost = models.DecimalField(
        max_digits=12, decimal_places=2, default=0,
        help_text='Stored for audit — never displayed to non-FM roles'
    )
    is_battery_line = models.BooleanField(
        default=False,
        help_text='Auto-set if product.item_type == battery'
    )

    def __str__(self):
        return f"{self.product.name} × {self.qty_issued}"

    def save(self, *args, **kwargs):
        if self.product_id:
            self.is_battery_line = self.product.is_battery
        super().save(*args, **kwargs)

class MRetN(models.Model):
    """
    Material Return Note
    Reverse of an MRN — materials going FROM production BACK TO warehouse.

    Three scenarios:
    1. EXCESS     — unused materials after Work Order is complete
    2. DEFECTIVE  — faulty/wrong components detected during assembly or packing
    3. EXCHANGE   — wrong spec issued, need correct replacement
    """

    REASON_CHOICES = (
        ('excess',    'Excess — unused materials after production'),
        ('defective', 'Defective — faulty components found during assembly'),
        ('wrong_spec','Wrong Specification — wrong item issued'),
        ('damaged',   'Damaged in Transit/Handling'),
        ('exchange',  'Exchange — returning to get correct item'),
        ('other',     'Other'),
    )

    STATUS_CHOICES = (
        ('draft',     'Draft'),
        ('submitted', 'Submitted — awaiting WC acceptance'),
        ('accepted',  'Accepted — stock returned to warehouse'),
        ('rejected',  'Rejected — query raised'),
    )

    RETURN_TO_CHOICES = (
        ('available', 'Back to Available Stock'),
        ('quarantine','Hold in Quarantine — QC to inspect'),
        ('scrap',     'Scrap — write off'),
    )

    mretn_number = models.CharField(max_length=50, unique=True, db_index=True)
    work_order   = models.ForeignKey(
        WorkOrder, on_delete=models.CASCADE, related_name='mretns'
    )
    original_mrn = models.ForeignKey(
        MRN, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='returns',
        help_text='The MRN that originally issued these materials'
    )
    reason       = models.CharField(max_length=20, choices=REASON_CHOICES)
    reason_notes = models.TextField(
        help_text='Detailed explanation — what was found, where, and by whom'
    )
    return_to    = models.CharField(
        max_length=15, choices=RETURN_TO_CHOICES, default='available',
        help_text='Where returned stock goes in the warehouse'
    )
    status       = models.CharField(
        max_length=15, choices=STATUS_CHOICES, default='draft', db_index=True
    )

    # Two signatures
    initiated_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
        related_name='mretns_initiated'
    )
    accepted_by  = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='mretns_accepted'
    )
    accepted_at  = models.DateTimeField(null=True, blank=True)
    rejection_reason = models.TextField(blank=True)

    created_at   = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Material Return Note'

    def __str__(self):
        return f"{self.mretn_number} — {self.work_order.wo_number}"

    def save(self, *args, **kwargs):
        if not self.mretn_number:
            today = timezone.now().strftime('%Y%m%d')
            count = MRetN.objects.filter(
                mretn_number__startswith=f'MRetN-{today}'
            ).count() + 1
            self.mretn_number = f"MRetN-{today}-{str(count).zfill(3)}"
        super().save(*args, **kwargs)


class MRetNLine(models.Model):
    """Each product line being returned"""
    mretn          = models.ForeignKey(MRetN, on_delete=models.CASCADE, related_name='lines')
    product        = models.ForeignKey('inventory.Product', on_delete=models.PROTECT)
    qty_returned   = models.DecimalField(max_digits=12, decimal_places=2)
    uom            = models.CharField(max_length=20, default='EA')
    batch_reference= models.CharField(
        max_length=100, blank=True,
        help_text='Original batch number from the SIV (if known)'
    )
    condition      = models.CharField(
        max_length=20,
        choices=(
            ('good',     'Good — unused, undamaged'),
            ('defective','Defective — faulty, do not reuse'),
            ('damaged',  'Damaged — physically damaged'),
            ('wrong',    'Wrong Item — wrong specification'),
        ),
        default='good'
    )
    defect_description = models.TextField(
        blank=True,
        help_text='Describe the defect or damage found — mandatory if condition is not good'
    )

    def __str__(self):
        return f"{self.product.name} × {self.qty_returned} ({self.condition})"

