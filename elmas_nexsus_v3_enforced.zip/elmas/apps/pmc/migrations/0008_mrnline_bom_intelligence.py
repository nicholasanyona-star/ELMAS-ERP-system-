"""
ELMAS PMC Migration 0008
- Add bom_calculated_qty, available_at_request, has_shortfall,
  shortfall_qty, deviation_reason, deviation_approved_by to MRNLine
"""
from django.db import migrations, models
import django.db.models.deletion
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('pmc', '0007_workorder_lines_quality_hold'),
        ('accounts', '0004_user_assigned_line'),
    ]

    operations = [
        migrations.AddField(
            model_name='mrnline',
            name='bom_calculated_qty',
            field=models.DecimalField(decimal_places=2, default=0, max_digits=12),
        ),
        migrations.AddField(
            model_name='mrnline',
            name='available_at_request',
            field=models.DecimalField(decimal_places=2, default=0, max_digits=12),
        ),
        migrations.AddField(
            model_name='mrnline',
            name='has_shortfall',
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name='mrnline',
            name='shortfall_qty',
            field=models.DecimalField(decimal_places=2, default=0, max_digits=12),
        ),
        migrations.AddField(
            model_name='mrnline',
            name='deviation_reason',
            field=models.TextField(blank=True),
        ),
        migrations.AddField(
            model_name='mrnline',
            name='deviation_approved_by',
            field=models.ForeignKey(
                blank=True, null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='mrn_deviations_approved',
                to=settings.AUTH_USER_MODEL,
            ),
        ),
    ]
