from django.db import migrations, models
import django.db.models.deletion
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('pmc', '0004_workorder_cancelled_at'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='MRetN',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True)),
                ('mretn_number', models.CharField(db_index=True, max_length=50, unique=True)),
                ('reason', models.CharField(choices=[
                    ('excess', 'Excess — unused materials after production'),
                    ('defective', 'Defective — faulty components found during assembly'),
                    ('wrong_spec', 'Wrong Specification — wrong item issued'),
                    ('damaged', 'Damaged in Transit/Handling'),
                    ('exchange', 'Exchange — returning to get correct item'),
                    ('other', 'Other'),
                ], max_length=20)),
                ('reason_notes', models.TextField()),
                ('return_to', models.CharField(choices=[
                    ('available', 'Back to Available Stock'),
                    ('quarantine', 'Hold in Quarantine — QC to inspect'),
                    ('scrap', 'Scrap — write off'),
                ], default='available', max_length=15)),
                ('status', models.CharField(choices=[
                    ('draft', 'Draft'),
                    ('submitted', 'Submitted — awaiting WC acceptance'),
                    ('accepted', 'Accepted — stock returned to warehouse'),
                    ('rejected', 'Rejected — query raised'),
                ], db_index=True, default='draft', max_length=15)),
                ('rejection_reason', models.TextField(blank=True)),
                ('accepted_at', models.DateTimeField(blank=True, null=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('work_order', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,
                    related_name='mretns', to='pmc.workorder')),
                ('original_mrn', models.ForeignKey(blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='returns', to='pmc.mrn')),
                ('initiated_by', models.ForeignKey(null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='mretns_initiated', to=settings.AUTH_USER_MODEL)),
                ('accepted_by', models.ForeignKey(blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='mretns_accepted', to=settings.AUTH_USER_MODEL)),
            ],
            options={'ordering': ['-created_at'], 'verbose_name': 'Material Return Note'},
        ),
        migrations.CreateModel(
            name='MRetNLine',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True)),
                ('qty_returned', models.DecimalField(decimal_places=2, max_digits=12)),
                ('uom', models.CharField(default='EA', max_length=20)),
                ('batch_reference', models.CharField(blank=True, max_length=100)),
                ('condition', models.CharField(choices=[
                    ('good', 'Good — unused, undamaged'),
                    ('defective', 'Defective — faulty, do not reuse'),
                    ('damaged', 'Damaged — physically damaged'),
                    ('wrong', 'Wrong Item — wrong specification'),
                ], default='good', max_length=20)),
                ('defect_description', models.TextField(blank=True)),
                ('mretn', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,
                    related_name='lines', to='pmc.mretn')),
                ('product', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT,
                    to='inventory.product')),
            ],
        ),
    ]
