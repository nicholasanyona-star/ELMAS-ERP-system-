from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone
from django.conf import settings


class Migration(migrations.Migration):
    initial = True
    dependencies = [
        ('inventory', '0001_initial'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]
    operations = [
        migrations.CreateModel('ProductionPlan', fields=[
            ('id', models.BigAutoField(auto_created=True, primary_key=True)),
            ('plan_number', models.CharField(db_index=True, max_length=50, unique=True)),
            ('title', models.CharField(max_length=200)),
            ('plan_date', models.DateField()),
            ('target_qty', models.IntegerField()),
            ('status', models.CharField(choices=[('draft','Draft'),('approved','Approved'),('in_progress','In Progress'),('completed','Completed'),('cancelled','Cancelled')], default='draft', max_length=20)),
            ('notes', models.TextField(blank=True)),
            ('created_at', models.DateTimeField(auto_now_add=True)),
            ('approved_by', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='plans_approved', to=settings.AUTH_USER_MODEL)),
            ('created_by', models.ForeignKey(null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='plans_created', to=settings.AUTH_USER_MODEL)),
        ], options={'ordering': ['-plan_date']}),
        migrations.CreateModel('BOM', fields=[
            ('id', models.BigAutoField(auto_created=True, primary_key=True)),
            ('bom_number', models.CharField(db_index=True, max_length=50, unique=True)),
            ('phone_model', models.CharField(db_index=True, max_length=100)),
            ('bom_type', models.CharField(choices=[('assembly','Assembly BOM'),('packing','Packing BOM')], max_length=10)),
            ('version', models.CharField(default='v1', max_length=10)),
            ('status', models.CharField(choices=[('draft','Draft'),('approved','Approved'),('superseded','Superseded')], default='draft', max_length=15)),
            ('effective_date', models.DateField(default=django.utils.timezone.now)),
            ('notes', models.TextField(blank=True)),
            ('created_at', models.DateTimeField(auto_now_add=True)),
            ('approved_by', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='boms_approved', to=settings.AUTH_USER_MODEL)),
            ('created_by', models.ForeignKey(null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='boms_created', to=settings.AUTH_USER_MODEL)),
        ], options={'ordering': ['phone_model', 'bom_type', 'version'], 'unique_together': {('phone_model', 'bom_type', 'version')}}),
        migrations.CreateModel('BOMLine', fields=[
            ('id', models.BigAutoField(auto_created=True, primary_key=True)),
            ('quantity_per_unit', models.DecimalField(decimal_places=4, max_digits=12)),
            ('uom', models.CharField(default='EA', max_length=20)),
            ('scrap_allowance', models.DecimalField(decimal_places=2, default=0, max_digits=5)),
            ('sequence', models.IntegerField(default=10)),
            ('notes', models.CharField(blank=True, max_length=255)),
            ('bom', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='lines', to='pmc.bom')),
            ('component', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='bom_lines', to='inventory.product')),
        ], options={'ordering': ['sequence']}),
        migrations.CreateModel('WorkOrder', fields=[
            ('id', models.BigAutoField(auto_created=True, primary_key=True)),
            ('wo_number', models.CharField(db_index=True, max_length=50, unique=True)),
            ('wo_type', models.CharField(choices=[('assembly','Assembly'),('packing','Packing')], max_length=10)),
            ('planned_qty', models.IntegerField()),
            ('completed_qty', models.IntegerField(default=0)),
            ('planned_date', models.DateField()),
            ('status', models.CharField(choices=[('draft','Draft'),('released','Released'),('in_progress','In Progress'),('completed','Completed'),('cancelled','Cancelled')], default='draft', max_length=15)),
            ('notes', models.TextField(blank=True)),
            ('created_at', models.DateTimeField(auto_now_add=True)),
            ('bom', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='work_orders', to='pmc.bom')),
            ('created_by', models.ForeignKey(null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='wo_created', to=settings.AUTH_USER_MODEL)),
            ('production_plan', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='work_orders', to='pmc.productionplan')),
        ], options={'ordering': ['-created_at']}),
        migrations.CreateModel('MRN', fields=[
            ('id', models.BigAutoField(auto_created=True, primary_key=True)),
            ('mrn_number', models.CharField(db_index=True, max_length=50, unique=True)),
            ('status', models.CharField(choices=[('draft','Draft'),('submitted','Submitted'),('approved','Approved — Issued'),('partial','Partially Issued'),('rejected','Rejected')], default='draft', max_length=15)),
            ('notes', models.TextField(blank=True)),
            ('approved_at', models.DateTimeField(blank=True, null=True)),
            ('created_at', models.DateTimeField(auto_now_add=True)),
            ('approved_by', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='mrns_approved', to=settings.AUTH_USER_MODEL)),
            ('requested_by', models.ForeignKey(null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='mrns_requested', to=settings.AUTH_USER_MODEL)),
            ('work_order', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='mrns', to='pmc.workorder')),
        ], options={'ordering': ['-created_at']}),
        migrations.CreateModel('MRNLine', fields=[
            ('id', models.BigAutoField(auto_created=True, primary_key=True)),
            ('qty_requested', models.DecimalField(decimal_places=2, max_digits=12)),
            ('qty_issued', models.DecimalField(decimal_places=2, default=0, max_digits=12)),
            ('uom', models.CharField(default='EA', max_length=20)),
            ('notes', models.CharField(blank=True, max_length=255)),
            ('mrn', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='lines', to='pmc.mrn')),
            ('product', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, to='inventory.product')),
        ]),
    ]
