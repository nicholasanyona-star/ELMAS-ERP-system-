"""
ELMAS PMC Migration 0006
- Add status, has_battery_lines, wh_pick_completed_at, battery_completed_at to SIV
- Add is_battery_line, unit_cost to SIVLine
- Add FMApprovalQueue model
"""
from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('pmc', '0005_mretn'),
        ('accounts', '0004_user_assigned_line'),
        ('master', '0002_new_types_settings_lines'),
    ]

    operations = [

        # SIV — add status and battery tracking
        migrations.AddField(
            model_name='siv',
            name='status',
            field=models.CharField(
                choices=[
                    ('generated',        'Generated'),
                    ('wh_picking',       'WH Picking'),
                    ('wh_pick_complete', 'WH Pick Complete'),
                    ('battery_pending',  'Battery Pick Pending'),
                    ('battery_picked',   'Battery Picked'),
                    ('complete',         'Complete'),
                ],
                db_index=True, default='generated', max_length=20,
            ),
        ),
        migrations.AddField(
            model_name='siv',
            name='has_battery_lines',
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name='siv',
            name='wh_pick_completed_at',
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name='siv',
            name='battery_completed_at',
            field=models.DateTimeField(blank=True, null=True),
        ),

        # SIVLine — add battery flag and unit_cost
        migrations.AddField(
            model_name='sivline',
            name='is_battery_line',
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name='sivline',
            name='unit_cost',
            field=models.DecimalField(decimal_places=2, default=0, max_digits=12),
        ),

    ]
