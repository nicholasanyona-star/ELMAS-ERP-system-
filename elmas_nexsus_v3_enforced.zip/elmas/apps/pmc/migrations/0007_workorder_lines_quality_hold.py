"""
ELMAS PMC Migration 0007
- Add assembly_line, packaging_line FKs to WorkOrder
- Add quality_hold fields to WorkOrder
- Add quality_hold status to STATUS_CHOICES
"""
from django.db import migrations, models
import django.db.models.deletion
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('pmc', '0006_siv_battery_fmqueue'),
        ('master', '0002_new_types_settings_lines'),
        ('accounts', '0004_user_assigned_line'),
    ]

    operations = [
        # WorkOrder — line assignment
        migrations.AddField(
            model_name='workorder',
            name='assembly_line',
            field=models.ForeignKey(
                blank=True, null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='assembly_work_orders',
                to='master.productionline',
            ),
        ),
        migrations.AddField(
            model_name='workorder',
            name='packaging_line',
            field=models.ForeignKey(
                blank=True, null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='packaging_work_orders',
                to='master.productionline',
            ),
        ),
        # WorkOrder — quality hold
        migrations.AddField(
            model_name='workorder',
            name='quality_hold',
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name='workorder',
            name='quality_hold_by',
            field=models.ForeignKey(
                blank=True, null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='wos_quality_held',
                to=settings.AUTH_USER_MODEL,
            ),
        ),
        migrations.AddField(
            model_name='workorder',
            name='quality_hold_at',
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name='workorder',
            name='quality_hold_notes',
            field=models.TextField(blank=True),
        ),
        # Update status choices
        migrations.AlterField(
            model_name='workorder',
            name='status',
            field=models.CharField(
                choices=[
                    ('draft', 'Draft'),
                    ('released', 'Released'),
                    ('in_progress', 'In Progress'),
                    ('quality_hold', 'Quality Hold — FM Investigation'),
                    ('completed', 'Completed'),
                    ('cancelled', 'Cancelled'),
                ],
                default='draft',
                max_length=15,
            ),
        ),
    ]
