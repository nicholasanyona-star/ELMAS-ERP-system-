"""
ELMAS PMC Migration 0009
- Add submitted_at to MRN model
"""
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('pmc', '0008_mrnline_bom_intelligence'),
    ]

    operations = [
        migrations.AddField(
            model_name='mrn',
            name='submitted_at',
            field=models.DateTimeField(blank=True, null=True),
        ),
    ]
