from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('pmc', '0003_wo_cancel'),
    ]
    operations = [
        # cancelled_at already added in 0003_wo_cancel
    ]
