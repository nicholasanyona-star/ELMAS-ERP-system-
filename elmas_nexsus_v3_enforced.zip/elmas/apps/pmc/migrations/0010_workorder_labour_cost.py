"""
ELMAS-NEXSUS — pmc/0010
Add total_labour_cost to WorkOrder (auto-updated by HR shift signals)
"""
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('pmc', '0009_mrn_submitted_at'),
    ]

    operations = [
        migrations.AddField(
            model_name='workorder',
            name='total_labour_cost',
            field=models.DecimalField(
                decimal_places=2, default=0, max_digits=12,
                help_text='Cumulative labour cost from shift records',
            ),
        ),
    ]
