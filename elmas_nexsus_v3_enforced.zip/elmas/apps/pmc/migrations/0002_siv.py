from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone
from django.conf import settings


class Migration(migrations.Migration):
    dependencies = [
        ('pmc', '0001_initial'),
        ('inventory', '0001_initial'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]
    operations = [
        migrations.CreateModel(
            name='SIV',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True)),
                ('siv_number', models.CharField(db_index=True, max_length=50, unique=True)),
                ('is_signed', models.BooleanField(default=False)),
                ('notes', models.TextField(blank=True)),
                ('issued_at', models.DateTimeField(default=django.utils.timezone.now)),
                ('received_at', models.DateTimeField(blank=True, null=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('issued_by', models.ForeignKey(
                    help_text='Warehouse Controller',
                    null=True, on_delete=django.db.models.deletion.SET_NULL,
                    related_name='sivs_issued', to=settings.AUTH_USER_MODEL
                )),
                ('mrn', models.OneToOneField(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='siv', to='pmc.mrn'
                )),
                ('received_by', models.ForeignKey(
                    blank=True, null=True,
                    help_text='Production Supervisor who signs on receipt',
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='sivs_received', to=settings.AUTH_USER_MODEL
                )),
                ('work_order', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='sivs', to='pmc.workorder'
                )),
            ],
            options={'ordering': ['-created_at'], 'verbose_name': 'Store Issue Voucher'},
        ),
        migrations.CreateModel(
            name='SIVLine',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True)),
                ('batch_reference', models.CharField(blank=True, max_length=100)),
                ('from_location', models.CharField(blank=True, max_length=200)),
                ('qty_issued', models.DecimalField(decimal_places=2, max_digits=12)),
                ('uom', models.CharField(default='EA', max_length=20)),
                ('product', models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT, to='inventory.product'
                )),
                ('siv', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='lines', to='pmc.siv'
                )),
            ],
        ),
    ]
