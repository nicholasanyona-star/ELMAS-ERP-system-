from django.contrib import admin
from .models import ProductionPlan, BOM, BOMLine, WorkOrder, MRN, MRNLine, SIV, SIVLine, MRetN, MRetNLine


class BOMLineInline(admin.TabularInline):
    model = BOMLine
    extra = 1


@admin.register(BOM)
class BOMAdmin(admin.ModelAdmin):
    list_display = ('bom_number', 'phone_model', 'bom_type', 'version', 'status', 'effective_date')
    list_filter = ('bom_type', 'status')
    search_fields = ('bom_number', 'phone_model')
    inlines = [BOMLineInline]
    ordering = ('-effective_date',)


@admin.register(ProductionPlan)
class ProductionPlanAdmin(admin.ModelAdmin):
    list_display = ('plan_number', 'title', 'target_qty', 'status', 'plan_date', 'created_by')
    list_filter = ('status',)
    search_fields = ('plan_number', 'title')
    ordering = ('-plan_date',)


@admin.register(WorkOrder)
class WorkOrderAdmin(admin.ModelAdmin):
    list_display = ('wo_number', 'production_plan', 'wo_type', 'planned_qty', 'completed_qty', 'status', 'planned_date')
    list_filter = ('wo_type', 'status')
    search_fields = ('wo_number',)
    ordering = ('-planned_date',)


@admin.register(MRN)
class MRNAdmin(admin.ModelAdmin):
    list_display = ('mrn_number', 'work_order', 'status', 'requested_by', 'created_at')
    list_filter = ('status',)
    search_fields = ('mrn_number',)
    ordering = ('-created_at',)


@admin.register(SIV)
class SIVAdmin(admin.ModelAdmin):
    list_display = ('siv_number', 'mrn', 'issued_by', 'created_at')
    search_fields = ('siv_number',)
    ordering = ('-created_at',)
