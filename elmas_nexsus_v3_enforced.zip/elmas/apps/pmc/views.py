"""ELMAS PMC Views — Production Plans, BOMs, Work Orders, MRN"""
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from django.db import transaction
from apps.accounts.decorators import role_required
from .models import ProductionPlan, BOM, BOMLine, WorkOrder, MRN, MRNLine
from apps.inventory.models import Product
import logging
logger = logging.getLogger('elmas')


@login_required
@role_required('admin', 'pmc', 'factory_manager')
def plan_list(request):
    plans = ProductionPlan.objects.select_related('created_by').order_by('-plan_date')
    return render(request, 'pmc/plan_list.html', {'plans': plans, 'page_title': 'Production Plans'})


@login_required
@role_required('admin', 'pmc')
def plan_create(request):
    if request.method == 'POST':
        try:
            plan = ProductionPlan.objects.create(
                title=request.POST['title'].strip(),
                plan_date=request.POST['plan_date'],
                target_qty=int(request.POST.get('target_qty', 0)),
                notes=request.POST.get('notes', '').strip(),
                created_by=request.user,
            )
            messages.success(request, f'✓ Production Plan {plan.plan_number} created.')
            return redirect('pmc:plan_detail', pk=plan.pk)
        except Exception as e:
            messages.error(request, f'Error: {e}')
    return render(request, 'pmc/plan_form.html', {'page_title': 'New Production Plan'})


@login_required
@role_required('admin', 'pmc', 'factory_manager')
def plan_detail(request, pk):
    plan = get_object_or_404(ProductionPlan, pk=pk)
    work_orders = plan.work_orders.select_related('bom').all()
    return render(request, 'pmc/plan_detail.html', {
        'plan': plan, 'work_orders': work_orders, 'page_title': plan.plan_number,
    })



@login_required
@role_required('admin', 'factory_manager')
def plan_approve(request, pk):
    """Factory Manager approves a Production Plan"""
    plan = get_object_or_404(ProductionPlan, pk=pk)
    if request.method == 'POST':
        if plan.created_by == request.user:
            messages.error(request, '⚠ You cannot approve a plan you created. A different Factory Manager must approve it.')
            return redirect('pmc:plan_detail', pk=pk)
        plan.status = 'approved'
        plan.approved_by = request.user
        plan.save(update_fields=['status', 'approved_by'])
        messages.success(request, f'✓ Production Plan {plan.plan_number} approved.')
    return redirect('pmc:plan_detail', pk=pk)

@login_required
@role_required('admin', 'pmc', 'factory_manager', 'production')
def bom_list(request):
    boms = BOM.objects.select_related('created_by').prefetch_related('lines').order_by('phone_model', 'bom_type')
    return render(request, 'pmc/bom_list.html', {'boms': boms, 'page_title': 'Bills of Materials'})


@login_required
@role_required('admin', 'pmc')
def bom_create(request):
    if request.method == 'POST':
        try:
            bom = BOM.objects.create(
                phone_model=request.POST['phone_model'].strip(),
                bom_type=request.POST['bom_type'],
                version=request.POST.get('version', 'v1').strip() or 'v1',
                effective_date=request.POST.get('effective_date') or timezone.now().date(),
                notes=request.POST.get('notes', '').strip(),
                created_by=request.user,
            )
            messages.success(request, f'✓ BOM {bom.bom_number} created. Now add components below.')
            return redirect('pmc:bom_detail', pk=bom.pk)
        except Exception as e:
            messages.error(request, f'Error: {e}')
    return render(request, 'pmc/bom_form.html', {
        'bom_types': BOM.BOM_TYPE_CHOICES, 'page_title': 'Create BOM',
    })


@login_required
@role_required('admin', 'pmc', 'factory_manager', 'production', 'warehouse')
def bom_detail(request, pk):
    bom = get_object_or_404(BOM, pk=pk)
    lines = bom.lines.select_related('component').order_by('sequence')
    # Calculator — how many phones?
    calc_qty = int(request.GET.get('qty', 0) or 0)
    lines_with_totals = []
    for line in lines:
        total = line.required_for(calc_qty) if calc_qty > 0 else None
        try:
            stock = line.component.current_stock
        except Exception:
            stock = 0
        lines_with_totals.append({
            'line': line,
            'total_required': float(total) if total else None,
            'current_stock': float(stock),
            'sufficient': stock >= float(total) if total else True,
        })
    all_products = Product.objects.filter(is_active=True).order_by('name')
    return render(request, 'pmc/bom_detail.html', {
        'bom': bom,
        'lines_with_totals': lines_with_totals,
        'calc_qty': calc_qty,
        'all_products': all_products,
        'page_title': f'{bom.bom_number} — {bom.phone_model}',
    })


@login_required
@role_required('admin', 'factory_manager')
def bom_approve(request, pk):
    bom = get_object_or_404(BOM, pk=pk)
    if request.method == 'POST':
        if bom.created_by == request.user:
            messages.error(request, '⚠ You cannot approve a BOM you created. A different Factory Manager must approve it.')
            return redirect('pmc:bom_detail', pk=pk)
        if not bom.lines.exists():
            messages.error(request, '⚠ Cannot approve an empty BOM. Add at least one component first.')
            return redirect('pmc:bom_detail', pk=pk)
        bom.status = 'approved'
        bom.approved_by = request.user
        bom.save(update_fields=['status', 'approved_by'])
        messages.success(request, f'✓ BOM {bom.bom_number} approved. Can now be used for Work Orders.')
    return redirect('pmc:bom_detail', pk=pk)


@login_required
@role_required('admin', 'pmc')
def bom_add_line(request, pk):
    bom = get_object_or_404(BOM, pk=pk)
    if request.method == 'POST':
        try:
            product = Product.objects.get(pk=request.POST['component'])
            BOMLine.objects.create(
                bom=bom,
                component=product,
                quantity_per_unit=float(request.POST['quantity_per_unit']),
                uom=request.POST.get('uom', product.uom),
                scrap_allowance=float(request.POST.get('scrap_allowance', 0) or 0),
                sequence=int(request.POST.get('sequence', 10) or 10),
                notes=request.POST.get('notes', '').strip(),
            )
            messages.success(request, f'✓ {product.name} added to BOM.')
        except Exception as e:
            messages.error(request, f'Error: {e}')
    return redirect('pmc:bom_detail', pk=pk)


@login_required
@role_required('admin', 'pmc')
def bom_delete_line(request, pk, line_pk):
    bom = get_object_or_404(BOM, pk=pk)
    if request.method == 'POST':
        BOMLine.objects.filter(pk=line_pk, bom=bom).delete()
        messages.success(request, 'Line removed.')
    return redirect('pmc:bom_detail', pk=pk)


@login_required
def bom_pdf(request, pk):
    from apps.master.models import SystemSettings
    bom = get_object_or_404(BOM, pk=pk)
    lines = bom.lines.select_related('component').order_by('sequence')
    return render(request, 'pmc/bom_pdf.html', {
        'bom': bom, 'lines': lines, 'sys': SystemSettings.get_settings(),
    })


@login_required
@role_required('admin', 'pmc', 'factory_manager')
def wo_list(request):
    wos = WorkOrder.objects.select_related('bom', 'created_by').order_by('-created_at')
    status_filter = request.GET.get('status', '')
    if status_filter:
        wos = wos.filter(status=status_filter)
    return render(request, 'pmc/wo_list.html', {
        'wos': wos, 'status_filter': status_filter,
        'status_choices': WorkOrder.STATUS_CHOICES,
        'page_title': 'Work Orders',
    })


@login_required
@role_required('admin', 'pmc')
def wo_create(request):
    approved_boms = BOM.objects.filter(status='approved').order_by('phone_model', 'bom_type')
    plans = ProductionPlan.objects.filter(status__in=['approved', 'in_progress']).order_by('-plan_date')
    if request.method == 'POST':
        try:
            bom = BOM.objects.get(pk=request.POST['bom'])
            wo = WorkOrder.objects.create(
                bom=bom,
                wo_type=bom.bom_type,
                planned_qty=int(request.POST['planned_qty']),
                planned_date=request.POST['planned_date'],
                production_plan_id=request.POST.get('production_plan') or None,
                notes=request.POST.get('notes', '').strip(),
                created_by=request.user,
            )
            messages.success(request, f'✓ Work Order {wo.wo_number} created. Materials: {wo.bom.phone_model} × {wo.planned_qty}')
            return redirect('pmc:wo_detail', pk=wo.pk)
        except Exception as e:
            messages.error(request, f'Error: {e}')
    return render(request, 'pmc/wo_form.html', {
        'approved_boms': approved_boms, 'plans': plans, 'page_title': 'Create Work Order',
    })


@login_required
@role_required('admin', 'pmc', 'factory_manager', 'warehouse', 'production')
def wo_detail(request, pk):
    wo = get_object_or_404(WorkOrder, pk=pk)
    materials = wo.calculate_materials()
    mrns = wo.mrns.select_related('requested_by', 'approved_by').all()
    shortages = [m for m in materials if m['current_stock'] < m['required_qty']]
    return render(request, 'pmc/wo_detail.html', {
        'wo': wo, 'materials': materials, 'mrns': mrns,
        'shortages': shortages, 'page_title': wo.wo_number,
    })


@login_required
@role_required('admin', 'pmc', 'factory_manager')
def wo_release(request, pk):
    wo = get_object_or_404(WorkOrder, pk=pk)
    if request.method == 'POST':
        if wo.bom.status != 'approved':
            messages.error(request, f'⚠ BOM {wo.bom.bom_number} is not approved. Get Factory Manager approval before releasing.')
            return redirect('pmc:wo_detail', pk=pk)
        if not wo.bom.lines.exists():
            messages.error(request, f'⚠ BOM {wo.bom.bom_number} has no components. Add components before releasing.')
            return redirect('pmc:wo_detail', pk=pk)
        wo.status = 'released'
        wo.save(update_fields=['status'])
        # Auto-notify Production Supervisors
        try:
            from apps.messaging.models import Message, MessageRecipient
            from apps.accounts.models import User
            supervisors = User.objects.filter(role='production', is_active=True)
            for sup in supervisors:
                msg = Message.objects.create(
                    sender=request.user,
                    subject=f'Work Order Released: {wo.wo_number}',
                    body=f'Work Order {wo.wo_number} has been released to the production floor.\n\nPhone Model: {wo.bom.phone_model}\nType: {wo.get_wo_type_display()}\nPlanned Qty: {wo.planned_qty} units\nPlanned Date: {wo.planned_date}\n\nView in ELMAS: PMC → Work Orders → {wo.wo_number}',
                    is_urgent=False,
                    ref_module='wo',
                    ref_number=wo.wo_number,
                )
                MessageRecipient.objects.create(message=msg, recipient=sup)
        except Exception as e:
            logger.warning(f'[wo_release] notification failed: {e}')
        messages.success(request, f'✓ Work Order {wo.wo_number} released. Production Supervisors notified.')
    return redirect('pmc:wo_detail', pk=pk)


@login_required
@role_required('admin', 'pmc')
def mrn_create(request, pk):
    wo = get_object_or_404(WorkOrder, pk=pk)
    if request.method == 'POST':
        try:
            with transaction.atomic():
                mrn = MRN.objects.create(
                    work_order=wo,
                    notes=request.POST.get('notes', '').strip(),
                    requested_by=request.user,
                )
                for mat in wo.calculate_materials():
                    calc_qty = mat['required_qty']
                    current = mat['current_stock']
                    shortfall = mat['shortfall']
                    MRNLine.objects.create(
                        mrn=mrn,
                        product=mat['component'],
                        qty_requested=calc_qty,
                        bom_calculated_qty=calc_qty,
                        available_at_request=current,
                        has_shortfall=shortfall > 0,
                        shortfall_qty=shortfall,
                        uom=mat['uom'],
                    )
                mrn.status = 'submitted'
                mrn.submitted_at = timezone.now()
                mrn.save(update_fields=['status'])
                messages.success(
                    request,
                    f'✓ MRN {mrn.mrn_number} created with {mrn.lines.count()} lines. Submitted for FM approval.'
                )
                # Notify FM via FMApprovalQueue
                try:
                    from apps.core.models import FMApprovalQueue
                    shortfall_count = mrn.lines.filter(has_shortfall=True).count()
                    urgency = 'urgent' if shortfall_count > 0 else 'normal'
                    FMApprovalQueue.objects.create(
                        document_type='mrn',
                        document_ref=mrn.mrn_number,
                        document_id=mrn.pk,
                        raised_by=request.user,
                        urgency=urgency,
                        description=f'MRN {mrn.mrn_number} for {wo.wo_number} — {mrn.lines.count()} lines. '
                                    f'{"⚠ " + str(shortfall_count) + " shortfall(s) detected." if shortfall_count else "All materials available."}'
                    )
                except Exception:
                    pass
                # Notify FM via messaging
                try:
                    from apps.messaging.views import send_system_message
                    send_system_message(
                        subject=f'MRN Awaiting Approval: {mrn.mrn_number}',
                        body=f'MRN {mrn.mrn_number} for WO {wo.wo_number} requires your approval.\nLines: {mrn.lines.count()}\nPhone: {wo.bom.phone_model}',
                        role='factory_manager',
                        is_urgent=False,
                        ref_type='mrn',
                        ref_num=mrn.mrn_number,
                    )
                except Exception:
                    pass
        except Exception as e:
            messages.error(request, f'Error: {e}')
    return redirect('pmc:wo_detail', pk=pk)


@login_required
@role_required('admin', 'pmc', 'warehouse', 'factory_manager')
def mrn_list(request):
    mrns = MRN.objects.select_related('work_order', 'requested_by', 'approved_by').order_by('-created_at')
    status_filter = request.GET.get('status', '')
    if status_filter:
        mrns = mrns.filter(status=status_filter)
    return render(request, 'pmc/mrn_list.html', {
        'mrns': mrns, 'status_filter': status_filter,
        'status_choices': MRN.STATUS_CHOICES, 'page_title': 'Material Request Notes',
    })


@login_required
@role_required('admin', 'pmc', 'warehouse', 'factory_manager')
def mrn_detail(request, pk):
    mrn = get_object_or_404(MRN, pk=pk)
    lines = mrn.lines.select_related('product').all()
    from apps.accounts.models import User
    warehouse_users = User.objects.filter(role='warehouse', is_active=True)
    return render(request, 'pmc/mrn_detail.html', {
        'mrn': mrn, 'lines': lines,
        'warehouse_users': warehouse_users,
        'page_title': mrn.mrn_number,
    })


@login_required
@role_required('admin', 'warehouse')
def mrn_approve(request, pk):
    mrn = get_object_or_404(MRN, pk=pk)
    if request.method == 'POST':
        if mrn.requested_by == request.user:
            messages.error(request, '⚠ You cannot approve your own MRN. A different Warehouse Controller must approve it.')
            return redirect('pmc:mrn_detail', pk=pk)
        if mrn.status != 'submitted':
            messages.error(request, f'MRN is already {mrn.status} — cannot approve again.')
            return redirect('pmc:mrn_detail', pk=pk)
        try:
            with transaction.atomic():
                # Lock MRN to prevent concurrent approval
                mrn = MRN.objects.select_for_update().get(pk=pk)
                if mrn.status != 'submitted':
                    messages.error(request, 'MRN was already processed (concurrent request blocked).')
                    return redirect('pmc:mrn_detail', pk=pk)
                from apps.inventory.models import StockBatch, StockMovement, get_current_stock
                # Pre-validate all lines have sufficient stock before touching anything
                shortfalls = []
                for line in mrn.lines.select_related('product').all():
                    available = float(get_current_stock(line.product))
                    needed = float(line.qty_requested)
                    if available < needed:
                        shortfalls.append(
                            f'{line.product.name}: need {needed}, have {available}'
                        )
                if shortfalls:
                    messages.error(request,
                        f'⚠ Insufficient stock — cannot issue MRN: {"; ".join(shortfalls)}')
                    return redirect('pmc:mrn_detail', pk=pk)
                for line in mrn.lines.select_related('product').all():
                    issued = 0
                    batches = StockBatch.objects.select_for_update().filter(
                        product=line.product, status='available',
                        remaining_quantity__gt=0,
                    ).order_by('received_at')
                    needed = float(line.qty_requested)
                    for batch in batches:
                        if issued >= needed:
                            break
                        take = min(float(batch.remaining_quantity), needed - issued)
                        batch.remaining_quantity -= take
                        if batch.remaining_quantity <= 0:
                            batch.status = 'depleted'
                        batch.save(update_fields=['remaining_quantity', 'status'])
                        StockMovement.objects.create(
                            product=line.product,
                            batch=batch,
                            movement_type='mrn_issue',
                            quantity=take,
                            from_location=batch.location_display if hasattr(batch, 'location_display') else 'Warehouse',
                            to_location=f'Production — {mrn.work_order.wo_number}',
                            performed_by=request.user,
                            reference=mrn.mrn_number,
                        )
                        issued += take
                    line.qty_issued = issued
                    line.save(update_fields=['qty_issued'])
                mrn.status = 'approved'
                mrn.approved_by = request.user
                mrn.approved_at = timezone.now()
                mrn.save(update_fields=['status', 'approved_by', 'approved_at'])

                # Auto-create SIV with full batch and location details
                try:
                    from apps.pmc.models import SIV, SIVLine
                    siv = SIV.objects.create(
                        mrn=mrn,
                        work_order=mrn.work_order,
                        issued_by=request.user,
                    )
                    # Build SIV lines from stock movements — captures actual batch and location
                    for line in mrn.lines.select_related('product').all():
                        if line.qty_issued > 0:
                            # Get the movements created for this line to get batch/location info
                            movements = StockMovement.objects.filter(
                                product=line.product,
                                reference=mrn.mrn_number,
                                movement_type='mrn_issue',
                            ).select_related('batch').order_by('created_at')
                            if movements.exists():
                                # Create one SIV line per batch movement for full traceability
                                for mov in movements:
                                    batch_ref = mov.batch.batch_number if mov.batch else ''
                                    from_loc = mov.from_location or 'Warehouse'
                                    SIVLine.objects.create(
                                        siv=siv,
                                        product=line.product,
                                        batch_reference=batch_ref,
                                        from_location=from_loc,
                                        qty_issued=mov.quantity,
                                        uom=line.uom,
                                    )
                            else:
                                # Fallback: single line without batch detail
                                SIVLine.objects.create(
                                    siv=siv,
                                    product=line.product,
                                    qty_issued=line.qty_issued,
                                    uom=line.uom,
                                )
                    logger.info(f'[mrn_approve] SIV {siv.siv_number} created for {mrn.mrn_number} with {siv.lines.count()} lines')
                except Exception as siv_err:
                    logger.warning(f'[mrn_approve] SIV creation failed (non-critical): {siv_err}')

                # GL: DR WIP / CR Inventory per issued line
                try:
                    from apps.gl.models import post_material_issue
                    for line in mrn.lines.select_related('product').all():
                        if float(line.qty_issued) > 0:
                            post_material_issue(
                                product=line.product,
                                qty=float(line.qty_issued),
                                unit_cost=float(line.product.unit_cost),
                                wo_number=mrn.work_order.wo_number,
                                mrn_number=mrn.mrn_number,
                                user=request.user,
                            )
                except Exception as gl_err:
                    logger.warning(f'[GL] MRN material issue post: {gl_err}')

                # Auto-create MMN for the material movement record
                try:
                    from apps.inventory.models import MaterialMovementNote, MMNLine
                    from apps.master.models import Warehouse
                    wh = Warehouse.objects.filter(warehouse_type='raw_material', is_active=True).first()
                    mmn = MaterialMovementNote.objects.create(
                        purpose='production_issue',
                        status='complete',
                        from_warehouse=wh,
                        from_description='Main Warehouse Store',
                        to_description=f'Production Floor — {mrn.work_order.wo_number}',
                        initiated_by=request.user,
                        received_by=request.user,
                        notes=f'Auto-generated from MRN {mrn.mrn_number}',
                    )
                    for line in mrn.lines.select_related('product').all():
                        if line.qty_issued > 0:
                            MMNLine.objects.create(
                                mmn=mmn,
                                product=line.product,
                                quantity=line.qty_issued,
                                uom=line.uom,
                            )
                    logger.info(f'[mrn_approve] MMN {mmn.mmn_number} auto-created for {mrn.mrn_number}')
                except Exception as mmn_err:
                    logger.warning(f'[mrn_approve] MMN creation failed (non-critical): {mmn_err}')

                messages.success(request, f'✓ MRN {mrn.mrn_number} approved. Materials issued. SIV generated — print and send with goods.')
        except Exception as e:
            logger.error(f'[mrn_approve] {e}')
            messages.error(request, f'Error issuing materials: {e}')
    return redirect('pmc:mrn_detail', pk=pk)


@login_required
def mrn_pdf(request, pk):
    from apps.master.models import SystemSettings
    mrn = get_object_or_404(MRN, pk=pk)
    lines = mrn.lines.select_related('product').all()
    return render(request, 'pmc/mrn_pdf.html', {
        'mrn': mrn, 'lines': lines, 'sys': SystemSettings.get_settings(),
    })


@login_required
def wo_pdf(request, pk):
    from apps.master.models import SystemSettings
    wo = get_object_or_404(WorkOrder, pk=pk)
    materials = wo.calculate_materials()
    return render(request, 'pmc/wo_pdf.html', {
        'wo': wo, 'materials': materials, 'sys': SystemSettings.get_settings(),
    })


@login_required
@role_required('admin', 'warehouse', 'factory_manager', 'production', 'pmc')
def siv_list(request):
    from apps.pmc.models import SIV
    sivs = SIV.objects.select_related(
        'mrn', 'work_order', 'issued_by', 'received_by'
    ).order_by('-created_at')
    return render(request, 'pmc/siv_list.html', {
        'sivs': sivs, 'page_title': 'Store Issue Vouchers',
    })


@login_required
@role_required('admin', 'warehouse', 'factory_manager', 'production')
def siv_detail(request, pk):
    from apps.pmc.models import SIV
    siv = get_object_or_404(SIV, pk=pk)
    lines = siv.lines.select_related('product').all()
    return render(request, 'pmc/siv_detail.html', {
        'siv': siv, 'lines': lines, 'page_title': siv.siv_number,
    })


@login_required
@role_required('admin', 'production')
def siv_sign(request, pk):
    """Production Supervisor countersigns SIV on receipt of materials"""
    from apps.pmc.models import SIV
    siv = get_object_or_404(SIV, pk=pk)
    if request.method == 'POST':
        if siv.issued_by == request.user:
            messages.error(request, '⚠ The Production Supervisor must be a different person from the Warehouse Controller who issued the materials.')
            return redirect('pmc:siv_detail', pk=pk)
        siv.received_by = request.user
        siv.received_at = timezone.now()
        siv.is_signed = True
        siv.save(update_fields=['received_by', 'received_at', 'is_signed'])
        messages.success(request, f'✓ SIV {siv.siv_number} signed. Materials confirmed received.')
    return redirect('pmc:siv_detail', pk=pk)


@login_required
@role_required('admin', 'warehouse', 'factory_manager', 'production', 'pmc')
def siv_pdf(request, pk):
    from apps.pmc.models import SIV
    from apps.master.models import SystemSettings
    siv = get_object_or_404(SIV, pk=pk)
    lines = siv.lines.select_related('product').all()
    return render(request, 'pmc/siv_pdf.html', {
        'siv': siv, 'lines': lines,
        'sys': SystemSettings.get_settings(),
    })


@login_required
@role_required('admin', 'factory_manager', 'pmc')
def wo_cancel(request, pk):
    """Cancel a Work Order"""
    wo = get_object_or_404(WorkOrder, pk=pk)
    # Check if any MRN has been approved (materials issued)
    issued = wo.mrns.filter(status='approved').exists()
    if wo.status in ('draft', 'released'):
        if request.method == 'POST':
            reason = request.POST.get('reason', '').strip()
            if not reason:
                messages.error(request, 'A reason is required to cancel a Work Order.')
                return render(request, 'pmc/wo_cancel.html', {'wo': wo, 'issued': issued})
            if issued and request.user.role not in ('admin',):
                messages.error(request, '⚠ Materials have already been issued against this WO. Only System Administrator can cancel it.')
                return render(request, 'pmc/wo_cancel.html', {'wo': wo, 'issued': issued})
            wo.status = 'cancelled'
            wo.cancellation_reason = reason
            wo.cancelled_by = request.user
            wo.cancelled_at = timezone.now()
            wo.save(update_fields=['status', 'cancellation_reason', 'cancelled_by', 'cancelled_at'])
            messages.success(request, f'Work Order {wo.wo_number} cancelled.')
            return redirect('pmc:wo_list')
        return render(request, 'pmc/wo_cancel.html', {'wo': wo, 'issued': issued, 'page_title': f'Cancel {wo.wo_number}'})
    else:
        messages.error(request, f'Work Order cannot be cancelled at status: {wo.get_status_display()}.')
        return redirect('pmc:wo_detail', pk=pk)



@login_required
@role_required('admin', 'pmc', 'factory_manager')
def mrn_send(request, pk):
    mrn = get_object_or_404(MRN, pk=pk)
    if request.method == 'POST':
        from apps.messaging.models import Message, MessageRecipient
        from apps.accounts.models import User
        recipient_id = request.POST.get('recipient')
        note = request.POST.get('note', '').strip()
        is_urgent = request.POST.get('is_urgent') == 'on'
        try:
            if recipient_id:
                recipients = [User.objects.get(pk=recipient_id)]
            else:
                recipients = list(User.objects.filter(role='warehouse', is_active=True))
            body = note if note else (
                'Please review and approve MRN ' + mrn.mrn_number + '.\n\n'
                'Work Order: ' + mrn.work_order.wo_number + '\n'
                'Phone Model: ' + mrn.work_order.bom.phone_model + '\n'
                'Lines: ' + str(mrn.lines.count()) + ' materials requested.\n\n'
                'View and approve in ELMAS: PMC → MRN → ' + mrn.mrn_number
            )
            for recipient in recipients:
                msg = Message.objects.create(
                    sender=request.user,
                    subject='MRN for Approval: ' + mrn.mrn_number,
                    body=body,
                    is_urgent=is_urgent,
                    ref_module='mrn',
                    ref_number=mrn.mrn_number,
                )
                MessageRecipient.objects.create(message=msg, recipient=recipient)
            names = ', '.join(r.get_full_name() for r in recipients)
            messages.success(request, '✓ MRN ' + mrn.mrn_number + ' sent to ' + names + '.')
        except Exception as e:
            messages.error(request, 'Error sending: ' + str(e))
    return redirect('pmc:mrn_detail', pk=pk)


@login_required
@role_required('admin', 'pmc', 'factory_manager')
def wo_send(request, pk):
    wo = get_object_or_404(WorkOrder, pk=pk)
    if request.method == 'POST':
        from apps.messaging.models import Message, MessageRecipient
        from apps.accounts.models import User
        recipient_id = request.POST.get('recipient')
        note = request.POST.get('note', '').strip()
        is_urgent = request.POST.get('is_urgent') == 'on'
        try:
            if recipient_id:
                recipients = [User.objects.get(pk=recipient_id)]
            else:
                recipients = list(User.objects.filter(role='production', is_active=True))
            body = note if note else (
                'Work Order ' + wo.wo_number + ' has been released.\n\n'
                'Phone Model: ' + wo.bom.phone_model + '\n'
                'Type: ' + wo.get_wo_type_display() + '\n'
                'Planned Quantity: ' + str(wo.planned_qty) + ' units\n\n'
                'View in ELMAS: PMC → Work Orders → ' + wo.wo_number
            )
            for recipient in recipients:
                msg = Message.objects.create(
                    sender=request.user,
                    subject='Work Order Released: ' + wo.wo_number,
                    body=body,
                    is_urgent=is_urgent,
                    ref_module='wo',
                    ref_number=wo.wo_number,
                )
                MessageRecipient.objects.create(message=msg, recipient=recipient)
            names = ', '.join(r.get_full_name() for r in recipients)
            messages.success(request, '✓ WO ' + wo.wo_number + ' sent to ' + names + '.')
        except Exception as e:
            messages.error(request, 'Error sending: ' + str(e))
    return redirect('pmc:wo_detail', pk=pk)


@login_required
@role_required('admin', 'pmc', 'factory_manager')
def bom_send(request, pk):
    bom = get_object_or_404(BOM, pk=pk)
    if request.method == 'POST':
        from apps.messaging.models import Message, MessageRecipient
        from apps.accounts.models import User
        recipient_id = request.POST.get('recipient')
        note = request.POST.get('note', '').strip()
        try:
            if recipient_id:
                recipients = [User.objects.get(pk=recipient_id)]
            else:
                recipients = list(User.objects.filter(role='factory_manager', is_active=True))
            body = note if note else (
                'Please review and approve BOM ' + bom.bom_number + '.\n\n'
                'Phone Model: ' + bom.phone_model + '\n'
                'Type: ' + bom.get_bom_type_display() + '\n'
                'Version: ' + bom.version + '\n'
                'Components: ' + str(bom.total_lines()) + ' lines\n\n'
                'View in ELMAS: PMC → BOMs → ' + bom.bom_number
            )
            for recipient in recipients:
                msg = Message.objects.create(
                    sender=request.user,
                    subject='BOM for Approval: ' + bom.bom_number,
                    body=body,
                    is_urgent=False,
                    ref_module='bom',
                    ref_number=bom.bom_number,
                )
                MessageRecipient.objects.create(message=msg, recipient=recipient)
            names = ', '.join(r.get_full_name() for r in recipients)
            messages.success(request, '✓ BOM ' + bom.bom_number + ' sent to ' + names + ' for approval.')
        except Exception as e:
            messages.error(request, 'Error sending: ' + str(e))
    return redirect('pmc:bom_detail', pk=pk)


# ══════════════════════════════════════════════════════════════
#  MATERIAL RETURN NOTE (MRetN) — reverse of MRN
#  Production returns materials to warehouse
# ══════════════════════════════════════════════════════════════

@login_required
@role_required('admin', 'production', 'factory_manager', 'warehouse')
def mretn_list(request):
    from apps.pmc.models import MRetN
    mretns = MRetN.objects.select_related(
        'work_order', 'initiated_by', 'accepted_by'
    ).order_by('-created_at')
    status_filter = request.GET.get('status', '')
    reason_filter = request.GET.get('reason', '')
    if status_filter:
        mretns = mretns.filter(status=status_filter)
    if reason_filter:
        mretns = mretns.filter(reason=reason_filter)
    from django.core.paginator import Paginator
    page_obj = Paginator(mretns, 25).get_page(request.GET.get('page', 1))
    return render(request, 'pmc/mretn_list.html', {
        'mretns': page_obj, 'page_obj': page_obj,
        'status_filter': status_filter, 'reason_filter': reason_filter,
        'status_choices': MRetN.STATUS_CHOICES,
        'reason_choices': MRetN.REASON_CHOICES,
        'page_title': 'Material Return Notes',
    })


@login_required
@role_required('admin', 'production', 'factory_manager')
def mretn_create(request, wo_pk):
    """Production Supervisor initiates a material return against a Work Order"""
    from apps.pmc.models import MRetN, MRetNLine, MRN
    from apps.inventory.models import Product
    wo = get_object_or_404(WorkOrder, pk=wo_pk)
    # Get MRNs that were approved for this WO — for reference
    mrns = MRN.objects.filter(work_order=wo, status='approved').order_by('-created_at')
    if request.method == 'POST':
        try:
            reason      = request.POST.get('reason')
            reason_notes= request.POST.get('reason_notes', '').strip()
            return_to   = request.POST.get('return_to', 'available')
            mrn_ref_pk  = request.POST.get('original_mrn') or None

            if not reason:
                messages.error(request, 'Please select a reason for the return.')
                return redirect('pmc:mretn_create', wo_pk=wo_pk)
            if not reason_notes:
                messages.error(request, 'Please provide a detailed explanation.')
                return redirect('pmc:mretn_create', wo_pk=wo_pk)

            mrn_ref = MRN.objects.filter(pk=mrn_ref_pk).first() if mrn_ref_pk else None

            mretn = MRetN.objects.create(
                work_order=wo,
                original_mrn=mrn_ref,
                reason=reason,
                reason_notes=reason_notes,
                return_to=return_to,
                initiated_by=request.user,
                status='draft',
            )
            messages.success(request, f'✓ {mretn.mretn_number} created. Now add items to return.')
            return redirect('pmc:mretn_detail', pk=mretn.pk)
        except Exception as e:
            logger.error(f'[mretn_create] {e}')
            messages.error(request, f'Error: {e}')
    return render(request, 'pmc/mretn_create.html', {
        'wo': wo, 'mrns': mrns,
        'reason_choices': MRetN.REASON_CHOICES,
        'return_to_choices': MRetN.RETURN_TO_CHOICES,
        'page_title': f'New Material Return — {wo.wo_number}',
    })


@login_required
@role_required('admin', 'production', 'factory_manager', 'warehouse')
def mretn_detail(request, pk):
    from apps.pmc.models import MRetN
    mretn = get_object_or_404(MRetN, pk=pk)
    lines = mretn.lines.select_related('product').all()
    from apps.inventory.models import Product
    all_products = Product.objects.filter(is_active=True).order_by('name')
    return render(request, 'pmc/mretn_detail.html', {
        'mretn': mretn, 'lines': lines,
        'all_products': all_products,
        'page_title': mretn.mretn_number,
    })


@login_required
@role_required('admin', 'production', 'factory_manager')
def mretn_add_line(request, pk):
    from apps.pmc.models import MRetN, MRetNLine
    from apps.inventory.models import Product
    mretn = get_object_or_404(MRetN, pk=pk)
    if mretn.status != 'draft':
        messages.error(request, 'Lines can only be added to draft MRetNs.')
        return redirect('pmc:mretn_detail', pk=pk)
    if request.method == 'POST':
        try:
            product = get_object_or_404(Product, pk=request.POST['product'])
            qty = float(request.POST['qty_returned'])
            condition = request.POST.get('condition', 'good')
            defect_desc = request.POST.get('defect_description', '').strip()
            batch_ref = request.POST.get('batch_reference', '').strip()

            if qty <= 0:
                messages.error(request, 'Quantity must be greater than zero.')
                return redirect('pmc:mretn_detail', pk=pk)
            if condition != 'good' and not defect_desc:
                messages.error(request, f'A defect description is required when condition is not Good.')
                return redirect('pmc:mretn_detail', pk=pk)

            MRetNLine.objects.create(
                mretn=mretn,
                product=product,
                qty_returned=qty,
                uom=product.uom,
                condition=condition,
                defect_description=defect_desc,
                batch_reference=batch_ref,
            )
            messages.success(request, f'✓ {product.name} added to return.')
        except Exception as e:
            messages.error(request, f'Error: {e}')
    return redirect('pmc:mretn_detail', pk=pk)


@login_required
@role_required('admin', 'production', 'factory_manager')
def mretn_delete_line(request, pk, line_pk):
    from apps.pmc.models import MRetN, MRetNLine
    mretn = get_object_or_404(MRetN, pk=pk)
    if mretn.status != 'draft':
        messages.error(request, 'Cannot remove lines from a submitted MRetN.')
        return redirect('pmc:mretn_detail', pk=pk)
    if request.method == 'POST':
        MRetNLine.objects.filter(pk=line_pk, mretn=mretn).delete()
        messages.success(request, 'Line removed.')
    return redirect('pmc:mretn_detail', pk=pk)


@login_required
@role_required('admin', 'production', 'factory_manager')
def mretn_submit(request, pk):
    """Production Supervisor submits — WC notified to come and accept"""
    from apps.pmc.models import MRetN
    mretn = get_object_or_404(MRetN, pk=pk)
    if request.method == 'POST':
        if mretn.status != 'draft':
            messages.error(request, 'Only draft MRetNs can be submitted.')
            return redirect('pmc:mretn_detail', pk=pk)
        if not mretn.lines.exists():
            messages.error(request, 'Cannot submit a MRetN with no items. Add items first.')
            return redirect('pmc:mretn_detail', pk=pk)
        mretn.status = 'submitted'
        mretn.save(update_fields=['status'])
        # Notify Warehouse Controllers
        try:
            from apps.messaging.models import Message, MessageRecipient
            from apps.accounts.models import User
            wcs = User.objects.filter(role='warehouse', is_active=True)
            for wc in wcs:
                msg = Message.objects.create(
                    sender=request.user,
                    subject=f'Material Return: {mretn.mretn_number}',
                    body=(
                        f'Materials are being returned from production to the warehouse.\n\n'
                        f'MRetN: {mretn.mretn_number}\n'
                        f'Work Order: {mretn.work_order.wo_number}\n'
                        f'Reason: {mretn.get_reason_display()}\n'
                        f'Items: {mretn.lines.count()} line(s)\n'
                        f'Return to: {mretn.get_return_to_display()}\n\n'
                        f'Details:\n{mretn.reason_notes}\n\n'
                        f'Please go to PMC → Material Returns to accept this return.'
                    ),
                    is_urgent=False,
                    ref_module='mretn',
                    ref_number=mretn.mretn_number,
                    reference_type='MRetN',
                    reference_number=mretn.mretn_number,
                )
                MessageRecipient.objects.create(message=msg, recipient=wc)
        except Exception as e:
            logger.warning(f'[mretn_submit] notify error: {e}')
        messages.success(request, f'✓ {mretn.mretn_number} submitted. Warehouse Controller has been notified.')
    return redirect('pmc:mretn_detail', pk=pk)


@login_required
@role_required('admin', 'warehouse', 'factory_manager')
def mretn_accept(request, pk):
    """
    Warehouse Controller accepts the returned materials.
    Two-signature rule: WC must be different from the Production Supervisor who submitted.
    Stock is credited back to inventory (or quarantine/scrap) based on return_to.
    """
    from apps.pmc.models import MRetN
    from apps.inventory.models import StockBatch, StockMovement
    from apps.master.models import Warehouse
    mretn = get_object_or_404(MRetN, pk=pk)

    if request.method == 'POST':
        if mretn.initiated_by == request.user:
            messages.error(
                request,
                '⚠ You cannot accept a return you initiated. '
                'A different Warehouse Controller must countersign.'
            )
            return redirect('pmc:mretn_detail', pk=pk)
        if mretn.status != 'submitted':
            messages.error(request, 'Only submitted MRetNs can be accepted.')
            return redirect('pmc:mretn_detail', pk=pk)

        try:
            with transaction.atomic():
                # Determine destination warehouse
                if mretn.return_to == 'available':
                    dest_wh = Warehouse.objects.filter(warehouse_type='raw_materials').first()
                    batch_status = 'available'
                    move_type = 'IN'
                elif mretn.return_to == 'quarantine':
                    dest_wh = Warehouse.objects.filter(warehouse_type='quarantine').first()
                    batch_status = 'quarantine'
                    move_type = 'QUARANTINE'
                else:  # scrap
                    dest_wh = None
                    batch_status = 'scrapped'
                    move_type = 'SCRAP'

                # Process each line
                for line in mretn.lines.select_related('product').all():
                    if mretn.return_to != 'scrap':
                        # Find original batch to credit back (if batch_reference known)
                        credited = False
                        if line.batch_reference:
                            batch = StockBatch.objects.filter(
                                batch_number=line.batch_reference,
                                product=line.product,
                            ).first()
                            if batch:
                                batch.remaining_quantity = (
                                    float(batch.remaining_quantity) + float(line.qty_returned)
                                )
                                batch.status = batch_status
                                if dest_wh:
                                    batch.warehouse = dest_wh
                                batch.save(update_fields=['remaining_quantity', 'status', 'warehouse'])
                                credited = True

                        if not credited:
                            # Create a new batch for the return
                            StockBatch.objects.create(
                                product=line.product,
                                grn_number=f'MRetN:{mretn.mretn_number}',
                                warehouse=dest_wh,
                                quantity_received=line.qty_returned,
                                remaining_quantity=line.qty_returned,
                                unit_cost=line.product.unit_cost,
                                status=batch_status,
                                created_by=request.user,
                            )

                    # Record stock movement
                    StockMovement.objects.create(
                        product=line.product,
                        movement_type=move_type,
                        quantity=line.qty_returned,
                        reference=mretn.mretn_number,
                        notes=(
                            f'Return from production. WO: {mretn.work_order.wo_number}. '
                            f'Reason: {mretn.get_reason_display()}. '
                            f'Condition: {line.condition}.'
                            + (f' {line.defect_description}' if line.defect_description else '')
                        ),
                        performed_by=request.user,
                    )

                mretn.status = 'accepted'
                mretn.accepted_by = request.user
                mretn.accepted_at = timezone.now()
                mretn.save(update_fields=['status', 'accepted_by', 'accepted_at'])

                # Notify initiator
                try:
                    from apps.messaging.models import Message, MessageRecipient
                    msg = Message.objects.create(
                        sender=request.user,
                        subject=f'MRetN Accepted: {mretn.mretn_number}',
                        body=(
                            f'{mretn.mretn_number} has been accepted by {request.user.get_full_name()}.\n\n'
                            f'Items returned to: {mretn.get_return_to_display()}\n'
                            f'Accepted at: {timezone.now().strftime("%d %b %Y %H:%M")}'
                        ),
                        is_urgent=False,
                        ref_module='mretn',
                        ref_number=mretn.mretn_number,
                        reference_type='MRetN',
                        reference_number=mretn.mretn_number,
                    )
                    if mretn.initiated_by:
                        MessageRecipient.objects.create(message=msg, recipient=mretn.initiated_by)
                except Exception:
                    pass

            messages.success(
                request,
                f'✓ {mretn.mretn_number} accepted. '
                f'{mretn.lines.count()} item(s) returned to '
                f'{mretn.get_return_to_display()}. Stock updated.'
            )
        except Exception as e:
            logger.error(f'[mretn_accept] {e}')
            messages.error(request, f'Error processing return: {e}')
    return redirect('pmc:mretn_detail', pk=pk)


@login_required
@role_required('admin', 'warehouse', 'factory_manager')
def mretn_reject(request, pk):
    """WC rejects the return — sends back to production with a reason"""
    from apps.pmc.models import MRetN
    mretn = get_object_or_404(MRetN, pk=pk)
    if request.method == 'POST':
        reason = request.POST.get('rejection_reason', '').strip()
        if not reason:
            messages.error(request, 'A rejection reason is required.')
            return redirect('pmc:mretn_detail', pk=pk)
        mretn.status = 'rejected'
        mretn.rejection_reason = reason
        mretn.accepted_by = request.user
        mretn.accepted_at = timezone.now()
        mretn.save(update_fields=['status', 'rejection_reason', 'accepted_by', 'accepted_at'])
        # Notify initiator
        try:
            from apps.messaging.models import Message, MessageRecipient
            msg = Message.objects.create(
                sender=request.user,
                subject=f'MRetN Rejected: {mretn.mretn_number}',
                body=(
                    f'{mretn.mretn_number} has been REJECTED by {request.user.get_full_name()}.\n\n'
                    f'Reason: {reason}\n\n'
                    f'Please review and resubmit or contact the Warehouse Controller.'
                ),
                is_urgent=False,
                ref_module='mretn', ref_number=mretn.mretn_number,
                reference_type='MRetN', reference_number=mretn.mretn_number,
            )
            if mretn.initiated_by:
                MessageRecipient.objects.create(message=msg, recipient=mretn.initiated_by)
        except Exception:
            pass
        messages.warning(request, f'{mretn.mretn_number} rejected. Initiator has been notified.')
    return redirect('pmc:mretn_detail', pk=pk)


@login_required
@role_required('admin', 'production', 'factory_manager', 'warehouse', 'pmc')
def mretn_pdf(request, pk):
    from apps.pmc.models import MRetN
    from apps.master.models import SystemSettings
    mretn = get_object_or_404(MRetN, pk=pk)
    lines = mretn.lines.select_related('product').all()
    return render(request, 'pmc/mretn_pdf.html', {
        'mretn': mretn, 'lines': lines,
        'sys': SystemSettings.get_settings(),
        'now': timezone.now(),
    })
