"""
ELMAS Production Server
Run with: python serve.py
"""
import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'elmas_core.settings')

from waitress import serve
from elmas_core.wsgi import application

if __name__ == '__main__':
    print("=" * 55)
    print("  ELMAS — Ellams Manufacturing Automation System")
    print("  Starting server on port 5000...")
    print("  Open: http://localhost:5000")
    print("  Stop: Press Ctrl+C")
    print("=" * 55)
    serve(application, host='0.0.0.0', port=5000, threads=8)
