from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.views.generic import RedirectView

admin.site.site_header = 'ELMAS-NEXSUS ERP Administration'
admin.site.site_title = 'ELMAS-NEXSUS'

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', RedirectView.as_view(url='/dashboard/', permanent=False)),
    path('accounts/', include('apps.accounts.urls', namespace='accounts')),
    path('dashboard/', include('apps.accounts.dashboard_urls', namespace='dashboard')),
    path('master/', include('apps.master.urls', namespace='master')),
    path('receiving/', include('apps.receiving.urls', namespace='receiving')),
    path('inventory/', include('apps.inventory.urls', namespace='inventory')),
    path('bettery/', include('apps.bettery.urls', namespace='bettery')),
    path('qc/', include('apps.qc.urls', namespace='qc')),
    path('messaging/', include('apps.messaging.urls', namespace='messaging')),
    path('core/', include('apps.core.urls', namespace='core')),
    path('reports/', include('apps.reports.urls', namespace='reports')),
    path('pmc/', include('apps.pmc.urls', namespace='pmc')),
    path('production/', include('apps.production.urls', namespace='production')),
    path('dispatch/', include('apps.dispatch.urls', namespace='dispatch')),
    path('procurement/', include('apps.procurement.urls', namespace='procurement')),
    path('gl/',          include('apps.gl.urls',          namespace='gl')),
    path('hr/',          include('apps.hr.urls',          namespace='hr')),
    path('portal/',      include('apps.portal.urls',      namespace='portal')),
    # REST API endpoints
    path('api/stock/<int:product_id>/',   __import__('apps.core.api', fromlist=['api_stock_level']).api_stock_level,  name='api_stock_level'),
    path('api/stock/',                     __import__('apps.core.api', fromlist=['api_stock_list']).api_stock_list,     name='api_stock_list'),
    path('api/stock/shortages/',           __import__('apps.core.api', fromlist=['api_shortage_alerts']).api_shortage_alerts, name='api_shortages'),
    path('api/wo/<str:wo_number>/',        __import__('apps.core.api', fromlist=['api_wo_status']).api_wo_status,      name='api_wo_status'),
    path('api/wo/',                         __import__('apps.core.api', fromlist=['api_wo_list']).api_wo_list,          name='api_wo_list'),
    path('api/production/output/',          __import__('apps.core.api', fromlist=['api_log_output']).api_log_output,    name='api_log_output'),
    path('api/so/<str:so_number>/completion/', __import__('apps.core.api', fromlist=['api_so_completion']).api_so_completion, name='api_so_completion'),
    path('api/gl/summary/',                 __import__('apps.core.api', fromlist=['api_gl_summary']).api_gl_summary,    name='api_gl_summary'),
    path('api/messages/unread/',            __import__('apps.core.api', fromlist=['api_unread_count']).api_unread_count, name='api_unread'),
    path('api/messages/urgent/',            __import__('apps.core.api', fromlist=['api_pending_urgent']).api_pending_urgent, name='api_urgent'),
    path('api/fm/queue/',                   __import__('apps.core.api', fromlist=['api_fm_queue']).api_fm_queue,        name='api_fm_queue'),
    path('api/bettery/stock/',              __import__('apps.core.api', fromlist=['api_bettery_stock']).api_bettery_stock, name='api_bettery_stock'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
